<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"/>
	<title>download_detail</title>
	<script src="/js/jquery-3.2.1.min.js"></script>
	<script src="/js/jquery.cookie.js"></script>
</head>
<style>
	html,body,p,img,a{
		margin: 0;
		padding: 0;
	}
	a{
		text-decoration: none;
	}
	body{
		/*background: url('/images/bg.png');*/
		background-repeat: 	no-repeat;
		background-size: cover;
		text-align: center;
		margin: 0 auto;
	}
	.icon{
		width: 33.066666%;
		height: 18.59071464767%;
		margin-top: 48.534%;
	}
	.app-name{
		font-size: 24px;
		color: #fff;
		margin-top: 8px;
	}
	.btn{
		width: 220px;
		height: 71px;
		margin-top: 8.8%;
		display: inline-block;
	}
	.free-btn{
		background: url('/images/free_button.png');
		background-size: cover;
	}
	.free-btn:active{
		background: url('/images/free_button_active.png');
		background-size: cover;
	}
	.load-wifi{
		width: 220px;
		text-align: right;
		margin: 0 auto;
	}
	.load-wifi span{
		font-size: 16px;
		color: #fff;
		border-bottom: 	1px solid #fff;
	}
	.rich-btn{
		margin-top: 26px;
		background: url('/images/rich_button.png');
		background-size: cover;
	}
	.rich-btn:active{
		background: url('/images/rich_button_active.png');
		background-size: cover;
	}
	.protal{
		width: 100%;
		height: 100%;
		background-color: rgba(0,0,0,0.5);
		position: fixed;
		top: 0;
		left: 0;
        display: none;
	}
	.protal img{
		width: 100%;
		height: 100%;
	}
	.thickness{
		width: 100%;
		height: 100%;
		background-repeat: no-repeat;
		background-size: cover;
		position: fixed;
		z-index: 1000;
		bottom: 0;
		display: none;
	}
	.error{
		width: 80%;
		line-height: 44px;
		height: 44px;
		margin: 0 auto;
		position: fixed;
		top: 46%;
		left: 10%;
		background-color: rgba(0,0,0,0.5);
		border-radius: 4px;
		display: none;
		color: #fff;
	}
	.iKnow{
		background-color: #007aff;
		color: #fff;
		font-size: 16px;
		padding: 1.1% 4%;
		border-radius:14.05%;
		position: absolute;
		border-radius: 100px;
		text-align: center;
		letter-spacing: 0;
		outline: none;
		resize: none;
		border: none;
		text-decoration: none;
		bottom: 10px;
		right: 50%;
        margin-right: -15%;
	}
	.msg-box{
        position: relative;
        width: 80.3%;
        height: 77.8%;
        left: 50%;
        top: 50%;
        margin-left: -40.15%;
        margin-top: -68.9%;
    }
</style>
<body>
	<div class="error">
		下载被拒绝，请先连接WIFI！
	</div>
	<img id="img1" alt="">
	<img class="icon">
	<div class="app-name"></div>

	<div class="load-wifi">
		<a class="btn free-btn"></a>
		<span class="howtowifi">如何连WIFI?</span>
	</div>
	<a class="btn rich-btn"></a>
	<div class="protal">
		<div class="msg-box">
            <img src="/images/msg.png" alt="">
            <div class="iKnow">我知道了</div>
        </div>
	</div>
	<div class="thickness" id="thickness"></div>
</body>
<script>
	$(".icon").height(window.screen.height*0.1859071464767)
	var mobile_msg = window.navigator.userAgent;
	function isWeiXin(){  //判断微信浏览器 方法
		var ua = mobile_msg.toLowerCase();
		if(ua.match(/MicroMessenger/i) == 'micromessenger'){
		    return true;
		}else{
		    return false;
		}
	};
	$(".howtowifi").click(function(){  //如何连wifi
		$(".protal").show();
	});
	// $(".protal").click(function(e){  //点击关闭弹层
	// 	e.stopImmediatePropagation();
	// 	$(".protal").hide();
		// if (e.currentTarget.className=="protal") {
		// 	$(".protal").hide();
		// };
	// });
	$(".iKnow").click(function(e){  //点击关闭弹层
		$(".protal").hide();
	});
	$(".free-btn").click(function(){
		$(".error").show();
		var timer = setInterval(function(){
			$(".error").hide();
		}, 3000)
	});
	document.getElementById('img1').onload = function(e){
	    e.stopPropagation();
	    if ($("#img1").height()/2<667) {
	    	$("body").height(window.screen.height);
	    }else{
	    	$("body").height($("#img1").height()/2);  //为了背景图而给body的高度适配
	    }
	    $("#img1").hide();
	}
	 // 获取参数
    function getUrlParam(name){
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        if (r!=null) return unescape(r[2]); return null;
    };
	var planid = getUrlParam('planid');
    var adid = getUrlParam('adid');
    var mac = getUrlParam('mac');
    var source = getUrlParam('source');
    var number = getUrlParam('number');
	var type = navigator.userAgent.indexOf(("Android")||('Nokia'))==-1?"ios":"android";
	sessionStorage.setItem('type', type);

	$.ajax({
		type: 'get',
	    dataType: 'json',
	    url: "/browser/api-res",   //请求地址
	    data: {'planid': planid, 'adid': adid, 'mac': mac, 'source': source},  //请求所需要的参数
	    async: true,  //是否异步
	    success: function(data) { //成功的回调
	    	var res = data.data; //请求来的数据
	    	console.log(res);
	    	var bg_url = "url("+ res.content.H5_bg_url +")";
	    	if (!$.cookie('flag')) {   //如果不存在标记才统计
				$.ajax({
					type: 'get',
				    dataType: 'json',
				    url: "http://yule.datuhongan.com/api/wexin/gro-push",   //请求地址
				    data: {'number': number, 'gid': Number(adid)},  //请求所需要的参数
				    async: true,  //是否异步
				    success: function(data) { //成功的回调
				    	if (data.code==0) {
				    		$.cookie('flag', 'count_people', { expires: 30 });  //为了递推员而存储的标记 存30天
				    	}
				    }
				})
	    	}
	    	document.getElementById('img1').src= res.content.H5_bg_url;
	    	document.getElementById('img1').onload = function(e){
			    e.stopPropagation();
			    if ($("#img1").height()/2<667) {
			    	$("body").height(window.screen.height);
			    }else{
			    	$("body").height($("#img1").height()/2);  //为了背景图而给body的高度适配
			    }
			    $("#img1").hide();
			}
	    	$("body").css('background-image', bg_url);  //背景图
	    	$(".icon").attr('src', res.icon_url);   //icon图  resource_name
	    	$(".app-name").html(res.resource_name);  //app名称
	    	var mobileType  = sessionStorage.getItem('type');
	   		if (mobileType=='ios') {
	   			if (isWeiXin()) {  //是微信浏览器
						$('.thickness').show();
						$("#thickness").css('background-image', "url(/images/ios.png)");
					}
	    		if (res.content.app_platform.iOS) {//如果存在ios版本
					$(".rich-btn").attr('href', res.content.app_platform.iOS.apk_url);
					$(".rich-btn").click(function(){
						$.ajax({
							type: 'post',
					    	dataType: 'json',
					    	url: "/outapi/count-create-download",   //请求地址
					    	data: {'planid': planid, 'mac': mac, 'adid': adid, 'source': source, 'os': mobileType},   //请求所需要的参数
					    	async: true,  //是否异步
					    	success: function(data) {  //成功的回调
					    			// console.log('download');
				    		if(data.code==0){  //
							    }else if(data.code==1){  //请求通了但是异常

							    }
				    		},
				    		error: function(data) {  //接口异常
				    		  console.log(data)
				    		}

							})
						})
	    		}else{
	    			//window.location.href = res.apple_error; //跳转到没有ios版本的页面
	    			$(".rich-btn").attr('href', res.apple_error);
	    		}
	    	}else if (mobileType=='android') {
	    		if (isWeiXin()) {  //是微信浏览器
						$('.thickness').show();
						$("#thickness").css('background-image', "url(/images/android.png)");
					}
	    		if (res.content.app_platform.Android) {//如果存在安卓版本
					$(".rich-btn").attr('href', res.content.app_platform.Android.apk_url);
					$(".rich-btn").click(function(){
						$.ajax({
							type: 'post',
				    		dataType: 'json',
				    		url: "/outapi/count-create-download",   //请求地址
				    		data: {'planid': planid, 'mac': mac, 'adid': adid, 'source': source, 'os': mobileType},   //请求所需要的参数
				    		async: true,  //是否异步
				    		success: function(data) {  //成功的回调
				    			// console.log('download');
				    			if(data.code==0){  //
							    }else if(data.code==1){  //请求通了但是异常

							    }
				    		},
				    		error: function(data) {  //接口异常
				    		  console.log(data)
				    		}

						})
					})
	    		}else{
	    			window.location.href = res.android_error; //跳转到没有ios版本的页面
	    		}
	    	}
	    },
	    error: function(data){

	    }
	})

	//判断是否是首次还是刷新
 	if (performance.navigation.type==0) {
		$.ajax({
			type: 'post',
			dataType: 'json',
			url: "/outapi/count-create",   //请求地址
			data: {'planid': planid, 'mac': mac, 'adid': adid, 'source': source, 'os': type},   //请求所需要的参数
			async: true,  //是否异步
			success: function(data) {  //成功的回调
				console.log('first');
				if(data.code==0){  //
			    }else if(data.code==1){  //请求通了但是异常

			    }
			},
			error: function(data) {  //接口异常
				  console.log(data)
				}
			})
 			// alert('刷新')
 		}else if (performance.navigation.type==1) {}
</script>
</html>