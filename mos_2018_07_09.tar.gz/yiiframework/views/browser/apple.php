<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"/>
	<title>ios_error</title>
	<style>
		html, body{
			margin: 0;
			padding: 0;
			width: 100%;
			height: 100%;
		}
		body{
			height: 100%;
			background: url(/images/ios_error.png) no-repeat;
			background-size: cover;
			border-top:1px solid transparent;
		}

</head>
<body>
</body>
</html>