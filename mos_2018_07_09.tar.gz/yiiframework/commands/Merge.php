<?php
namespace app\commands;


class Merge
{
	public $enableCsrfValidation = false;

	public $filepath; //上传目录
	public $tmpPath; //PHP文件临时目录
	public $blobNum; //第几个文件块
	public $totalBlobNum; //文件块总数
	public $fileName; //文件名
	public $filename; //上传后的文件路径

	public function __construct($totalBlobNum='', $fileName='', $tmpPath='', $blobNum='')
	{
		$this->tmpPath = $tmpPath;
		$this->blobNum = $blobNum;
		$this->totalBlobNum = $totalBlobNum;
		$this->fileName = $fileName;
		$this->filepath = $_SERVER['DOCUMENT_ROOT'] . '/mos/api/' . date('Ymd');
	}

	//合并文件夹
	public function fileMerge($name)
	{
		ini_set('memory_limit', -1);
		$blob = '';
		for($i=1; $i<= $this->totalBlobNum; $i++){
			$blob .= file_get_contents($this->filepath.'/'. $this->fileName.'__'.$i);
		}
		file_put_contents($this->filepath.'/'. $name,$blob);
		$this->deleteFileBlob();
	}

	//删除文件块
	public function deleteFileBlob()
	{
		for($i=1; $i<= $this->totalBlobNum; $i++){
			@unlink($this->filepath.'/'. $this->fileName.'__'.$i);
		}
	}

	//移动文件
	public function moveFile()
	{
		$this->touchDir();
		$this->filename = $this->filepath.'/'. $this->fileName.'__'.$this->blobNum;
		move_uploaded_file($this->tmpPath,$this->filename);
	}

	//建立上传文件夹
	public function touchDir(){
		if (!file_exists($this->filepath)) {
			mkdir($this->filepath, 0777);
			chmod($this->filepath, 0777);
			return ;
		}
	}
}