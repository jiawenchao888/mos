<?php

namespace app\commands;

use app\common\Common;
use app\service\CommonService;
use yii\console\Controller;
use Yii;

class CrontabController extends Controller {


	/**
	 * 外审定时发送邮件
	 * @return [type] [description]
	 */
	public function actionSendMail()
	{
		set_time_limit(0);
		$redis = Yii::$app->redis;
		$keys = $redis->hkeys('sendEmail');
		foreach ($keys as $value) {
			$email = $redis->hget('sendEmail', $value);
			if (Common::sendMail($email, '有新的物料需要审核', Yii::$app->params['other']['outAudit'])) {
				$redis->hdel('sendEmail', $value);
			}
		}
	}

	/**
	 * 定时获取渠道信息
	 */
	public function actionChannelInfo()
	{
		$redis = Yii::$app->redis;
		set_time_limit(0);
		$result = CommonService::recursionChannelId(0);
		$result = json_encode($result);
		$redis->set('ProvinceList',$result);
	}

}