<?php

namespace app\commands;

use app\logic\ChargeLogic;
use app\service\CommonService;
use yii\console\Controller;
use Yii;

class ErcodeController extends Controller {

	/**
	 * 定时任务获取macAddres的二维码
	 * @return
	 */
	public function actionCotErCode()
	{
		set_time_limit(0);
		$redis = Yii::$app->redis;
		$macAddress = $redis->hkeys('machineInfoByMacAddress');
		foreach ($macAddress as $key => $value) {
			for ($i=1; $i <= 8 ; $i++) {
				$data = ChargeLogic::terminalGetChargeCodeEr($value, $i);
				if ($data === 0) {
					continue;
				}
				$erCode = json_decode($data, true);
				if (is_array($erCode['data'])) {
					$redis->hset('machineErCode', $value . "_" . $i, $erCode['data'][$i]);
				} else {
					$redis->hset('machineErCode', $value . "_" . $i, $erCode['data']);
				}
			}
		}
	}

	/**
	 * @name 根据mac获取设备信息
	 * @return
	 */
	public function actionGetMachineInfoByMacAddress()
	{
		set_time_limit(0);
		$data = CommonService::getAllChannelList(1);
		$channelList = array_column($data, 'id');
		$machineInfo = [];
		foreach ($channelList as $key => $value) {
			$machineInfo = array_merge($machineInfo, CommonService::getAllMachine($value));
		}
		$tmp = ['machineInfoByMacAddress'];
		foreach ($machineInfo as $v) {
			$tmp[] = $v['macAddress'];
			$tmp[] = json_encode($v, JSON_UNESCAPED_UNICODE);
		}
		$redis = Yii::$app->redis;
		$redis->executeCommand('HMSET', $tmp);
	}

}