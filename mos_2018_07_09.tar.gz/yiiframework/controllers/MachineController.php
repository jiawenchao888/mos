<?php

namespace app\controllers;

use Yii;
use app\commands\Rsa;
use app\service\CommonService;

class MachineController extends CommonController
{

	/**
	 * 根据设备id创建指令,素材发布内网
	 * author caolei
	 * @return [type] [description]
	 */
	public function actionMachineorder()
	{
			$get = Yii::$app->request->get();
			$instruct = [
				'machineId' => $get['id'],
				'key' => 'Res_Download_Conf',
				'value' => $get['value'],
				'expired' => time()+300,
			];
			$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandCreateByManchineId'],$instruct);
			if ($res['code']) {
				$this->error(11000, '创建失败', $res);
				return ;
			} else {
				$data = [
					'projectName' => 'mos',
					'controllerName' => Yii::$app->controller->id,
					'actionName' => Yii::$app->controller->action->id,
					'type' => 'insert', //新增=insert、更新=update、删除=delete
					'userId' => $get['user_id'],
					'matter' => '查看日志',
					'data1' => '发布内网', //操作类型
					'data2' => '素材', //资源类型
					'data3' => $get['value'], //资源类型对应的id
					'time' => time(),
				];
				//将操作的记录保存
				$res = $this->operateLog($data);
				$this->success($res, '创建成功');
			}
	}

}