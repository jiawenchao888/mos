<?php
namespace app\controllers;

use Yii;
use app\models\NetpointWechat;
use app\models\DefaultWechat;
use app\logic\WechatLogic;
use app\logic\MachineOrder;
use app\logic\ChargeLogic;
use app\service\CommonService;
use yii\data\Pagination;
use app\service\CurlService;

class ChargeController extends CommonController
{
	public $enableCsrfValidation = false;

	public function behaviors()
	{
		return [
			'verbs' => [
				'class' => \yii\filters\VerbFilter::className(),
				'actions' => [
					'termianl-get-charge-code-er' => ['post'],
				],
			],
		];
	}

	/**
	 * @name 网点添加微信公众号
	 * @author caolei
	 * @time 2017年12月6日10:07:47
	 * @return [json]
	 */
	public function actionAdd()
	{
			$data = Yii::$app->request->post();
			$netpointId = explode(',', $data['netpoint_id']);
			$id = explode(',', $data['netpoint_id']);
			unset($data['netpoint_id']);
			$error = '';
			foreach ($netpointId as $key => $value) {
				$data['netpoint_id'] = $value;
				$model = new NetpointWechat();
				$model->created_time = time();
				if (!($model->edit($data))) {
					$error .= $id[$key] . ',';
				}
			}
			if ('' === $error) {
				$this->success('', 'success');
			} else {
				$this->error(12000, $error . ' 添加失败');
			}
	}

	/**
	 * @name 网点编辑微信公众号
	 * @author caolei
	 * @time 2017年12月6日13:53:02
	 * @return [type] [description]
	 */
	public function actionEdit()
	{
		$data = Yii::$app->request->post();
		$id = explode(',', $data['id']);
		unset($data['id']);
		Yii::$app->redis->del('machineErCode', 'machineInfoByMacAddress');
		$error = '';
		foreach ($id as $key => $value) {
			$model = NetpointWechat::findOne(['id' => $value]);
			if (!($model->edit($data))) {
				$error .= $id[$key] . ',';
			}
			//终端更新二维码
			MachineOrder::resetTerminalErCode($model->netpoint_id);
		}
		if ('' === $error) {
			$this->success('', 'success');
		} else {
			$this->error(12000, $error . ' 修改失败');
		}
	}

	/**
	 * @name 列表
	 * @author caolei
	 * @time 2017年12月11日17:43:28
	 * @return [type] [description]
	 */
	public function actionList()
	{
		//接受参数
		$get['name'] = Yii::$app->request->get('wechat_name', '');
		$get['url'] = Yii::$app->request->get('wechat_url', '');
		$get['page'] = Yii::$app->request->get('page', 1);
		$get['channelId'] = Yii::$app->request->get('channel_id', '');
		$pageSize = Yii::$app->request->get('page_size', 10);
		//搜索框条件查询
		$model = NetpointWechat::find();
		$model->andFilterWhere(['like', 'name', $get['name']])->andFilterWhere(['like', 'url_wechat', $get['url']]);
		//分页
		//只传递了渠道id查询
		if ($get['channelId'] && empty($get['name']) && empty($get['url'])) {
			$wecharNetPoint = $model->orderBy('id desc')->asArray()->all();
			$wecharNetPoint = array_column($wecharNetPoint, null , 'netpoint_id');
			$data = $this->actionAddWechatInfo($get['channelId'], $wecharNetPoint, $get['page'], $pageSize);
		} else if ((!empty($get['name']) || !empty($get['url'])) && empty($get['channelId'])) {
			//只传递了公众号名称，或者链接的查询
			$count = $model->count();
			$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
			$wecharNetPoint = $model->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			$data = $this->actionAddChannelInfo($wecharNetPoint, $count, $get['page'], $pageSize);
		} else if (empty($get['name']) && empty($get['url']) && empty($get['channelId'])) {
			//第一次进入页面，展示所有，没有关联的公众号的默认关联大途弘安
			$wecharNetPoint = $model->orderBy('id desc')->asArray()->all();
			$wecharNetPoint = array_column($wecharNetPoint, null , 'netpoint_id');
			$allNetpoint = $this->getAllNetPoint();
			$allNetpoint = array_column((array)$allNetpoint, null , 'id');
			$data = $this->actionAllNetpointAddWechatInfo($allNetpoint, $wecharNetPoint, $get['page'], $pageSize);
		} else if ($get['channelId'] && (!empty($get['name']) || !empty($get['url']))) {
			//传递了渠道id，还传递了公众号，或者链接的其中一个
			$wecharNetPoint = $model->orderBy('id desc')->asArray()->all();
			$wecharNetPoint = array_column($wecharNetPoint, null , 'netpoint_id');
			$data = $this->actionDelMoreNetPoint($get['channelId'], $wecharNetPoint, $get['page'], $pageSize);
		}
		$data['list'] = $this->addParentChannelInfo($data['list']);
		$this->success($data, 'success');
	}

	/**
	 * @name 补全网点的父级信息
	 * @param [array] $data [展示的信息]
	 * @author lei.cao
	 * @time 2018年1月5日
	 * @return array
	 */
	public function addParentChannelInfo($data)
	{
		$hh = array_map(function ($value)
		{
			$res = CommonService::getParentChannelByChannelId($value['netpoint_id']);
			if (empty($res['data'][0])) {
			} else {
				if (empty($value['channel_msg'])) {
				} else {
					$value['channel_msg'] = $res['data'][0]['name'] . '-' . $res['data'][1]['name'] . '-' . $res['data'][2]['name'] . '-' . $value['channel_msg'];
				}
			}
			return $value;
		}, $data);
		return $hh;
	}

	/**
	 * @name 获取所有的网点列表
	 * @author caolei
	 * @time 2018年1月3日
	 * @return [type] [description]
	 */
	public function getAllNetPoint()
	{
		$allPointCount = CommonService::getCountByLevel(4);
		$times = ceil($allPointCount['data'] / 50);
		$allNetpoint = [];
		for ($i = 1; $i <= $times; $i++) {
			$allNetpoint = array_merge($allNetpoint,  CommonService::getAllInfoByLevel(4, 50, $i)['data']);
		}
		return $allNetpoint;
	}

	/**
	 * @name 删除多余的不在查询范围的网点
	 * @author caolei
	 * @time 2017年12月12日14:57:37
	 * @param [int] $channelId  渠道信息
	 * @param [arr] $wecharNetPoint 带微信信息的网点信息
	 * @param [int] $page 页码
	 * @param [int] $pageSize 每页数量
	 * @return [type] [description]
	 */
	public function actionDelMoreNetPoint($channelId, $wecharNetPoint, $page, $pageSize)
	{
		$field = 'id, name, parent_id, level';
		$netPoint = array_column(CommonService::childChannelByChannelId($channelId, 4, $field), null, 'id');
		$data['list'] = array_intersect_key($wecharNetPoint, $netPoint);
		$data['list'] = $this->actionMergeWechatNetPoint($data['list'], $netPoint);
		$data['list'] = array_slice($data['list'], ($page-1)*$pageSize, $pageSize);
		$netPointCount = count($data['list']);
		$data['paginate'] = self::paginate($page, $pageSize, $netPointCount);
		return $data;
	}

	/**
	 * @name 将$netPoint中的信息，补全微信信息
	 * @author caolei
	 * @time 2017年12月11日17:44:19
	 * @param  [int] $channelId       [渠道id]
	 * @param  [type] $wecharNetPoint [微信网点信息]
	 * @param  [type] $page           [当前页码]
	 * @param  [type] $pageSize       [每页数量]
	 * @return [type]                 [description]
	 */
	public function actionAddWechatInfo($channelId, $wecharNetPoint, $page, $pageSize)
	{
		$field = 'id, name, parent_id,level';
		$netPoint = array_column(CommonService::childChannelByChannelId($channelId, 4, $field), null, 'id');
		//将微信的信息遍历到$netPoint中
		$data['list'] = $this->actionMergeNetPointWechat($netPoint, $wecharNetPoint);
		$this->actionSortArrByField($data['list'], 'id', true);
		$data['list'] = array_slice($data['list'], ($page-1)*$pageSize, $pageSize);
		$netPointCount = count($netPoint);
		$data['paginate'] = self::paginate($page, $pageSize, $netPointCount);
		return $data;
	}

	/**
	 * @name 将netPoint中的信息补全wecharNetPoint信息
	 * @param  [arr] $netPoint       [单一的网点信息]
	 * @param  [arr] $wecharNetPoint [带微信的网点信息]
	 * @return [arr]                 [单一的网点信息中添加微信的信息]
	 */
	public function actionMergeNetPointWechat($netPoint, $wecharNetPoint)
	{
		$data = array_map(
			function ($n) use ($wecharNetPoint) {
				if (array_key_exists($n['id'], $wecharNetPoint))
				{
					$n['wechat_name'] = $wecharNetPoint[$n['id']]['name'];
					$n['url_wechat'] = $wecharNetPoint[$n['id']]['url_wechat'];
					// var_dump($n);die;
					$n['netpoint_id'] = $n['id'];
					$n['id'] = $wecharNetPoint[$n['id']]['id'];
					$n['channel_msg'] = $n['name'];
					unset($n['name']);
				}
				return $n;
			}, $netPoint);
		return $data;
	}

	/**
	 * @name 将wecharNetPoint中的信息补全netPoint的信息
	 * @param  [arr] $wecharNetPoint [带微信的网点信息]
	 * @param  [arr] $netPoint       [单一的网点信息]
	 * @return [arr]                 [微信的网点信息添加网点的信息]
	 */
	public function actionMergeWechatNetPoint($wecharNetPoint, $netPoint)
	{
		$data = array_map(
			function ($n) use ($netPoint) {
				if (array_key_exists($n['netpoint_id'], $netPoint))
				{
					$n['wechat_name'] = $n['name'];
					// $n['name'] = $netPoint[$n['netpoint_id']]['name'];
					$n['channel_msg'] = $netPoint[$n['netpoint_id']]['name'];
					unset($n['name']);
				}
				return $n;
			}, $wecharNetPoint);
		return $data;
	}

	/**
	 * @name 展示所有的网点信息，关联微信
	 * @param  [arr] $allNetpoint    [所有网点的数据]
	 * @param  [arr] $wecharNetPoint [微信公众号数据库中数据]
	 * @return [type]                 [description]
	 */
	public function actionAllNetpointAddWechatInfo($allNetpoint, $wecharNetPoint, $page, $pageSize)
	{
		//比对netpoint网点，中不在wechat中的id，如果存在则默认大途微信公众号，入数据库
		$diffNetpoint = array_diff_key($allNetpoint, $wecharNetPoint);
		$defaultWechat = DefaultWechat::getWechatUrl();
		foreach ($diffNetpoint as $key => $value) {
			$model = new NetpointWechat();
			$model->netpoint_id = $value['id'];
			$model->name = $defaultWechat['name'];
			$model->url_wechat = $defaultWechat['wechat_url'];
			$model->created_time = time();
			$model->save();
		}
		$model = NetpointWechat::find();
		$count = $model->count();
		$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
		$wecharNetPoint = $model->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
		$wecharNetPoint = $this->actionMergeWechatNetPoint($wecharNetPoint, $allNetpoint);
		$data['list'] = $wecharNetPoint;
		$data['paginate'] = self::paginate($page, $pageSize, $count);
		return $data;
	}

	/**
	 * @name 将$wecharNetPoint中的信息，补全渠道信息
	 * @author caolei
	 * @time 2017年12月11日17:43:56
	 * @param  [arr] $wecharNetPoint [微信网点信息]
	 * @param  [int] $count  [总数]
	 * @param  [int] $page   [页码]
	 * @param  [int] $pageSize 每页数量
	 * @return [type]                 [description]
	 */
	public function actionAddChannelInfo($wecharNetPoint, $count, $page, $pageSize)
	{

		foreach ($wecharNetPoint as $key => &$value) {
			$value['wechat_name'] = $value['name'];
			$value['channel_msg'] = CommonService::channelInfoByChannelId($value['netpoint_id'])['data']['name'];
			$value['wechar_id'] = $value['id'];
		}
		$data['list'] = $wecharNetPoint;
		$data['paginate'] = self::paginate($page, $pageSize, $count, $pageSize);
		return $data;
	}

	/**
	 * 二维数组根据特定的键进行排序
	 * @param  [type]  &$array [description]
	 * @param  [type]  $field  [排序的键]
	 * @param  boolean $desc   [排序规则]
	 * @return [type]          [description]
	 */
	public function actionSortArrByField(&$array, $field, $desc = false){
		$fieldArr = array();
		foreach ($array as $k => $v) {
		  $fieldArr[$k] = $v[$field];
		}
		$sort = $desc == false ? SORT_ASC : SORT_DESC;
		array_multisort($fieldArr, $sort, $array);
	}

	/**
	 * @name 终端获取二维码
	 * @author caolei
	 * @time 2017年12月19日11:41:33
	 * @return [type] [description]
	 */
	public function actionTermianlGetChargeCodeEr()
	{
		try {
			$macAddress = Yii::$app->request->get('mac', '');
			$port = Yii::$app->request->get('port', '');
			$netPointId = $this->actionPointIdByMac($macAddress);
			$data = [
				'mac' => $macAddress,
				'port' => $port,
			];
			$model = new NetpointWechat();
			if ($url = $model->getUrlByNetPointId($netPointId['netpoint_id'])) {
				// MachineOrder::deleteOrderByMacAddress($macAddress, Yii::$app->params['machineOrder']['downloadWechatErCode']);
				if ($erCodeUrl = Yii::$app->redis->hget('machineErCode', $macAddress . "_" . $port)) {
					return json_encode(['code' => 0, 'msg' => 'get-temp-qrcode-success', 'data' => $erCodeUrl]);
				}
				return json_encode($this->HttpClient($url, $data, 'get'));
			} else {
				// $url = Yii::$app->params['weChat']['makeErCode'];
				$url = WechatLogic::getDefaultWechat(1);
				return json_encode($this->HttpClient($url, $data, 'get'));
			}
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 生成二维码地址拼接参数
	 * @param  [string] $mac  [mac地址]
	 * @param  [int] $port [终端扫码充电的充电口]
	 * @param  [string] $url  [生成二维码的地址]
	 * @author caolei
	 * @time 2017年12月19日17:32:33
	 * @return [string]       [带参数的url]
	 */
	public function actionUrlAddParam($mac, $port, $url)
	{
		if (strpos($url, '?')) {
			return $url . '&mac=' . $mac . '&port=' . $port;
		} else {
			return $url . '?mac=' . $mac . '&port=' . $port;
		}
	}

	/**
	 * @name 根据mac地址查询,机器所在网点ID
	 * @author caolei
	 * @time 2017年11月29日19:46:36
	 * @macAddress int $macAddress
	 * @return [type] [description]
	 */
	public function actionPointIdByMac($macAddress)
	{
		//通过redis查询
		if ($data = ChargeLogic::redisGetPointIdByMac($macAddress)) {
			return $data;
		}
		//如果redis中没有查询到，在走方圆
		$machineInfoApi = Yii::$app->params['apiBaseList']['apiMachineMacAddress'];
		$machineInfoData = [
			"macAddress" => $macAddress,
			"field" => 'channel_id,id',
		];
		$machineInfo = CommonService::httpShenYao($machineInfoApi, $machineInfoData);
		$tmp = [];
		if ($machineInfo['code'] === 0) {
			foreach ($machineInfo['data']['channels'] as $key => $value) {
				if ($value['level'] == 4) {
					$tmp['machine_id'] = $machineInfo['data']['id'];
					$tmp['netpoint_id'] = $value['id'];
					return $tmp;
				}
			}
		} else {
			return 0;
		}
	}

	/**
	 * @name 设置默认微信公众号
	 * @author caolei
	 * @time 2018年3月15日
	 * @return json
	 */
	public function actionEditDefault()
	{
		$data = Yii::$app->request->post();
		if ($model = DefaultWechat::findOne(['id' => $data['id']])) {
			$model->updated_time = time();
			$msg = '修改成功';
		} else {
			$model = new DefaultWechat;
			$model->created_time = time();
			$msg = '添加成功';
		}
		if ($model->add($data)) {
			$this->success('', $msg);
		} else {
			$this->error(11000, '失败', $model->getErrors());
		}
	}

	/**
	 * @name 查看微信公众号链接详情
	 * @param  [int] $id [数据库id]
	 * @author caolei
	 * @time 2018年3月15日
	 * @return json
	 */
	public function actionDetail($id)
	{
		$model = new DefaultWechat;
		$resObj = $model->get($id);
		if ($resObj) {
			$this->success($resObj->toArray(), '查询成功');
		} else {
			$this->success([], '数据空');
		}
	}

	/**
	 * @name 删除终端下载二维码指令
	 * @author caolei
	 * @time 2018年3月19日
	 * @return
	 */
	public function actionDeleteOrderDownloadErCode()
	{
		$macAddress = Yii::$app->request->post('mac', '');
		MachineOrder::deleteOrderByMacAddress($macAddress, Yii::$app->params['machineOrder']['downloadWechatErCode']);
	}

	/**
	 * @name 终端批量获取二维码
	 * @author caolei
	 * @time 2018年3月20日
	 * @return json 微信二维码
	 */
	public function actionV2TermianlGetChargeCodeEr()
	{
		try {
			$macAddress = Yii::$app->request->get('mac', '');
			$port = "[1,2,3,4,5,6,7,8]";
			$machineInfo = $this->actionPointIdByMac($macAddress);
			$data = [
				'mac' => $macAddress,
				'port' => $port,
			];
			$model = new NetpointWechat();
			if ($url = $model->getUrlByNetPointId($machineInfo['netpoint_id'])) {
				// CommonService::delMachineOrder($machineInfo['machine_id'], Yii::$app->params['machineOrder']['downloadWechatErCode']);
				if ($res = ChargeLogic::redisBatchChargeCodeEr($macAddress)) {
					return $res;
				}
				return json_encode($this->HttpClient($url, $data, 'post'), JSON_UNESCAPED_UNICODE);
			} else {
				$url = WechatLogic::getDefaultWechat(1);
				return json_encode($this->HttpClient($url, $data, 'post'), JSON_UNESCAPED_UNICODE);
			}
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 根据mac获取设备信息
	 * @return [type] [description]
	 */
	public function actionGetMachineInfoByMacAddress()
	{
		set_time_limit(0);
		$data = CommonService::getAllChannelList(1);
		$channelList = array_column($data, 'id');
		$machineInfo = [];
		foreach ($channelList as $key => $value) {
			$machineInfo = array_merge($machineInfo, CommonService::getAllMachine($value));
		}
		$tmp = ['machineInfoByMacAddress'];
		foreach ($machineInfo as $v) {
			$tmp[] = $v['macAddress'];
			$tmp[] = json_encode($v, JSON_UNESCAPED_UNICODE);
		}
		$redis = Yii::$app->redis;
		$redis->executeCommand('HMSET', $tmp);
	}

	/**
	 * 定时任务获取macAddres的二维码
	 * @return [type] [description]
	 */
	public function actionCotErCode()
	{
		set_time_limit(0);
		$redis = Yii::$app->redis;
		$macAddress = $redis->hkeys('machineInfoByMacAddress');
		foreach ($macAddress as $key => $value) {
			for ($i=1; $i <= 8 ; $i++) {
				$data = ChargeLogic::terminalGetChargeCodeEr($value, $i);
				if ($data === 0) {
					continue;
				}
				$erCodeUrl = json_decode($data, true);
				if ($erCodeUrl['code'] !== 0) {
					continue;
				}
				$redis->hset('machineErCode', $value . "_" . $i, json_decode($data, true)['data'][$i]);
			}
		}
	}

}