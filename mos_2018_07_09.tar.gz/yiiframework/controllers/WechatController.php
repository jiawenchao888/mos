<?php

namespace app\controllers;

use app\models\NewConference;
use app\models\TempSet;
use app\service\CommonService;
use app\logic\WechatLogic;
use yii\data\Pagination;
use yii\db\Query;
use Yii;

class WechatController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * 增加分数
	 * @return
	 */
	public function actionScore()
	{
		$post = Yii::$app->request->post();
		if ($model = NewConference::findOne(['access_token' => $post['access_token']])) {
			$model->score += $post['score'];
			if ($model->save()) {
				return $this->success('', 'success');
			} else {
				return $this->error(15000, $model->getErrors());
			}
		} else {
			return $this->error(15000, 'null');
		}
	}

	/**
	 * 增加新的微信用户
	 * @return
	 */
	public function actionAdd()
	{
		try {
			$post = Yii::$app->request->post();
			if ($model = NewConference::findOne(['access_token' => $post['access_token']])) {
				$data = ['team' => $model->team];
				return $this->success($data, 'success');
			}
			$model = new NewConference;
			if ($model->add($post) && ($team = $model->team($post))) {
				$data = ['team' => $team];
				return $this->success($data, 'success');
			} else {
				return $this->error(15000, 'error' ,$model->getErrors());
			}
		} catch (\ErrorException $exception) {
			return $this->error(11000, 'error',$exception->getMessage());
		}
	}

	/**
	 * @name 根据队伍id添加用户
	 * @return json
	 */
	public function actionAddUserByTeamId()
	{
		try {
			$post = Yii::$app->request->post();
			$redis = Yii::$app->redis;
			if (!($model = NewConference::findOne(['access_token' => $post['access_token']]))) {
				$model = NewConference::findOne($post['id']);
				if ('' !== $model->access_token) {
					return $this->success('', 'success', 4009); //已被签到，无效码
				}
				if ($model->add($post)) {
					//把id入sign缓存中
					$redis->sadd('sign', $post['id']);
					$redis->srem('unsign', $post['id']);
					$data = ['team' => $model->team];
					return $this->success($data, 'success');
				} else {
					$redis->srem('sign', $post['id']);
					$redis->sadd('unsign', $post['id']);
					return $this->error(15000, 'error');
				}
			} else {
				$data = ['team' => $model->team];
				return $this->success($data, 'success', 4008);//您已经签到
			}
		} catch (\ErrorException $exception) {
			return $this->error(11000, 'error',$exception->getMessage());
		}
	}

	/**
	 * @name 分配队伍
	 * @return json
	 */
	public function actionAllotTeam()
	{
		try {
			$data = ['access_token' => ''];
			$redis = Yii::$app->redis;
			//如果请求数量超过30，进行Redis数据的验证发送
			if (($redis->zincrby('mos_new_conference', 1, 'team') > 5) && $team['id'] = $redis->spop('unsign')) {
				$team['team'] = $team['id']%10;
				return $this->success($team, 'success');
			}
			$model = new NewConference;
			if ($model->add($data) && ($team = $model->team($model->id))) {
				return $this->success($team, 'success');
			} else {
				return $this->error(15000, 'error' ,$model->getErrors());
			}
		} catch (\ErrorException $exception) {
			return $this->error(11000, 'error',$exception->getMessage());
		}
	}

	/**
	 * 查询是否存在微信用户
	 * @return json
	 */
	public function actionFind()
	{
		try {
			$access_token = Yii::$app->request->post('access_token', '');
			$result = NewConference::find()->select(['access_token', 'wechat_name', 'head_url'])->where(['access_token' => $access_token])->one();
			if ($result) {
				return $this->success($result, 'success');
			} else {
				return $this->error(15000, 'null' );
			}
		} catch (\ErrorException $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * 队伍分数排行
	 * @return
	 */
	public function actionTeamScore()
	{
		try {
			//查询表中access_token和team
			$res = NewConference::find()->select(['access_token', 'team'])->where(['!=', 'access_token', ''])->asArray()->all();
			//根据access_token查询所有的得分
			$access_token = array_column($res, 'access_token');
			$ad_id = WechatLogic::findAdId();
			$mediaRes = WechatLogic::getScoreByAccessToken($access_token, $ad_id);
			$usr = WechatLogic::getUserInfoByAccessToken($access_token);
			$mediaRes = array_merge($mediaRes, $usr);
			if (empty($mediaRes)) {
				return $this->success('', 'success');
			}
			// var_dump($mediaRes);die;
			//将查询的数据增加一个team  key
			WechatLogic::keyInsert($mediaRes, array_column($res,null, 'access_token'));
			//将team相同的score相加
			$personInfo = WechatLogic::columnAdd($mediaRes, 'team', 'score');
			//根据score进行排序
			WechatLogic::multiSort($personInfo, 'score');
			return $this->success($personInfo, 'success');
		} catch (\ErrorException $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * 单个个人分数排序
	 * @return
	 */
	public function actionSingleScore()
	{
		try {
			//查询mos数据库所有用户的access_token
			$res = NewConference::find()->select(['access_token'])->where(['!=', 'access_token', ''])->asArray()->all();
			$access_token = array_column($res, 'access_token');
			//根据access_token查询所有得分
			$ad_id = WechatLogic::findAdId();
			$mediaRes = WechatLogic::getScoreByAccessToken($access_token, $ad_id);
			$usr = WechatLogic::getUserInfoByAccessToken($access_token);
			$mediaRes = array_merge($mediaRes, $usr);
			if (empty($mediaRes)) {
				return $this->success('', 'success');
			}
			//将id相同的得分相加
			$personInfo = WechatLogic::columnAdd($mediaRes, 'id', 'score');
			//根据分数排序
			WechatLogic::multiSort($personInfo, 'score');
			return $this->success($personInfo, 'success');
		} catch (\ErrorException $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}


	/**
	 * @name 用户列表
	 * @return json
	 */
	public function actionList()
	{
		try {
			$get['page'] = Yii::$app->request->get('page', 1);
			$get['pageSize'] = Yii::$app->request->get('pageSize', 10);
			$model = NewConference::find();//->asArray()->all();
			$count = $model->count();
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $get['pageSize']]);
			$data['list'] = $model->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			$data['paginate'] = self::paginate($get['page'], $get['pageSize'], $count);
			$this->success($data, 'success');
		} catch (\ErrorException $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 用户组信息
	 * @return json
	 */
	public function actionTeam()
	{
		$res = NewConference::find()->asArray()->all();
		$data = WechatLogic::groupByKey($res, 'team');
		return $this->success($data, 'success');
	}

	/**
	 * 将分配到的id入集合到unsign中
	 * @return
	 */
	public function actionIdAdd()
	{
		$postId = Yii::$app->request->post('id', '');
		if (!(Yii::$app->redis->sismember('sign', $postId))){
			if ($res = Yii::$app->redis->sadd('unsign', $postId)){
				return $this->success('', 'success');
			} else {
				return $this->success('用户id已经添加到未签到集合', 'success');
			}
		} else {
			return $this->success('用户id已经签到成功', 'success');
		}
	}

	/**
	 * @name 个人信息
	 * @return
	 */
	public function actionSingleInfo()
	{
		try {
			$post = Yii::$app->request->post();
			//查询mos数据库所有用户的access_token
			$res = NewConference::find()->select(['access_token', 'team'])->where(['!=', 'access_token', ''])->asArray()->all();
			$team = array_column($res, null, 'access_token');
			$access_token = array_column($res, 'access_token');
			//根据access_token查询所有得分
			$ad_id = WechatLogic::findAdId();
			$mediaRes = WechatLogic::getScoreByAccessToken($access_token, $ad_id);
			//查询所有access_token的用户，拼接
			$usr = WechatLogic::getUserInfoByAccessToken($access_token);
			$mediaRes = array_merge($mediaRes, $usr);
			//如果没有数据直接返回“-”
			if (empty($mediaRes)) {
				$data = WechatLogic::disposeEmpty($post['access_token']);
				return $this->success($data, 'success');
			}
			//将id相同的得分相加
			$personInfo = WechatLogic::columnAdd($mediaRes, 'access_token', 'score');
			//获取组的排名
			$teamInfo = WechatLogic::teamRanking($mediaRes, $team);
			//根据分数排序
			WechatLogic::multiSort($personInfo, 'score');
			//获取排名
			$ranking = array_search($post['access_token'], array_keys($personInfo));
			$personInfo[$post['access_token']]['person_ranking'] = $ranking + 1;
			$personInfo[$post['access_token']]['team'] = $team[$post['access_token']]['team'];
			$personInfo[$post['access_token']]['team_score'] = $teamInfo[$team[$post['access_token']]['team']]['score'];
			$personInfo[$post['access_token']]['team_rangking'] = $teamInfo[$team[$post['access_token']]['team']]['team_ranking'];
			return $this->success($personInfo[$post['access_token']], 'success');
		} catch (\ErrorException $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 发布会临时开关按钮
	 * @return 0显示，1关闭
	 */
	public function actionButton()
	{
		$post = Yii::$app->request->post();
		$res = NewConference::findOne(['access_token' => $post['access_token']]);
		$code = TempSet::findOne(1)->switch;
		if ((NULL === $res)) {
			$code = 1;
			return $this->success('', 'success', $code);//code 0显示，1关闭
		}
		return $this->success('', 'success', $code);
	}

	/**
	 * @name 发布会临时设置
	 * @return
	 */
	public function actionTmpSet()
	{
		try {
			$post = Yii::$app->request->post();
			$model = TempSet::findOne($post['id']);
			if (NULL === $model) {
				$model = new TempSet();
			}
			$model->updated_time = time();
			if ($model->add($post)) {
				return $this->success('', 'success');
			} else {
				return $this->error(11000, $model->getErrors());
			}
		} catch (Exception $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 发布会设置列表
	 * @return
	 */
	public function actionSetList()
	{
		try {
			$res = TempSet::findOne(1)->toArray();
			return $this->success($res, 'success');
		} catch (Exception $exception) {
			return $this->error(11000, $exception->getMessage());
		}
	}

}