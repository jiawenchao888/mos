<?php

namespace app\controllers;

use yii;
use app\models\Resource;
use yii\data\Pagination;


/**
 * 妙智旅行app使用接口
 */
class MztripController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 游戏列表
	 * @method post
	 * @author caolei
	 * @time 2017年12月25日
	 * @return [json] [列表]
	 */
	public function actionAppList()
	{
		$request = Yii::$app->request;
		$post['id'] = $request->post('id', '');
		$pageSize = $request->post('pageSize', 20);
		$pageSize = $pageSize > 20 ? 20 : (int)$pageSize;
		$post['page'] = $request->post('page', 1);
		$_GET['page'] = $post['page'];
		$model = Resource::find();
		if ($post['id']) {
			$post['id'] = explode(',', $post['id']);
			$model->where(['id' => $post['id'], 'type' => 3, 'is_deleted' => 0]);
			$count = $model->count();
			$pager = new Pagination(['totalCount'=>$count,'pageSize'=>$pageSize]);
			$res = $model->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			$res = $model->orderBy('id desc')->asArray()->all();
			$data['list'] = $this->disposeData($res);
			$data['paginate'] = self::paginate($post['page'], $pageSize, $count);
			$this->success($data, '列表获取成功');

		} else {
			$model->where(['type' => 3, 'is_deleted' => 0]);
			$count = $model->count();
			$pager = new Pagination(['totalCount'=>$count,'pageSize'=>$pageSize]);
			$res = $model->orderBy('id desc')->asArray()->all();
			$res = $model->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			$data['list'] = $this->disposeData($res);
			$data['paginate'] = self::paginate($post['page'], $pageSize, $count);
			$this->success($data, '列表获取成功');
		}
	}

	/**
	 * @name app的总数
	 * @author caolei
	 * @time 2018年1月7日
	 * @return [type]        [description]
	 */
	public function actionCountByApp()
	{
		$model = Resource::find();
		return $count = $model->where(['type' => 3, 'is_deleted' => 0])->count();
	}

	/**
	 * @name 处理查询出来的数据，展示给app
	 * @param array $res [app列表]
	 * @author caolei
	 * @time 2017年12月25日
	 * @return [json][app列表]
	 */
	public function disposeData($data)
	{
		$res = [];
		foreach ($data as $key => &$value) {
			$value['content'] = json_decode($value['content'], 1);
			$res[$key]['id'] = $value['id'];
			$res[$key]['resource_name'] = $value['resource_name'];
			if (!empty($value['content']['app_platform']['Android']['packageName'])) {
				$res[$key]['package_name'] = $value['content']['app_platform']['Android']['packageName'];
			}
			//out为外网地址，in为内网地址
			$res[$key]['icon_url_out'] = $this->getFullUrl($value['icon_url']);
			// $res[$key]['icon_url_in'] = $this->disposeUrl('mos/api/20171226/20171226163845_5a420a95a4344.png');
			$res[$key]['icon_url_in'] = $this->disposeUrl($value['icon_url']);
			$res[$key]['video_url_out'] = $this->getFullUrl($value['content']['video_url']);
			// $res[$key]['video_url_in'] = $this->disposeUrl('mos/api/20171226/20171226164037_5a420b057d842.mp4');
			$res[$key]['video_url_in'] = $this->disposeUrl($value['content']['video_url']);
			$res[$key]['app_desc'] = $value['content']['app_desc'];
			$res[$key]['app_platform'] = $value['content']['app_platform'];
			if (!empty($value['content']['app_platform']['Android'])) {
				$res[$key]['app_platform']['Android']['apk_url_out'] = $this->getFullUrl($value['content']['app_platform']['Android']['apk_url']);
				// $res[$key]['app_platform']['Android']['package_name'] = $value['content']['app_platform']['Android']['packageName'];
				// $res[$key]['app_platform']['Android']['apk_url_in'] = $this->disposeUrl('mos/api/20171226/20171226164419_5a420be3486f7.apk');
				$res[$key]['app_platform']['Android']['apk_url_in'] = $this->disposeUrl($value['content']['app_platform']['Android']['apk_url']);
			}
			unset($res[$key]['app_platform']['Android']['apk_url']);
			unset($res[$key]['app_platform']['Android']['packageName']);
		}
		return $res;
	}

	/**
	 * @name 处理url,把路径去掉，拼接内网地址
	 * @param string $url [资源路径]
	 * @author caolei
	 * @time 2017年12月27日
	 * @return [type] [description]
	 */
	public function disposeUrl($url)
	{
		return $finalUrl = 'http://192.168.10.230:8089/game' . substr($url, strrpos($url, '/'));
	}

}