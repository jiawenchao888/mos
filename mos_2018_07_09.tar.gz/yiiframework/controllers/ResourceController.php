<?php

namespace app\controllers;

use app\models\Terminal;
use Yii;
use app\models\Resource;
use app\models\ResourceConfig;
use app\service\CommonService;
use app\service\ApkparserService;
use yii\data\Pagination;
use app\commands\Rsa;
use yii\helpers\Url;
use app\logic\ResourceLogic;
use app\service\OrderService;

class ResourceController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 资源添加
	 * @remark 资源添加接口
	 * @author yongkang
	 * @time 2017年09月15日10:32:06
	 * @method post
	 * return json
	 */
	public function actionAddres()
	{
		try {
			$resource = new Resource();
			$data = Yii::$app->request->post();
			//删除给妙智旅行app的资源列表
			$res = Yii::$app->redis->del('appList');
			$resource->updated_time = time();   // 更新时间
			$result = $resource->addRes($data);
			if($result === true){
				$this->success('','素材添加成功');
			} else {
				$this->error(11000,'素材添加失败',$result);
			}
		} catch ( \ErrorException $exception ) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 资源修改
	 * @remark 资源修改接口
	 * @author yongkang
	 * @time 2017年09月15日10:32:06
	 * @method post
	 * return json
	 */
	public function actionEditres()
	{
		//check method
		if(Yii::$app->Request->isPost){
			$data = Yii::$app->request->post();
			//删除给妙智旅行app的资源列表
			Yii::$app->redis->del('appList');
			//通过post / get 获取 素材id
			$resId = $data['id'];

			$resource = Resource::findOne($resId);

			$result = $resource->addRes($data,2);
			//删除素材缓存
			ResourceConfig::del($resId);
			Yii::$app->redis->hdel('resourceConf', "id_{$resId}");
			if($result === true){
				$this->success('','素材修改成功');
			} else {
				$this->error(11000,'素材修改失败'.$result,$result);
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 获取配置文件接口
	 * @remark 获取配置文件接口
	 * @author yongkang
	 * @time 2017年09月18日11:35:21
	 * @method get
	 * return json
	 */
	public function actionGetresconf()
	{
		try {
			$resource = new Resource();
			//获取 id = 1| id = 1,2,3,4
			$id = Yii::$app->request->post('id','');
			$mac = Yii::$app->request->get('mac','');
			//获取配置
			$data = $resource->getResConf($id);
			if($data === false){
				$this->error(11000,'查询失败');
			} else {
				if(empty($data)){
					$data = '';
				}
				//获取成功后 添加终端缓存资源列表
				Terminal::addTerminalbyresconf($id,$mac);
//				$equ_number = Yii::$app->redis->hget('machineIdByMachineMacAddressArrayData', $mac);
				$equ_info = Terminal::getMachineInfoByMac($mac);
				$equ_number = $equ_info['id'];
				CommonService::delMachineOrder($equ_number,'Res_Download_Conf');
				// header("Content-type:application/json;charset=UTF-8");
				// echo json_encode(['code' => 0, 'msg' => '查询成功', 'data' => $data], JSON_FORCE_OBJECT);
				$this->success($data,'查询成功');
			}
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 素材详情审核 ,内部审核
	 * @remark 素材详情审核,内部审核接口
	 * @author caolei
	 * @time 2017年9月15日10:22:28
	 * @method get
	 * @return
	 */
	public function actionLay()
	{
		if(Yii::$app->Request->isGet){
			$get['id'] = Yii::$app->request->get('id','');
			$get['status'] = Yii::$app->request->get('status','');
			$get['userId'] = Yii::$app->request->get('user_id','');
			$get['matter'] = Yii::$app->request->get('matter','');
			$get['result'] = Yii::$app->request->get('result','');
			$get['typeMatter'] = '内部审核';
			$model = Resource::findOne($get['id']);
			$model->lay_status = $get['status'];
			if($model->save()){
				$this->actionAudit($get['userId'],$get['id'],$get['typeMatter'],$get['matter'],$get['result']);
				$this->success('','素材内部审核成功');
			} else {
				$this->error(11000,'素材内部审核失败',$model->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}

	}

	/**
	 * @name 素材详情审核 ,资源审核
	 * @remark 素材详情审核,资源审核接口
	 * @author caolei
	 * @time 2017年9月15日11:58:08
	 * @method get
	 * @return
	 */
	public function actionRes()
	{
		if(Yii::$app->Request->isGet){
			$get['id'] = Yii::$app->request->get('id','');
			$get['status'] = Yii::$app->request->get('status','');
			$get['userId'] = Yii::$app->request->get('user_id','');
			$get['matter'] = Yii::$app->request->get('matter','');
			$get['result'] = Yii::$app->request->get('result','');
			$get['typeMatter'] = '资源审核';
			$model = Resource::findOne($get['id']);
			$model->res_status = $get['status'];
			if($model->save()){
				$this->actionAudit($get['userId'],$get['id'],$get['typeMatter'],$get['matter'],$get['result']);
				$this->success('','素材资源审核成功');
			} else {
				$this->error(11000,'素材资源审核失败',$model->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 素材列表
	 * @author caolei
	 * @time 2017年9月19日09:55:54
	 * @method get
	 * @return [json]
	 */
	public function actionList()
	{
		if(Yii::$app->Request->isGet){
			$request = Yii::$app->request;
			$get['id'] = $request->get('id', '');
			$get['type'] = $request->get('type', '');
			$get['version'] = $request->get('version', '');
			$get['lay'] = $request->get('lay', '');
			$get['res'] = $request->get('res', '');
			$get['is_short'] = $request->get('is_short', '');
			$get['is_deleted'] = $request->get('is_deleted', 0);
			$get['page'] = $request->get('page', '');

			$model = Resource::find();
			if(empty($get)){
			} else {
				if(is_numeric($get['id'])){
					$model->andWhere('id=:id',[':id' => $get['id']]);
				} else {
					$model->andfilterWhere(['type' => $get['type'],'version' => $get['version'],'lay_status' => $get['lay'],'res_status' => $get['res']])->andfilterWhere(['like','resource_name',$get['id']]);
				}
			}
			$count = $model->andWhere(['is_deleted' => $get['is_deleted']])->count();
			$pageSize = Yii::$app->params['pageSize']['resource'];
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
			//如果传递page参数，进行分页查询，如果没有传递page参数就查询所有
			if($get['page']){
				$data['list'] = $model->andWhere(['is_deleted' => $get['is_deleted']])->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			} else {
				$data['list'] = $model->andWhere(['is_deleted' => $get['is_deleted']])->orderBy('created_time desc')->asArray()->all();
			}
			$data['list'] = $this->actionListJsonToArray($data['list'],$get['is_short']);
			$data['paginate'] = self::paginate($get['page'],$pageSize,$count);
			$this->success($data,'素材列表查询成功');
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 将素材列表中的json数据转换成数组
	 * @param  [json] $data    [列表数据]
	 * @param  [int] $isShort [是否要短地址]
	 * @return [type]          [description]
	 */
	public function actionListJsonToArray($data,$isShort)
	{
		//将查询出来的数据进行处理
		//content 为json数据，转换成数组输出前端
		foreach($data as $key => &$value){
			$value['content'] = json_decode($value['content'],true);
			//处理contact_app
			if (!empty($value['content']['contact_app'])) {
				$value['content']['contact_app'] = $this->getFullUrl($value['content']['contact_app']);
			}
			//处理apk_url
			if (!empty($value['content']['app_platform']['Android']['apk_url'])) {
				$value['content']['app_platform']['Android']['apk_url'] = $this->getFullUrl($value['content']['app_platform']['Android']['apk_url']);
			}
			//将带有url地址，请求接口获取完整路径输出前端
			$value['icon_url'] = $this->getFullUrl($value['icon_url']);
			foreach($value['content'] as $k => &$v){
				if((substr($k,-3) == 'url') && !empty($v)){
					$v = $this->getFullUrl($v);
				}
				if (substr($k,-3) == 'md5') {
					unset($value['content'][$k]);
				}
			}
			if (isset($value['content']['set_list'])) {
				foreach($value['content']['set_list'] as $kk => &$vv){
					isset($vv['cover_url'])?$vv['cover_url'] = $this->getFullUrl($vv['cover_url']):0;
					isset($vv['detail_url'])?$vv['detail_url'] = $this->getFullUrl($vv['detail_url']):0;
					isset($vv['effect_res'])?$vv['effect_res'] = $this->getFullUrl($vv['effect_res']):0;
					isset($vv['mp3'])?$vv['mp3'] = $this->getFullUrl($vv['mp3']):0;
					// if (isset($vv['cover_url'])) {
					// 	$vv['cover_url'] = $this->getFullUrl($vv['cover_url']);
					// }
					// if (isset($vv['detail_url'])) {
					// 	$vv['detail_url'] = $this->getFullUrl($vv['detail_url']);
					// }
					unset($vv['cover_url_md5']);
					unset($vv['detail_url_md5']);
				}
			}
			unset($value['md5_file']);
		}
		return $data;
	}

	/**
	 * @name 获取操作记录
	 * @author caolei
	 * @time 2017年10月17日15:40:59
	 * @return [type] [description]
	 */
	public function actionGetoperaterecord()
	{
		$get['id'] = Yii::$app->request->get('id',52);
		$get['page'] = Yii::$app->request->get('page',1);
		$data = ['projectName' => 'mos','showNum' => Yii::$app->params['pageSize']['operateRecord'],'page' => $get['page'],'data2' => '素材','data3' => $get['id'],'field' => 'id, type, user_id, matter, time, data1'];
		$res = $this->operateLog($data,$type = 1);
		//根据用户id查询用户名
		$userApi1 = Yii::$app->params['apiBaseList']['apiUserGetDataById'];
		foreach($res['data'] as $key => &$value){
			$userArr = ['userId' => $value['userId']];
			$userName = CommonService::httpShenYao($userApi1,$userArr);
			$value['userId'] = $userName['data']['name'];
		}
		$api = Yii::$app->params['apiBaseList']['apiOtherLogCount'];
		$arr = ['projectName' => 'mos','data2' => '素材','data3' => $get['id']];
		$count = CommonService::httpShenYao($api,$arr);
		$temp['list'] = $res['data'];
		$temp['paginate'] = self::paginate($get['page'],Yii::$app->params['pageSize']['operateRecord'],$count['data']);
		$this->success($temp,'获取操作记录成功');
	}

	/**
	 * @name 素材删除,删除未审核的素材，del=1
	 * @remark 素材删除接口
	 * @author caolei
	 * @time 2017年9月21日09:56:58
	 * @method get
	 * @return [json] [description]
	 */
	public function actionDel()
	{
		try{
			if(Yii::$app->request->isGet){
				//删除给妙智旅行app的资源列表
				Yii::$app->redis->del('appList');
				$get = Yii::$app->request->get('id');
				$model = new Resource();
				if($model->delRes($get)){
					$this->success('','素材删除成功');
				} else {
					$this->error('11000','素材删除失败');
				}
			} else {
				$this->error(10001,'请求方式错误');
			}
		}catch(\Exception $e){
			$this->error(15000,'内部错误',$e->getMessage());
		}
	}

	/**
	 * @name 素材删除，删除已经审核的，del=2
	 * @author caolei
	 * @time 2017年12月13日13:47:44
	 * @methor get
	 * @return [json]
	 */
	public function actionDelAudit()
	{
		try {
			if (Yii::$app->request->isGet) {
				//删除给妙智旅行app的资源列表
				Yii::$app->redis->del('appList');
				$get = Yii::$app->request->get('id');
				$model = new Resource();
				if ($model->delRes($get, 2)) {
					$this->success('', '素材删除成功');
				} else {
					$this->error('11000', '素材删除失败');
				}
			} else {
				$this->error(10001, '请求方式错误');
			}
		} catch (\Exception $e) {
			$this->error(15000, '内部错误', $e->getMessage());
		}
	}

	/**
	 * @name 素材恢复
	 * @author caolei
	 * @time 2017年12月13日14:40:40
	 * @methor get
	 * @return [type] [description]
	 */
	public function actionRestore()
	{
		try {
			if (Yii::$app->request->isGet) {
				//删除给妙智旅行app的资源列表
				Yii::$app->redis->del('appList');
				$get = Yii::$app->request->get('id');
				$model = new Resource();
				if ($model->restore($get)) {
					$this->success('', '素材恢复成功');
				} else {
					$this->error('11000', '素材恢复失败');
				}
			} else {
				$this->error(10001, '请求方式错误');
			}
		} catch (\Exception $e) {
			$this->error(15000, '内部错误', $e->getMessage());
		}
	}

	/**
	 * @name 素材终端缓存情况查询
	 * @remark 素材终端缓存情况查询接口
	 * @author caolei
	 * @time 2017年9月21日09:32:57
	 * @return [type] [description]
	 */
	public function actionCachelist()
	{
		try {
			$get['id'] = Yii::$app->request->get('id','');
			$model = Resource::find();
			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['resource'];
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
			if(empty($get['id'])){
				$resource = $model->where(['lay_status' => 1,'res_status' => 1])->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->all();
			} else {
				if(is_numeric($get['id'])){
					$resource = $model->orderBy('created_time desc')->offset($pager->offset)->where(['lay_status' => 1,'res_status' => 1,'id' => $get['id']])->limit($pager->limit)->all();
				} else {
					$resource = $model->orderBy('created_time desc')->offset($pager->offset)->where(['lay_status' => 1,'res_status' => 1])->andwhere(['like','resource_name',$get['id']])->limit($pager->limit)->all();
				}
			}
			$data['list'] = \yii\helpers\ArrayHelper::toArray($resource);
			$get['page'] = empty($get['page']) ? 1 : $get['page'];
			$data['paginate'] = self::paginate($get['page'],$pageSize,$count);
			$this->success($data,'素材列表查询成功');
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 发布内网获取设备
	 * @remark 发布内网获取设备接口
	 * @author caolei
	 * @time 2017年9月21日17:06:59
	 * @return [type] [description]
	 */
	public function actionGetmachine()
	{
		if(Yii::$app->Request->isGet){
			//上海channelid 392
			$count = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineCountByChannelId'], ['channelId' => 392]);
			$response = CommonService::getAllMachineListByChannelId($count['data']['totalCount'], 392);
			if($response){
				$this->success($response,'设备获取成功');
			} else {
				$this->error(11000,'设备获取失败');
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 素材审核 ,保存备注的信息
	 * @author caolei
	 * @time 2017年10月10日09:14:34
	 * @return [type] [description]
	 */
	public function actionAudit($userId,$resId,$typeMatter,$matter,$result)
	{
		try{
			$data = [
				'projectName' => 'mos',
				'controllerName' => Yii::$app->controller->id,
				'actionName' => Yii::$app->controller->action->id,
				'type' => 'insert', //新增=insert、更新=update、删除=delete
				'userId' => $userId,
				'matter' => $result." : ".$matter,
				'data1' => $typeMatter, //操作类型
				'data2' => '素材', //资源类型
				'data3' => $resId, //资源类型对应的id
				'time' => time(),
			];
			return $log = $this->operateLog($data);
		}catch(\Exception $e){
			$this->error(12001,'内部错误',['line' => $e->getLine(),'message' => $e->getMessage()]);
		}
	}

	/**
	 * @name 查看日志 查看操作素材的日志
	 * @author caolei
	 * @time 2017年10月11日16:00:52
	 * @type post
	 * @return [type] [description]
	 */
	public function actionLog()
	{
		try{
			$get['id'] = Yii::$app->request->post('id','');
			$get['res_id'] = Yii::$app->request->post('res_id',61);
			$data = [
				'userId' => $get['id'],
				'projectName' => 'mos',
				'data2' => '素材', //资源类型
				'data3' => $get['res_id'], //资源类型对应的id
			];
			if(empty($get['id'])){
				unset($data['userId']);
			}
			return $log = $this->operateLog($data,$type = 1);
		}catch(\Exception $e){
			$this->error(12001,'内部错误',['line' => $e->getLine(),'message' => $e->getMessage()]);
		}
	}

	/**
	 * @name 根据id获取应用名称
	 * @author caolei
	 * @param $id int 对应素材的id
	 * @time 2017年11月1日16:25:08
	 * @return [type] [description]
	 */
	public function actionAppnameById()
	{
		if(Yii::$app->request->isPost){
			$post['id'] = Yii::$app->request->post('id','');
			$model = new Resource();
			if($res = $model->details($post['id'])){
				//进行数据加密
				$config = [
					'publicKey' => Yii::$app->params['key']['publicKey'],
					'privateKey' => Yii::$app->params['key']['privateKey'],
				];
				$key = new Rsa($config);
				$res['data'] = $key->encrypt($res['resource_name']);
				$this->success($res['data'],'success');
			} else {
				$this->error(10001,'未查询到数据');
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 根据id获取素材列表信息，wifi项目用，查询少量字段
	 * @author yongkang
	 * @time 2017年11月16日14:18:49
	 * @param  num $id [素材的id]
	 * @param $delRedis integer 如果为2 重新给redis赋值
	 * @return json
	 */
	public function actionWifiResList($delRedis=1)
	{
		$request = Yii::$app->request;
		$id = explode(',',$request->get('id',''));
		$planid = explode(',',$request->get('planid',''));

		$res = Resource::find()->select(['id','resource_name','icon_url','content'])->where(['id' => $id])->asArray()->all();
		foreach($res as $key => $value){
			$result = Yii::$app->redis->hget('wifiResConf','id_'.$value['id']);
			if(empty($result)||$delRedis==2){
				$list = [
					'id' => $value['id'],
					'resource_name' => $value['resource_name'],
					'icon_url'  => $value['icon_url'],
//					'icon_url1' => 'http://mos.datuhongan.com/'.$value['icon_url'],
//					'icon_url0' => 'http://192.168.10.230:8089/game/'.$value['icon_url'],
					// 'icon_url' => $this->getFullUrl($value['icon_url']),
				];
				$content = json_decode($value['content'],true);
				if(!empty($content['app_platform']['Android'])){
					$arr = explode('/',$content['app_platform']['Android']['apk_url']);
					//apk_url0 内网
					$list['app_platform']['Android']['apk_url0'] =  'http://192.168.10.230:8089/game/'.$arr[count($arr) - 1];
					//apk_url1 外网
					$list['app_platform']['Android']['apk_url1'] =  $this->getFullUrl($content['app_platform']['Android']['apk_url']);
					$list['app_platform']['Android']['size'] = $content['app_platform']['Android']['size'];
					$list['app_platform']['Android']['apk_md5'] =  $content['app_platform']['Android']['apk_md5'];
				}
				$result = json_encode($list);
				Yii::$app->redis->hset('wifiResConf','id_'.$value['id'],$result);
			}

			$list = json_decode($result,1);
			$list['redirt']= Yii::$app->request->hostInfo.':8089/browser/redirt.html?adid='.$value['id'].'&planid='.$planid[$key];
			$list2[] = $list;
		}

		$data['list'] = $list2;

		$data['android_error'] = Yii::$app->request->hostInfo.':8089/browser/android';
		$data['apple_error'] = Yii::$app->request->hostInfo.':8089/browser/apple';
		if($data){
			$this->success($data,'success');
		} else {
			$this->error(10001,'查询失败');
		}
	}

	/**
	 * @name 素材立即发布
	 * @author caolei
	 * @time 2018年3月20日
	 * @return json 方圆接口返回数据
	 */
	public function actionResourceReset()
	{
		$resId = Yii::$app->request->post('res_id', '');
		$resId = explode(',', $resId);
		$tmp = [];
		foreach ($resId as $key => $value) {
			$res = ResourceLogic::resetTerminalResConf($value);
			if (0 !== $res['code']) {
				$tmp[] = $res;
			}
		}
		if ($tmp) {
			return $this->error(1, array_column($tmp, 'msg')[0]);
		} else {
			$this->success('', 'success');
		}
	}

	/**
	 * @name 重下素材
	 * @author caolei
	 * @time 2018年3月21日
	 * @return
	 */
	public function actionResourceResetDownload()
	{
		$machineId = Yii::$app->request->post('machine_id', '');
		$resId = Yii::$app->request->post('res_id', '');
		$machineIdArr = explode(',', $machineId);
		$resIdArr = explode(',', $resId);
		if (count($machineIdArr) !== count($resIdArr)) {
			return $this->error(1, '传递的参数不对称');
		}
		$combineArr = array_combine($machineIdArr, $resIdArr);
		$tmp = [];
		foreach ($combineArr as $key => $value) {
			$res = ResourceLogic::resourceResetDownload($key, $value);
			if ($res['code'] !== 0) {
				$tmp[] = $res;
			}
		}
		if ($tmp) {
			return $this->error(1, 'error', array_column($tmp, 'msg'));
		} else {
			$this->success('', 'success');
		}
	}

	/**
	 * @name 投放计划立即发布
	 * @author caolei
	 * @time 2018年3月21日
	 * @return
	 */
	public function actionPlanReset()
	{
		$planId = Yii::$app->request->post('plan_id', '');
		$planIdArr = explode(',', $planId);
		$tmp = [];
		foreach ($planIdArr as $key => $value) {
			$res = ResourceLogic::planReset($value);
			if (0 !== $res['code']) {
				$tmp[] = $res;
			}
		}
		if ($tmp) {
			return $this->error(1, 'error', array_column($tmp, 'msg'));
		} else {
			$this->success('', 'success');
		}
	}

	/**
	 * @name 同步投放计划
	 * @author caolei
	 * @time 2018年3月21日
	 * @return
	 */
	public function actionSyncPlan()
	{
		$machineId = Yii::$app->request->post('machine_id', '');
		$planId = Yii::$app->request->post('plan_id', '');
		$machineIdArr = explode(',', $machineId);
		return json_encode(OrderService::syncPlan($machineIdArr, $planId));
	}

	/**
	 * 外审状态修改接口
	 * @return [type] [description]
	 */
	public function actionOutAudit()
	{
		$get['resId'] = Yii::$app->request->get('res_id', '');
		$get['status'] = Yii::$app->request->get('status', '');

		$model = Resource::findOne($get['resId']);
		$model->res_status = $get['status'];
		if ($model->save()) {
			$this->success('', 'success');
		} else {
			$this->error(11000, 'error');
		}
	}

}