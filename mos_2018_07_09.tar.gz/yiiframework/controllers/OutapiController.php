<?php

namespace app\controllers;

use app\models\Resource;
use app\service\CommonService;
use Yii;

class OutapiController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name下载应用信息统计，统计外网下载,
	 * source => outnet为外网
	 * @author caolei
	 * @time 2017年11月3日09:20:43
	 * @return [json] [请求接口的返回值]
	 */
	public function actionCountCreateDownload()
	{
			//根据mac地址查询mac信息
			//二期终端机器会将machindId传递进来，下面9行代码在二期就可以删了
			$request = Yii::$app->request;
			$machineInfoApi = Yii::$app->params['apiBaseList']['apiMachineMacAddress'];
			$machineInfoData = [
				"macAddress" => $request->post('mac', ''),
			];
			$machineInfo = CommonService::httpShenYao($machineInfoApi, $machineInfoData);
			if (0 !== $machineInfo['code']) {
				echo json_encode($machineInfo);
				die;
			}
			//将终端提交的数据入库
			$data = [
				"machineId" => $machineInfo['data']['id'],
			    "adId" => $request->post('adid', ''),
			    "planId" => $request->post('planid', ''),
			    "startTime" => time(),
			    "source" => $request->post('source', 'outerNet'),
			    "mobileOs" => $request->post('os', 'undefined'),
			];
			$api = Yii::$app->params['apiBaseList']['apiCountCreateDownload'];
			$res = CommonService::httpShenYao($api, $data);
			echo json_encode($res, JSON_UNESCAPED_UNICODE);
	}

	/**
	 * @name   统计扫码次数,
	 * $typId  为1000-2000之内的数字，1100表示为外网扫码下载统计
	 * $key    投放计划
	 * $value1 存储其他获取到的信息如操作系统等等
	 * $value2 素材id
	 * $dataId machineId
	 * @author caolei
	 * @time 2017年11月22日09:22:14
	 * @return
	 */
	public function actionCountCreate()
	{
		//$this->layout = false;
		//根据mac地址查询mac信息
		//二期终端机器会将machindId传递进来，下面9行代码在二期就可以删了
		$request = Yii::$app->request;
		$machineInfoApi = Yii::$app->params['apiBaseList']['apiMachineMacAddress'];
		$machineInfoData = [
			"macAddress" => $request->post('mac', ''),
		];
		$machineInfo = CommonService::httpShenYao($machineInfoApi, $machineInfoData);
		if (0 !== $machineInfo['code']) {
			echo json_encode($machineInfo);
			die;
		}
		//将终端提交的数据入库
		$data = [
			"dataId" => $machineInfo['data']['id'],
		    "typeId" => 1100,
		    "key" => $request->post('planid', ''),
		    "date" => date('Ymd', time()),
		    "value1" => $this->osToInt($request->post('os', 'undefined')),//1 安卓，2 ios ,3其他
		    "value2" => $request->post('adid', ''),
		];
		$api = Yii::$app->params['apiBaseList']['apiCountCreate'];
		$res = CommonService::httpShenYao($api, $data);
		echo json_encode($res, JSON_UNESCAPED_UNICODE);
	}

	/**
	 * @name 系统转化数字,1 安卓，2 ios, 3 其他
	 * @param $os 手机系统
	 * @return [int] [操作系统对应的数字]
	 */
	public function osToInt($os)
	{
		switch ($os) {
			case 'android':
				return 1;
				break;
			case 'ios':
				return 2;
				break;
			default:
				return 3;
				break;
		}
	}

	/**
	 * @name 根据广告主查询素材
	 * @author caolei
	 * @time 2017年11月28日11:29:09
	 * @return json 相关的素材列表
	 */
	public function actionResByAdvOwnerId()
	{
		$get['adv_owner'] = explode(',', Yii::$app->request->get('id', '1'));
		$model = Resource::find();
		$list = $model->select(['id', 'icon_url', 'resource_name'])->where(['adv_owner' => $get['adv_owner']])->asArray()->all();
		var_dump($list);

	}
}