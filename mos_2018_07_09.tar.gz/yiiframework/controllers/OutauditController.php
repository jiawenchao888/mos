<?php

namespace app\controllers;

use Yii;
use yii\data\Pagination;
use app\models\OutAudit;
use app\common\Common;


class OutauditController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 添加外审
	 * @return [type] [description]
	 */
	public function actionAdd()
	{
		$data = Yii::$app->request->post();
		$model = new OutAudit;
		if ($model->add($data)) {
			if ($data['auditor_remind']) {
				Yii::$app->redis->hset('sendEmail', $data['auditor_id'], $data['auditor_email']);
			}
			$this->success('', '添加成功');
		} else {
			$this->error(11000, $model->getErrors());
		}
	}

	/**
	 * @name 重审
	 * @return [type] [description]
	 */
	public function actionEdit()
	{
		$get['res_id'] = Yii::$app->request->get('res_id', '');
		$created_time = OutAudit::getMaxCreateTime($get['res_id']);
		$data = OutAudit::findOne(['res_id' => $get['res_id'], 'created_time' => $created_time])->toArray();
		if ($data) {
			$this->success($data, 'success');
		} else {
			$this->error(11000, 'error');
		}
	}

	/**
	 * @name 外审详情
	 * @return [type] [description]
	 */
	public function actionDetail()
	{
		$get['resId'] = Yii::$app->request->get('res_id', '');
		$created_time = OutAudit::getMaxCreateTime($get['resId']);
		$model = new OutAudit;
		if ($data = $model->detail($get['resId'], $created_time)) {
			$this->success($data, 'success');
		} else {
			$this->error(11000, '查询详情不存在');
		}
	}

	public function actionSendMail()
	{
		set_time_limit(0);
		$redis = Yii::$app->redis;
		$keys = $redis->hkeys('sendEmail');
		foreach ($keys as $value) {
			$email = $redis->hget('sendEmail', $value);
			if (Common::sendMail($email, '有新的物料需要审核')) {
				$redis->hdel('sendEmail', $value);
			}
		}
	}

	public function actionTest()
	{
		Yii::$app->redis->set('dns_domain_mos', 'http://su.bcebos.com/datu-ad/');
	}

}