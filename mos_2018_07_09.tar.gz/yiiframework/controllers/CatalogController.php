<?php
namespace app\controllers;

use app\models\Catalog;
use app\models\Resource;
use yii\data\Pagination;
use Yii;
class CatalogController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name U盘刊例添加
	 * @remark U盘刊例添加
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionAddcatalog()
	{
		//check method
		if(Yii::$app->Request->isPost){
			$model = new Catalog();
			$data = Yii::$app->request->post();
			$result = $model->addCatalog($data);
			if($result === true){
				$this->success('','添加成功');
			} else {
				$this->error(11000,'添加失败',$result);
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name U盘刊例压缩
	 * @remark U盘刊例压缩
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionZipcatalog()
	{
		$id = Yii::$app->request->get('id', '');
		$catalog = Catalog::findOne($id);
		$list_id = explode(',', $catalog->list);
		$zipname = $catalog->zipname;
		$webroot  = Yii::getAlias('@webroot');
		$allfile = $webroot . '/catalog/' . $zipname;
		if(!file_exists($allfile)){
			mkdir($allfile);
			mkdir($allfile.'/filelist');
			mkdir($allfile.'/config');


			$catalog->is_finished = 2;
			$catalog->save();

			//获取 素材的 文件
			$resource = new Resource();
			foreach($resource->getFilelistByResId($list_id) as $key=>$value){
				//判断对应的文件是否存在
				$file = $webroot.'/'.$value;

				if(file_exists($file)){
					$command = 'cp ' . $file . ' ' . $allfile . '/filelist';
					exec($command);
				}else{
					//todo 列出不存在的文件,并记录
				}
			};
			//移动 获取配置文件
			$resource->getConfigByResIdForZip($list_id, $allfile . '/config');

			//生成压缩包
			$password = $catalog->password;
			$command = 'cd ' . $webroot .'/catalog/; zip -rq -P '.$password . ' '. $allfile . '.zip ' . $zipname . '/*';
			exec($command);
			$catalog->is_finished = 1;
			$catalog->save();
			$this->success('','创建成功');

			//修改状态
		}else{
			$this->error(11000,'file exists');
		}
	}


	/**
	 * @name U盘刊例获取配置文件
	 * @remark U盘刊例获取配置文件
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionGetzipconf()
	{
		$id = Yii::$app->request->get('id', '');
		$catalog = Catalog::findOne($id);

		$zipname = $catalog->zipname;
		$webroot  = Yii::getAlias('@webroot');
		$allfile = $webroot.'/catalog/'. $zipname;

		$filepath = $webroot . '/catalog/' . $zipname . '.conf';
		if(empty($catalog->md5)||$catalog->size==0){
			$catalog->size = filesize($allfile . '.zip');
//			$catalog->size = round(filesize($allfile . '.zip') / 1024 / 1024, 2);
			$catalog->md5 = md5_file($allfile.'.zip');
			$catalog->save();
			$data = [
				'id' => $catalog->id,
				'name' =>$catalog->name,
				'zipname' =>$catalog->zipname,
				'type' => 'resource',

			];

//			$data = $this->encrypt(json_encode($data));
//			file_put_contents($filepath,$data);

			$data['secret'] = $this->genertaSecretByArray($data);
			$data['version'] = '';
			file_put_contents($filepath,json_encode($data));
		}

		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.basename($filepath));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		header('Content-Length: ' . filesize($filepath));
		readfile($filepath);
	}

	/**
	 * @name U盘刊例获取详情
	 * @remark U盘刊例获取详情
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionGetzipinfo(){
		$id = Yii::$app->request->get('id','');
		$catalog = Catalog::findOne($id);
		$data = [
			'id' => $catalog->id,
			'password'=>$catalog->password,
			'md5'=>$catalog->md5,
			'zipname' =>$catalog->zipname,
			'name' => $catalog->name,
			'size' => (int)$catalog->size
		];

		$this->success($data,'查询成功');

	}

	/**
	 * @name U盘刊例列表
	 * @author yongkang
	 * @time 2017年9月29日11:22:45
	 * @return  [json]
	 */
	public function actionZiplist()
	{
		if (Yii::$app->Request->isGet) {
			$get['idname'] = Yii::$app->request->get('idName', '');
			$get['page'] = Yii::$app->request->get('page', 1);
			$model = Catalog::find()->where(['is_deleted'=>0]);

			if (!empty($get)) {
				$model->andWhere([
					'or',
					['like', 'id', $get['idname']],
					['like', 'name', $get['idname']],
				]);
			}

			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['zip'];
			$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
			$data['list'] = $model->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
			$this->success($data, '刊例列表查询成功');
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name U盘刊例编辑
	 * @author yongkang
	 * @time 2017年9月29日15:22:01
	 * @return [type] [description]
	 */
	public function actionEditcatalog()
	{
		//check method
		if(Yii::$app->Request->isPost){
			$data = Yii::$app->request->post();
			//$model = Catalog::find($data['id']);
			$model = new Catalog();
			$result = $model->editCatalog($data);
			if($result === true){
				$this->success('', '编辑成功');
			} else {
				$this->error(11000, '编辑失败', $result);
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name U盘刊例删除
	 * @author caolei
	 * @time 2017年9月29日17:18:33
	 * @return json
	 */
	public function actionDel()
	{
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get('id', '');
			$model = new Catalog();
			if ($model->delCatalog($get)) {
				$this->success('', '删除成功');
			} else {
				$this->error(11000, '删除失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

}