<?php
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\rest\ActiveController;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\Cors;
use yii\helpers\Json;
use yii\helpers\ArrayHelper;
use yii\httpclient\Client;
use app\commands\Rsa;
use app\service\CommonService;

/**
 * @class_name 公共 Common
 */
class CommonController extends Controller
{
	/**
	 * 设置跨域
	 * @author Lili Zhang <ruoge3s@gmail.com>
	 */
	public function init()
	{
		// 设置允许跨域请求
		$header = yii::$app->response->headers;
		$header->add('Access-Control-Allow-Origin', '*');
		$header->add('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,HEAD,DELETE');
		$header->add('Access-Control-Allow-Credentials:', 'true');
	}

    /**
     * 成功返回消息
     * @author shenyao
     * @param array $data 返回数据
     * @param string $msg 提示内容
     * @param string $code 提示内容
     * @return json 输出json消息
     */
    public function success($data = '', $msg = 'success', $code = 0)
    {
        $this->asJson([
                    'code' => $code,
                    'msg' => $msg,
                    'data' => $data
                ]);
    }

    /**
     * 错误返回消息
     * @author shenyao
     * @param string $code 提示内容
     * @param string $msg 提示内容
     * @param array $data 返回数据
     * @return json 输出json消息
     */
    public function error($code = 1, $msg = 'error', $data = '')
    {
        if (Yii::$app->request->get('callback')) { // 参数有callback的话则是jsonp
            Yii::$app->response->format = \yii\web\Response::FORMAT_JSONP;
            Yii::$app->response->data = [
                'data' => [
                    'code' => $code,
                    'msg' => $msg,
                    'data' => $data
                ],
                'callback' => Yii::$app->request->get('callback')
            ];
            return Yii::$app->response;
        } else {
            if ( defined ( 'YII_ENV' ) && YII_ENV != 'prod' ) {
                $this->asJson([
                    'code' => $code,
                    'msg' => $msg,
                    'data' => $data
                ]);
            } else {
                $this->asJson([
                    'code' => $code,
                    'msg' => $msg,
                ]);
            }
        }
        //Yii::$app->response->format = Yii\web\Response::FORMAT_JSON;
        //$data = !is_array($data) && !empty($data) ? array($data) : $data;
        //方法1
        /*$result = array(
            'code'    => $code,
            'msg'     => $msg,
            'data'          => $data
        );
        echo Json::encode($result);exit;*/
        /*//方法2
        return [
            'code'    => $code,
            'msg'     => $msg,
            'data'          => $data
        ];*/
        //方法2
        /*Yii::$app->response->data = array(
            'code' => $code,
            'msg' => $msg,
            'data' => $data
        );
        return Yii::$app->response;*/
    }

    /**
     * 分页
     * @author shenyao
     * @param [int] $current_page 当前页（注意：Yii默认第一页的当前页为0）
     * @param [int] $page_size 每页数量
     * @param [int] $record_count 总记录数
     * @return array
     */
    public static function paginate($current_page = '', $page_size = '', $record_count = 0)
    {
        $current_page = $current_page ? $current_page : 0;
        $page_size = $page_size ? $page_size : 3;
        return [
            'current_page' => $current_page,//当前页
            'page_size' => $page_size,//每页条数
            'record_count' => intval($record_count),//总记录数
            'page_count' => intval(ceil($record_count / $page_size))//分页总数
        ];
    }

    /**
     * 下划线转驼峰
     * @author shenyao
     * @param [string] $str 需要转换的字符串
     * @return string|array
     */
    public function underlineToHump($str)
    {
        $str = preg_replace_callback('/([-_]+([a-z]{1}))/i', function($matches) {
            return strtoupper($matches[2]);
        }, $str);

        return $str;
    }

    /**
     * 驼峰转下划线
     * @author shenyao
     * @param [string] $str 需要转换的字符串
     * @return string
     */
    public function humpToUnderline($str) {
        $str = preg_replace_callback('/([A-Z]{1})/', function($matches) {
            return '_'.strtolower($matches[0]);
        }, $str);

        return $str;
    }

    /**
     * 系统加密方法
     * @author shenyao
     * @param  string $data 要加密的字符串
     * @param  string $key 加密密钥
     * @param  int $expire 过期时间 单位 秒
     * @return string
     */
    public function encrypt($data, $key = '', $expire = 0)
    {
        $key = md5(empty($key) ? Yii::$app->params['authKey'] : $key);
        $data = base64_encode($data);
        $x = 0;
        $len = strlen($data);
        $l = strlen($key);
        $char = '';

        for ($i = 0; $i < $len; $i++) {
            if ($x == $l) $x = 0;
            $char .= substr($key, $x, 1);
            $x++;
        }

        $str = sprintf('%010d', $expire ? $expire + time() : 0);

        for ($i = 0; $i < $len; $i++) {
            $str .= chr(ord(substr($data, $i, 1)) + (ord(substr($char, $i, 1))) % 256);
        }
        return str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode($str));
    }

    /**
     * 系统解密方法
     * @author shenyao
     * @param  string $data 要解密的字符串 （必须是encrypt方法加密的字符串）
     * @param  string $key 加密密钥
     * @return string
     */
    public function decrypt($data, $key = '')
    {
        $key = md5(empty($key) ? Yii::$app->params['authKey'] : $key);
        $data = str_replace(array('-', '_'), array('+', '/'), $data);

        $mod4 = strlen($data) % 4;
        if ($mod4) {
            $data .= substr('====', $mod4);
        }
        $data = base64_decode($data);

        $expire = substr($data, 0, 10);
        $data = substr($data, 10);

        if ($expire > 0 && $expire < time()) {
            return '';
        }
        $x = 0;
        $len = strlen($data);
        $l = strlen($key);
        $char = $str = '';

        for ($i = 0; $i < $len; $i++) {
            if ($x == $l) $x = 0;
            $char .= substr($key, $x, 1);
            $x++;
        }

        for ($i = 0; $i < $len; $i++) {
            if (ord(substr($data, $i, 1)) < ord(substr($char, $i, 1))) {
                $str .= chr((ord(substr($data, $i, 1)) + 256) - ord(substr($char, $i, 1)));
            } else {
                $str .= chr(ord(substr($data, $i, 1)) - ord(substr($char, $i, 1)));
            }
            var_dump($str);
        }

        return base64_decode($str);
    }

    /**
     * 数据签名认证
     * @author shenyao
     * @param  array $data 被认证的数据
     * @return string 签名
     */
    public function dataAuthSign($data)
    {
        //数据类型检测
        if (!is_array($data)) {
            $data = (array)$data;
        }
        ksort($data); //排序
        $code = http_build_query($data); //url编码并生成query字符串
        $sign = sha1($code); //生成签名
        return $sign;
    }

    /**
     * 随机码
     * @author shenyao
     * @param  int $length 长度
     * @param  int $numeric 是否只是数字
     * @return string
     */
    public function randomCode($length, $numeric = 0)
    {
        //$numeric=1;
        PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
        if ($numeric) {
            $hash = sprintf('%0' . $length . 'd', mt_rand(0, pow(10, $length) - 1));
        } else {
            $hash = '';
            $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
            $max = strlen($chars) - 1;
            for ($i = 0; $i < $length; $i++) {
                $hash .= $chars[mt_rand(0, $max)];
            }
        }
        return $hash;
    }

    /**
     * 将数组转换为JSON格式
     * @author shenyao
     * @param  array $data 数组
     * @param  bool $ischinese 如果为0，则不处理中文，可选参数，默认为1
     * @return json 返回JSON，如果data为空，则返回空
     */
    public function array2json($data, $ischinese = 1)
    {
        if ($data == '') return '';
        if ($ischinese) {
            $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        } else {
            $json = json_encode($data);
        }
        return $json;
    }

    /**
     * 将JSON转换为数组JSON格式
     * @author shenyao
     * @param  json $data JSON
     * @param  bool $ischinese 如果为0，则不处理中文，可选参数，默认
     * @return array 返回数组，如果data为空，则返回空
     */
    public function json2array($data, $ischinese = 1)
    {
        if ($data == '') return '';
        if ($ischinese) {
            $array = json_decode($data, TRUE);
        } else {
            $array = json_decode($data);
        }
        return $array;
    }

    /**
     * 对象转数组（使用get_object_vars返回对象属性组成的数组）
     * @author shenyao
     * @param  obj $obj 对象
     * @param  string $input 需要转换的编码
     * @param  string $output 转换后的编码
     */
    public function object2array($obj)
    {
        $arr = is_object($obj) ? get_object_vars($obj) : $obj;
        if (is_array($arr)) {
            return array_map(__FUNCTION__, $arr);
        } else {
            return $arr;
        }
    }

    /**
     * 数组转对象
     * @author shenyao
     * @param  array /string $arr 数组
     */
    public function array2object($arr)
    {
        if (is_array($arr)) {
            return (object)array_map(__FUNCTION__, $arr);
        } else {
            return $arr;
        }
    }

    /**
     * 对数据进行编码转换
     * @author shenyao
     * @param  array /string $data 数组
     * @param  string $input 需要转换的编码
     * @param  string $output 转换后的编码
     */
    public function array_iconv($data, $input = 'gbk', $output = 'utf-8')
    {
        if (!is_array($data)) {
            return iconv($input, $output, $data);
        } else {
            foreach ($data as $key => $val) {
                if (is_array($val)) {
                    $data[$key] = array_iconv($val, $input, $output);
                } else {
                    $data[$key] = iconv($input, $output, $val);
                }
            }
            return $data;
        }
    }

    /**
     * 解析XML格式的字符串
     * @author shenyao
     * @param  string $str 需要解析的xml数据
     * @return 解析正确就返回解析结果,否则返回false,说明字符串不是XML格式
     */
    public static function xmlParser($str)
    {
        $xmlParser = xml_parser_create();
        if (!xml_parse($xmlParser,$str,true)) {
            xml_parser_free($xmlParser);
            return false;
        } else {
            return (json_decode(json_encode(simplexml_load_string($str)),true));
        }
    }



    /**
     * @name http请求
     * @author caolei
     * @param $api string 请求的接口
     * @param $data array 发送的数据
     * @param $type 请求的类型
     * @return 根据请求的接口返回
     */
    public static function HttpClient($api, $data, $type)
    {
        $client = new Client();
        $response = $client->createRequest()
            ->setMethod($type)
            ->setUrl($api)
            ->setData($data)
            ->send();
        if ($response->isOk) {
            return $data = $response->data;
        }
        return false;
    }

    /**
     * @name http提交文件请求
     * @author caolei
     * @param $api string 请求的接口
     * @param $data array 发送的数据
     * @param $type 请求的类型
     * @return 根据请求的接口返回
     */
    public function HttpClienFileUp($api, $data, $type, $file, $path)
    {
        $client = new Client();
        $response = $client->createRequest()
            ->setMethod('post')
            ->setUrl($api)
            ->setData($data)
            ->addFile($file, $path)
            ->send();
        if ($response->isOk) {
            return $data = $response->data;
        }
        return false;
    }

    /**
     * @name 对接受的数组增加维度
     * @author caolei
     * @param string $table 要入库的表名
     * @param array 要增加维度的数组
     * @return [type] [description]
     */
    public function arrUp($table,$arr)
    {
        $newArr[$table] = $arr;
        // foreach ($arr as $key=>$v) {
        //     $newArr[$table][$key] = $v;
        // }
        return $newArr;
    }

	/**
	 * @name 通过拼接文件地址,来生成md5
	 * @remark 通过拼接文件地址,来生成md5
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return string
	 */
	public static function makeMd5File($filename){
		// 网站根目录
		$webroot = Yii::getAlias('@webroot') . '/';
		if(file_exists($webroot . $filename)){
			return md5_file($webroot . $filename);
		}
		return '';
	}


    /**
     * @name 获取浮点数的位数
     * @author caolei
     * @time 2017年9月25日18:08:30
     * @param  [float] $num [需要获取位数的浮点数]
     * @return [int]      [浮点数的位数]
     */
    public function getFloatLength($num) {
        $count = 0;
        $temp = explode ( '.', $num );
        if (sizeof ( $temp ) > 1) {
            $decimal = end ( $temp );
            $count = strlen ( $decimal );
        }
        return $count;
    }

    /**
     * @name 更改浮点数为整数
     * @author caolei
     * @time 2017年9月25日18:08:30
     * @param  [array] $arr [需要转换的数组]
     * @return [array]      [转换后的数组]
     */
    public function changeFloatToInt($arr)
    {
        $data = [];
        foreach ($arr as $key => $value) {
            $data[] = $this->getFloatLength($value);
        }
        $max = max($data);
        if ($max > 0) {
            foreach ($arr as $key => &$value) {
                $value = $value*pow(10, $max);
            }
        }
        return $arr;
    }

    /**
     * @name 根据概率计算中奖奖品
     * @param array 奖品数组 '奖品名'=>'中奖权重'
     * @author caolei
     * @time 2017年9月25日18:08:30
     * @return string 中奖的奖品
     */
    public function getRand($proArr) {
        $result = '';
        $proArr = $this->changeFloatToInt($proArr);
        //概率数组的总概率精度
        $proSum = array_sum($proArr);
        //概率数组循环
        foreach ($proArr as $key => $proCur) {
            $randNum = mt_rand(1, $proSum);
            if ($randNum <= $proCur) {
                $result = $key;
                break;
            } else {
                $proSum -= $proCur;
            }
        }
        unset ($proArr);
        return $result;
    }


    /**
     * @name 公钥加密
     * @author caolei
     * @time 2017年9月26日17:26:57
     * @return [type] [description]
     */
    public function keyEncrypt($str)
    {
	    $webroot = Yii::getAlias('@webroot') . '/../';
        $public_key = file_get_contents(Yii::$app->params['key']['publicKey']);

        $pu_key = openssl_pkey_get_public($public_key);

        // 加密数据
        $encrypted = '';

        openssl_public_encrypt($str, $encrypted, $pu_key);//公钥加密
        $encrypted = base64_encode($encrypted);// base64传输
        return $encrypted;
    }

    /**
     * @name 私钥解密
     * @author caolei
     * @time 2017年9月26日17:25:52
     * @param  [type] $encrypted [description]
     * @return [type]            [description]
     */
    public function keyDecrypt($encrypted)
    {
	    $webroot = Yii::getAlias('@webroot') . '/../';
        $private_key = file_get_contents(Yii::$app->params['key']['privateKey']);
        $pi_key =  openssl_pkey_get_private($private_key);
        $decrypted = '';

        openssl_private_decrypt(base64_decode($encrypted), $decrypted, $pi_key);//私钥解密
        return $decrypted;
    }

    /**
     * @name 获取应用授权码
     * @time 2017年9月26日17:26:03
     * @author caolei
     * @return [type] [description]
     */
    public function getToken()
    {
        if ($accessToken = Yii::$app->redis->get('accessToken')) {
            return $accessToken;
        } else {
            $config = [
                'publicKey' => Yii::$app->params['key']['publicKey'],
                'privateKey' => Yii::$app->params['key']['privateKey'],
            ];
            $key = new Rsa($config);
            // 加密数据
            $data = [
                'appSecret' => Yii::$app->params['appSecret'],
            ];
            $encrypted = $key->encrypt($data);
            $arr = ['data' => $encrypted, 'appId' => Yii::$app->params['appId']];
            $api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiUserGetAccessToken'];
            $res = $this->HttpClient($api, $arr, 'post');
            $token = $key->decrypt($res['data']);
            Yii::$app->redis->set('accessToken', $token['accessToken']);
            Yii::$app->redis->expireat('accessToken', $token['expire']);
            return $accessToken = Yii::$app->redis->get('accessToken');
        }
    }

    /**
     * @name 老版本的获取图片全路径
     * @time 2017年9月28日14:47:36
     * @author caolei
     * @param $url string  objectKey地址
     * @return string
     */
    public function getFullUrlOld($url)
    {
        $config = [
            'publicKey' => Yii::$app->params['key']['publicKey'],
            'privateKey' => Yii::$app->params['key']['privateKey'],
        ];
        $key = new Rsa($config);
        $data = [
            'objectKey' => $url,
            'bucketName' => 'datu-ad',
            'expire' => -1,
        ];
        $url_encrypted = $key->encrypt($data);
        $url_data = [
            'appId' => Yii::$app->params['appId'],
            'accessToken' => $this->getToken(),
            'data' => $url_encrypted,
        ];
        $url_api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileGetFileUrl'];
        $url_res = $this->HttpClient($url_api, $url_data, 'post');
        if (0 === $url_res['code']) {
            return $key->decrypt($url_res['data']);
        } else {
            return $url_res['msg'];
        }
    }

    /**
     * @name 新版本的获取图片全路径
     * @time 2017年9月28日14:47:36
     * @author caolei
     * @param $url string  objectKey地址
     * @return string
     */
    public function getFullUrl($url)
    {
        if ($fullUrl = Yii::$app->redis->get('fullUrl')) {
            return $fullUrl . $url;
        } else {
            $config = [
                'publicKey' => Yii::$app->params['key']['publicKey'],
                'privateKey' => Yii::$app->params['key']['privateKey'],
            ];
            $key = new Rsa($config);
            $data = [
                'objectKey' => $url,
                'bucketName' => 'datu-ad',
                'expire' => -1,
            ];
            $url_encrypted = $key->encrypt($data);
            $url_data = [
                'appId' => Yii::$app->params['appId'],
                'accessToken' => $this->getToken(),
                'data' => $url_encrypted,
            ];
            $url_api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileGetFileUrl'];
            $url_res = $this->HttpClient($url_api, $url_data, 'post');
            if (0 === $url_res['code']) {
                $fullUrl = $key->decrypt($url_res['data']);
                //将域名截取并存入redis
                $strlenth = strpos($fullUrl, 'mos/api/');
                $domainUrl = substr($fullUrl, 0, $strlenth);
                Yii::$app->redis->set('fullUrl', $domainUrl);
                Yii::$app->redis->set('dns_domain_mos', $domainUrl);
                Yii::$app->redis->expire('fullUrl', 30);
                return $fullUrl;
            } else {
                return $url_res['msg'];
            }
        }
    }

    /**
     * @name 获取数据库入库所有错误信息
     * @author caolei
     * @time 2017年9月30日17:13:38
     * @param $arr array 报错数组
     * @return [string] [报错字符串]
     */
    public function getFullError($arr)
    {
        $str = '';
        foreach ($arr as $key => $value) {
            $str .= $value[0] . ',';
        }
        return $str;
    }

    /**
     * @name 存储，查询操作日志
     * @author caolei
     * @time 2017年10月10日10:12:02
     * @param $type 为空执行存储，不为空执行查询
     * @param $arr array 提交给接口的数据
     * @return json
     */
    public function operateLog($arr,$type = '')
    {
        if ($type) {
            $api = Yii::$app->params['apiBaseList']['aipOtherLogList'];
        } else {
            $api = Yii::$app->params['apiBaseList']['apiOtherRecordLog'];
        }
        $res = CommonService::httpShenYao($api, $arr);
        if (0 == $res['code']) {
            return $res;
        }
        return false;
    }

    public function genertaSecretByArray($arr,$key = '')
    {
	    $key = md5(empty($key) ? Yii::$app->params['authKey'] : $key);
	    $str = '';
		foreach($arr as $k=>$value){
			$str .= $k.$value;
		}
		$str .= $key;
	    return md5($str);
    }

    /**
     * @name 根据statu的数字设置数字
     * @author caolei
     * @time 2017年10月10日10:12:02
     * @param $status int 状态值
     * @return string 状态值对应的状态结果
     */
    public function setStatus($status)
    {
        switch ($status) {
            case '1':
                return '成功';
                break;
            case '2':
                return '下载中';
            case '5':
                return '已删除';
            default:
                return '参数错误';
                break;
        }
    }

}
