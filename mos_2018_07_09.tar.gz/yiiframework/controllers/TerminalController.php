<?php

namespace app\controllers;

use app\models\Resource;
use app\models\Terminal;
use app\models\TerminalLog;
use app\models\Plan;
use app\models\PlanMachine;
use app\service\TerminalService;
use app\service\CommonService;
use app\service\CurlService;
use app\service\OrderService;
use yii\data\Pagination;
use app\commands\Rsa;
use app\logic\ResourceLogic;
use app\logic\TerminalLogic;
use Yii;

class TerminalController extends CommonController
{
	public $enableCsrfValidation = false;
	public $db2;

	public function init() {
		parent ::init();
		$this -> db2 = \Yii::$app->db2;
	}


	/**
	 * @name 终端素材状态情况终端素材状态情况添加接口资源添加接口 单接口
	 * @author yongkang
	 * @time 2017年09月15日10:32:06
	 * @method post
	 * return json
	 */
	public function actionAddterminalsingle()
	{
		try{
		if(Yii::$app->request->isPost){
			$data = Yii::$app->request->post();
			$result = Terminal::addTerminalsingle($data);
			if($result === true){
				$this->success('','终端记录添加成功');
			} else {
				$this->error(11000,'添加失败',$result);
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
		}catch(\Exception $e){
			$this->error(15000, $e->getMessage());
		}

	}

	/**
	 * @name 终端素材状态情况终端素材状态情况添加接口资源添加接口 多个
	 * @author yongkang
	 * @time 2017年09月15日10:32:06
	 * @todo 优化 - 数据量过大,时间超时
	 * @method post
	 * return json
	 */
	public function actionAddterminalarray()
	{
		try{
			//check method
			if(Yii::$app->request->isPost){
				$data = Yii::$app->request->post();
				$terminal = new Terminal();
				$result = $terminal->addTerminalarray($data);
				if($result === true){
					$this->success('', '素材更新成功');
				} else {
					$this->error(11000, '更新失败',$result);
				}
			} else {
				$this->error(10001, '请求方式错误');
			}
		}catch(\Exception $e){
			$this->error(15000, $e->getMessage());
		}
	}

	/**
	 * @name 上传终端下载资源日志
	 * @remark 终端素材返回状态接口
	 * @author caolei
	 * @time 2017年9月20日11:41:27
	 * @method post
	 * @return [json]
	 */
	public function actionAddreslog()
	{
		try {
			$post = yii::$app->request->post();
			$data = $this->arrUp('TerminalLog',$post);

			$api = Yii::$app->params['domainList']['domain'].Yii::$app->params['apiBaseList']['apiMachineMacAddress'];
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			$mac = [
				'macAddress' => $data['TerminalLog']['mac']
			];
			$encrypted = $key->encrypt($mac);
			$mac_data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $this->getToken(),
				'data' => $encrypted,
			];

			$res = $this->HttpClient($api,$mac_data,'post');
			$res_d = $key->decrypt($res['data']);
			if($res['code']){
				$this->error('11000','添加失败',$res);
				return;
			} else {
				$data['TerminalLog']['equ_number'] = $res_d['id'];
			}
			$model = new TerminalLog;
			unset($data['TerminalLog']['mac']);
			if($model->add($data)){
				$this->success('','添加成功');
			} else {
				$this->error('11000','添加失败',$model->getErrors());
			}

		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 终端下载日志资源查询
	 * @remark 终端下载日志资源查询接口
	 * @author caolei
	 * @time 2017年9月20日16:12:15
	 * @return [json] [description]
	 */
	public function actionLoglist()
	{
		try {
			$get = Yii::$app->request->post();
			$model = TerminalLog::find();
			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['terminallog'];
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
			$log = $model->offset($pager->offset)->limit($pager->limit)->all();
			$data['list'] = \yii\helpers\ArrayHelper::toArray($log);
			$get['page'] = empty($get['page']) ? 1 : $get['page'];
			$data['paginate'] = self::paginate($get['page'],$pageSize,$count);
			$this->success($data,'终端下载日志列表查询成功');
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 终端缓存状态资源查询
	 * @remark 终端缓存状态资源查询接口
	 * @author caolei
	 * @time 2017年9月21日15:32:06
	 * @return [number] 状态
	 */
	public function actionCachestatus()
	{
		try {
			$post = Yii::$app->request->post();
			$model = Terminal::find();
			$data = $model->select('status')->where(['res_id' => $post['resid'], 'type' => $post['type']])->asArray()->all();
			$this->success($data, '终端缓存状态资源查询成功');
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 根据素材id获取设备的情况
	 * @remark 根据素材id获取设备的情况
	 * @author yongkang
	 * @time 2017年09月25日17:07:59
	 * @return array
	 */
	public function actionMachineinfo($id = '')
	{
		//导出excel查询过慢
		set_time_limit(0);

		$requet = Yii::$app->request;
		//素材id
		$res_id = $requet->get('id', '');
		//渠道id
		$channelId = $requet->get('channelid', '');
		//设备类型
		$typeId = $requet->get('typeid','');
		//设备mac地址
		$keyword = $requet->get('keyword','');
		// 类型 2 奖池 1 素材 3mos 4ota
		$type = $requet->get('type',1);
		//状态
		$status = $requet->get('status','');
		//是否是内外网
		$is_internet = $requet->get('is_internet','');
		//是否是要打印excel
		$get['excel'] = $requet->get('excel', '');
		// 判断是否要groupBy
		$groupBy = $requet->get('groupby','');
		$page = $requet->get('page',1);

		$model = Terminal::find();
		if(!empty($channelId)){
			//根据渠道id 获取所有设备id
			// $id = TerminalService::getTerminalMachineListByTerminalId($channelId);老的方法不用了
			$count = CommonService::getMachineCountByChannelId($channelId, $typeId);
			$id = CommonService::getAllMachineListByChannelId($count['data']['totalCount'], $channelId);
			$id = array_column($id,'id');
			$model->andWhere(['equ_number' => $id]);
		}

		if(!empty($keyword)){
			//判断是否是mac
			if(strpos($keyword,':') !== false){
				$result = Terminal::getMachineInfoByMac($keyword);
			}else{
				$result = TerminalService::getTerminalMachineListByTerminalSeriaNo($keyword);
			}
			$model->andWhere(['equ_number' => $result['id']]);
		}
		// 判断是否要groupBy
		if(!empty($groupBy)){
			$model->groupBy($groupBy);
		}
		$model->andFilterWhere(['equ_typeid' => $typeId, 'status' => $status, 'res_id' => $res_id, 'type' => $type]);
		$count = $model->count();
		$pageSize = Yii::$app->params['pageSize']['terminallist'];
		$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
		//如果excel为空，则正常执行
		if (empty($get['excel'])) {
			$terminalList = $model->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit);
		} else {
			//excel不为空，则打印所有数据进行输出excel
			$terminalList = $model->orderBy('created_time desc');
		}
		//处理terminalList,查询方圆接口将完整信息拼接完整展示前端
		$terminalList = $terminalList->asArray()->all();
		$terminalList = $this->jointTerminalListInfo($terminalList);
		$data['paginate'] = self::paginate($page, $pageSize, $count);
		//判断是否要输出excel
		if (empty($get['excel'])) {
			$data['list'] = $terminalList;
			$this->success($data,'搜索成功');
		} else {
			//处理数据，浏览器输出文件流
			$this->exportExcel($terminalList);
		}
	}

	/**
	 * @name 导出excel表
	 * @param [arr] $terminalList [终端列表的数据]
	 * @author caolei
	 * @time 2017年12月20日
	 * @return 输出文件流
	 */
	public function exportExcel($terminalList)
	{
		date_default_timezone_set('PRC');
		foreach ($terminalList as $key => &$value) {
			unset($value['equ_number'], $value['mac_address'], $value['type_name']);
			$value['created_time'] = date('Y-m-d H:i:s', $value['created_time']);
			$value['updated_time'] = date('Y-m-d H:i:s', $value['updated_time']);
			$value['status'] = $this->setStatus($value['status']);
			$value = array_reverse($value);
		}
		$titles = ['serial_no' => '设备编号', 'channels' => '渠道', 'times' => '重置次数', 'status' => '更新状态', 'updated_time' => '完成时间', 'created_time' => '创建时间'];
		array_unshift($terminalList, $titles);
		CommonService::makeExcel('demo.xls',$terminalList);
	}

	/**
	 * @name 将terminal 数据查询方圆拼接完整
	 * @param  [arr] $temeralList [终端列表数据]
	 * @author caolei
	 * @time 2017年12月20日
	 * @return [arr]              [完整信息的终端列表数据]
	 */
	public function jointTerminalListInfo($terminalList)
	{
		foreach($terminalList as $key => $value){
			$info = TerminalService::getTerminalMachineInfoByMachineId($value['equ_number']);

			if($info['channelId'] != 0){
				$terminalList[$key]['channels'] = '';
				foreach($info['channels'] as $k => $v){
					$terminalList[$key]['channels'] .= $v['name'] . '-';
				}
				$terminalList[$key]['channels'] = trim($terminalList[$key]['channels'],'-');
			} else {
				$terminalList[$key]['channels'] = '没有';
			}

			if(!empty($info['serialNo'])){
				$terminalList[$key]['serial_no'] = $info['serialNo']; // 设备编号
			} else {
				$terminalList[$key]['serial_no'] = '没有编号'; // 设备编号
			}

			if(!empty($info['macAddress'])){
				$terminalList[$key]['mac_address'] = $info['macAddress']; // 设备mac
			} else {
				$terminalList[$key]['mac_address'] = '没有mac'; // 设备mac
			}

			if(!empty($info['typeName'])){
				$terminalList[$key]['type_name'] = $info['typeName']; // 设备类型
			} else {
				$terminalList[$key]['type_name'] = '设备类型'; // 设备类型
			}
		}
		return $terminalList;
	}

	/**
	 * @name 根据设备id获取素材详情
	 * @remark 根据设备id获取素材详情
	 * @author yongkang
	 * @time 2017年09月25日17:07:59
	 * @return array
	 */
	public function actionResourcebymachineid()
	{
		if(Yii::$app->Request->isGet){
			try{
				$get['id_name'] = Yii::$app->request->get('id_name','');
				$get['equ'] = Yii::$app->request->get('equ','');
				$get['status'] = Yii::$app->request->get('status','');
				$get['type'] = Yii::$app->request->get('type','');

				$terminal = Terminal::find();
				$model = $terminal->select("{{%terminal}}.res_id, {{%terminal}}.type, {{%resource}}.resource_name as name,{{%resource}}.type as formwork,{{%resource}}.content as huodong, {{%resource}}.award_id as award_id, {{%resource}}.version as version,{{%terminal}}.created_time as start_time, {{%terminal}}.updated_time as end_time, {{%terminal}}.status as status  ")->joinWith(['resource'])->where(['{{%terminal}}.equ_number' => $get['equ'],'{{%terminal}}.type' => $get['type']]);
				if(empty($get['id_name']) && empty($get['status'])){
				} else {
					if(is_numeric($get['id_name'])){
						$model->andWhere(['{{%resource}}.id' => $get['id_name']]);
					} else {
						if(!empty($get['id_name'])){
							$model->andWhere(['like','{{%resource}}.resource_name',$get['id_name']]);
						}
						if(!empty($get['status'])){
							$model->andWhere(['{{%terminal}}.status' => $get['status']]);
						}
					}
				}
				$count = $model->count();
				$pageSize = Yii::$app->params['pageSize']['machineRes'];
				$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
				$data['list'] = $model->orderBy('{{%terminal}}.created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();

				foreach($data['list'] as $key => &$value){
					$value['huodong'] = json_decode($value['huodong'],true);
				}
				$get['page'] = empty($get['page']) ? 1 : $get['page'];
				$data['paginate'] = self::paginate($get['page'],$pageSize,$count);
				$this->success($data,'素材列表查询成功');
			}catch(\Exception $e){
				$this->error(12001,'内部错误: '.'第'.$e->getLine().'行 '.$e->getMessage());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 根据设备id获取素材 ,或者奖池缓存日志
	 * @author caolei
	 * @time 2017年9月28日09:28:40
	 * @return json
	 */
	public function actionLogresbymachineid()
	{
		if(Yii::$app->Request->isGet){
			$get['id'] = Yii::$app->request->get('id','');
			$get['equ'] = Yii::$app->request->get('equ','');
			$get['type'] = Yii::$app->request->get('type','');
			$get['page'] = Yii::$app->request->get('page','');
			if (!empty($get['equ'])) {
				$get['equ'] = explode(',', $get['equ']);
			}
			$model = TerminalLog::find();
			// $model->where(['res_id' => $get['id']])->andFilterWhere(['in', 'equ_number', $get['equ']])->andFilterWhere(['type' => $get['type']]);
			$model->andWhere(['res_id' => $get['id']])->andFilterWhere(['in', 'type', $get['type']])->andFilterWhere(['in', 'equ_number', $get['equ']]);
			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['machineResLog'];
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
			$data['list'] = $model->offset($pager->offset)->limit($pager->limit)->orderBy('time desc')->asArray()->all();
			$data['paginate'] = self::paginate($get['page'],$pageSize,$count);

			$this->success($data,'日志查询成功');
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 根据设备id获取奖池详情
	 * @author caolei
	 * @time 2017年9月28日09:48:01
	 * @return json
	 */
	public function actionJackpotbymachineid()
	{
		if(Yii::$app->Request->isGet){
			$get['id'] = Yii::$app->request->get('id','');
			$get['equ'] = Yii::$app->request->get('equ','');
			$get['status'] = Yii::$app->request->get('status','');
			$get['type'] = Yii::$app->request->get('type','');
			$get['page'] = Yii::$app->request->get('page','');

			$terminal = Terminal::find();
			$model = $terminal->select("{{%terminal}}.res_id, {{%jackpot}}.name as name,{{%jackpot}}.award_list as awards,{{%terminal}}.created_time as start_time, {{%terminal}}.updated_time as end_time, {{%terminal}}.status as status  ")->joinWith(['jackpot'])->where(['{{%terminal}}.equ_number' => $get['equ'],'{{%terminal}}.type' => $get['type']]);
			if(empty($get['id']) && empty($get['status'])){
			} else {
				if(is_numeric($get['id'])){
					$model->andWhere(['{{%jackpot}}.id' => $get['id']]);
				} else {
					if(!empty($get['id'])){
						$model->andWhere(['like','{{%jackpot}}.name',$get['id']]);
					}
					if(!empty($get['status'])){
						$model->andWhere(['{{%terminal}}.status' => $get['status']]);
					}
				}
			}
			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['machineJackpot'];
			$pager = new Pagination(['totalCount' => $count,'pageSize' => $pageSize]);
			$data['list'] = $model->orderBy('{{%terminal}}.created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			foreach($data['list'] as $key => &$value){
				$temp_arr = json_decode($value['awards'],true);
				$value['awards'] = array_column($temp_arr,'name');
			}
			$data['paginate'] = self::paginate($get['page'],$pageSize,$count);
			$this->success($data,'素材列表查询成功');
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 根据条件获取素材状态
	 * @author yongkang
	 * @time 2017年9月28日09:48:01
	 * @return mixed
	 */
	Public function actionGetTerminallStatusByCondition()
	{
		$get['id'] = Yii::$app->request->get('id','');
		$get['equ'] = Yii::$app->request->get('equ','');
		$get['type'] = Yii::$app->request->get('type','');
		$get['page'] = Yii::$app->request->get('page','');
		$result = TerminalService::getTerminalStatusByCondition($get['id'],$get['equ'],$get['type'],$get['page']);
		$this->success($result,'成功');
	}

	/**
	 * @name 铁路局问答接口
	 * @author caolei
	 * @time 2017年12月11日10:59:31
	 * @param $question string 终端发送的问题
	 * @menthod post
	 * @return [type] [description]
	 */
	public function actionRailwayAnswer()
	{
		try {
			$question = Yii::$app->request->post('question', '退票');
			$api = Yii::$app->params['railway']['callAIQuestion'];
			$data = ['question' => $question, 'platform' => 'app', 'user' => 'admin', 'code' => 'AIZNKFZX'];
			$res = $this->HttpClient($api, $data, 'post');
			echo $res[0];
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 根据设备id获取素材详情
	 * @author caolei
	 * @time 2018年3月23日
	 * @return json
	 */
	public function actionGetResListByMachineId()
	{
		$machineId = Yii::$app->request->get('machine_id', '');
		$page = Yii::$app->request->get('page', 1);
		$resTerminal = ResourceLogic::getTerminalResByMachineId($machineId);
		//分页处理
		$count = $resTerminal->count();
		$pager = new Pagination(['totalCount' => $count,'pageSize' => 10]);
		$planInfo = $resTerminal->offset($pager->offset)->limit($pager->limit)
		                ->createCommand()
		                ->queryAll();
		//处理图片全路径
		foreach ($planInfo as $key => &$value) {
			$value['icon_url'] = CommonController::getFullUrl($value['icon_url']);
		}
		$data['paginate'] = self::paginate($page, 10, $count);
		ResourceLogic::disposeRes($planInfo);
		$data['list'] = $planInfo;
		$this->success($data, 'success');
	}

	/**
	 * @name 根据设备id获取投放计划详情
	 * @author caolei
	 * @time 2018年3月26日
	 * @return json
	 */
	public function actionGetPlanListByMachineId()
	{
		$machineId = Yii::$app->request->get('machine_id', '');
		$page = Yii::$app->request->get('page', 1);
		$machineInfo = CurlService::getTerminalMachineInfoByMachineId($machineId);
		if (empty($machineInfo['channels'])) {
			return $this->error(11000,'渠道查询出错');
		} else {
			$channel = array_column($machineInfo['channels'], 'id');
		}
		$machinePlanList = PlanMachine::getPlanByMachineId($machineId)->andWhere(['m.`is_shelves`' => 1])->createCommand($this -> db2)->queryAll();
		$downShelvesMachinePlanList = PlanMachine::getPlanByMachineId($machineId)->andWhere(['m.`is_shelves`' => 2])->createCommand($this -> db2)->queryAll();
		$downShelvesIdList = array_column($downShelvesMachinePlanList, 'plan_id');
		$syncPlanIdList = array_column($machinePlanList, 'plan_id');
		// var_dump($syncPlanIdList);die;
		$planListObj = Plan::planListByArea($channel)->andWhere(['not in', 'p.plan_id', $downShelvesIdList]);
		// 分页处理
		$count = $planListObj->count('*', $this -> db2);
		$pager = new Pagination(['totalCount' => $count,'pageSize' => 10]);
		//根据分页展示数据
		$planInfo = ResourceLogic::getPlanList($planListObj, $machineId, $pager, $this -> db2);
		// var_dump($planInfo);die;
		ResourceLogic::addSyncStatus($planInfo, $syncPlanIdList);
		$data['paginate'] = self::paginate($page, 10, $count);
		$data['list'] = $planInfo;
		$this->success($data, 'success');
	}

	/**
	 * @name 终端缓存同步投放计划
	 * @author caolei
	 * @return json
	 */
	public function actionSyncPlan()
	{
		$machineId = Yii::$app->request->get('machine_id', '');
		$machineInfo = CurlService::getTerminalMachineInfoByMachineId($machineId);
		if (empty($machineInfo['channels'])) {
			return $this->error(11000,'渠道查询出错');
		} else {
			$channel = array_column($machineInfo['channels'], 'id');
		}
		// 查询到投放计划，上架未过期，等级大于5
		$plan = Plan::planListByArea($channel)->createCommand($this -> db2)->queryAll();
		if (empty($plan)) {
			return $this->error(11000, '投放计划查询出错');
		} else {
			$planId = array_column($plan, 'plan_id');
		}
		// 删除之前存在的并且上架的投放计划
		PlanMachine::deleteAll(['machine_id' => $machineId, 'is_shelves' => 1]);
		$tmp = TerminalLogic::addPlanMachine($planId, $machineId, $machineInfo, $channel);
		//计算投放计划是否超过100
		if ($tmp['code'] === 0) {
			//发送心跳指令
			OrderService::syncPlan((array)$machineId);
			$this->success('', 'success');
		} else {
			return $this->error(11000, '投放计划超出100%');
		}
	}


}

