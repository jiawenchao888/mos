<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\UploadForm;
use yii\web\UploadedFile;
use app\models\Award;
use app\models\Apk;
use app\models\Token;
use app\commands\Merge;
use app\commands\Rsa;
use app\models\UploadFile;
use yii\data\Pagination;

class UploadController extends CommonController
{
	public $enableCsrfValidation = false;
	private $_request;

	public function init()
	{
		parent::init();
		$this->_request = Yii::$app->request;
	}

	/**
	 * @name 上传事件之初始化
	 * @return [type] [description]
	 */
	public function actionInitpart()
	{
		if (Yii::$app->Request->isPost) {
			$api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileInitPart'];
			//获取前段传递数据
			$arr = Yii::$app->request->post();
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			//对数据进行加密
			$encrypted = $key->encrypt($arr);
			$accessToken = $this->getToken();
			$data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $accessToken,
				'data' => $encrypted,
			];
			$res = $this->HttpClient($api, $data, 'post');
			//对数据进行解密
			$response = $key->decrypt($res['data']);
			$res['data'] = $response;
			$this->success($response, 'success');
//			echo json_encode($res, JSON_UNESCAPED_UNICODE);
		} else {
			$this->error(10001,'请求方式错误');
		}
	}


	/**
	 * @name 上传事件之分块
	 * @return [type] [description]
	 */
	public function actionUploadpart()
	{
		if (Yii::$app->Request->isPost) {
			$api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileUploadPart'];
			$arr = Yii::$app->request->post();
			//先移动文件文件
			$merge = new Merge($arr['count'], $arr['fileName'], $_FILES['file']['tmp_name'], $arr['partNumber']);
			$merge->moveFile();
			//对提交的数据进行公钥加密
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			$encrypted = $key->encrypt($arr);
			$accessToken = $this->getToken();
			$data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $accessToken,
				'data' => $encrypted,
			];
			$res = $this->HttpClienFileUp($api, $data, 'post', 'file', $merge->filename);
			//对数据进行解密
			$response = $key->decrypt($res['data']);
			$res['data'] = $response;
			$this->success($response, 'success');
			//echo json_encode($res, JSON_UNESCAPED_UNICODE);
		} else {
			$this->error(10001,'请求方式错误');

		}
	}

	/**
	 * @name 上传事件之合并分块
	 * @param  string $value [description]
	 * @return [type]        [description]
	 */
	public function actionCompetepart()
	{
		if (Yii::$app->Request->isPost) {
			$api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileCompetePart'];
			$data = Yii::$app->request->post();
			//对数据进行加密
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			$encrypted = $key->encrypt($data);
			$accessToken = $this->getToken();
			$send_data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $accessToken,
				'data' => $encrypted,
			];
			$res = $this->HttpClient($api, $send_data, 'post');
			//对数据进行解密
			$response = $key->decrypt($res['data']);
			$res['data'] = $response;
			//合并文件
			$merge = new Merge($data['count'], $data['fileName']);
			$filename = explode('/', $res['data']);
			$filename = $filename[count($filename)-1];
			$merge->fileMerge($filename);
			//获取文件完整url
			$data['expire'] = -1;
			$url_encrypted = $key->encrypt($data);
			$url_data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $accessToken,
				'data' => $url_encrypted,
			];
			$url_api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileGetFileUrl'];
			$url_res = $this->HttpClient($url_api, $url_data, 'post');
			$ful_url = $key->decrypt($url_res['data']);

			$res['code'] = 0;
			$res['msg'] = '上传成功';
			$res['url'] = $ful_url;
			 header('Access-Control-Allow-Origin : *');
        		header('Access-Control-Allow-Methods : GET,POST,PUT,PATCH,HEAD,DELETE');
         	header('Access-Control-Allow-Credentials: true');
			echo json_encode($res, JSON_UNESCAPED_UNICODE);
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 上传事件之取消,功能已经完善，有个别小问题，当上传资源小于分隔的大小时，会无法取消。原因，资源太小，无法切割文件。
	 * @return [type] [description]
	 */
	public function actionCancel()
	{
		if (Yii::$app->request->isPost) {
			$api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileAboutPart'];
			//$arr = Yii::$app->request->post();
			//$arr为模拟的数据，生产需要从前端提交接受数据
			$arr = [
				'bucketName' => 'datu-ad',
				'uploadId' => 'c8691c37cc7eb9cdcd25d9472b672aad',
				'objectKey' => 'mos/api/20171009/20171009142932_59db174c28a69.jpg',
				'count' => 10,
				'fileName' => '54816app-debug.apk',
			];
			//删除上传本地的碎片文件
			$merge = new Merge($arr['count'], $arr['fileName']);
			$merge->deleteFileBlob();
			//对提交的数据进行公钥加密
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			$encrypted = $key->encrypt($arr);
			$accessToken = $this->getToken();
			$data = [
				'appId' => Yii::$app->params['appId'],
				'accessToken' => $accessToken,
				'data' => $encrypted,
			];
			$res = $this->HttpClient($api, $data, 'post');
			//对数据进行解密
			$response = $key->decrypt($res['data']);
			$res['data'] = $response;
			echo json_encode($res, JSON_UNESCAPED_UNICODE);
		} else {
			$this->error(10001,'请求方式错误');

		}
	}

	/**
	 * @name 上传文件列表
	 * @author caolei
	 * @time 2017年11月20日09:58:04
	 * @method get
	 * @return [type] [description]
	 */
	public function actionUploadFileList()
	{
		try {
			$get['type'] = $this->_request->get('type', '1');
			$get['name'] = $this->_request->get('name', '');
			$get['page'] = $this->_request->get('page', 1);
			$model = UploadFile::find()->andWhere(['is_deleted' => 0, 'type' => $get['type']])->andFilterWhere(['like', 'name', $get['name']]);
			$count = $model->count();
			$pageSize = $this->actionSetPageSizeByType($get['type']);
			$pager = new Pagination(['totalCount' => $count, 'pageSize' => $pageSize]);
			$fileList = $model->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			foreach ($fileList as $key => &$value) {
				$value['full_url'] = $this->getFullUrl($value['url']);
			}
			$data['list'] = $fileList;
			$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
			$this->success($data, '文件列表查询成功');
		} catch (\Exception $e) {
			$this->error(12001, '内部错误:', ['line' => $e->getLine(), 'message' => $e->getMessage()]);
		}
	}

	/**
	 * @name 根据文件类型确定每页显示个数
	 * 1图片，2视频，3APK
	 * @author caolei
	 * @time 2017年11月27日11:18:29
	 * @return [int]       [列表展示文件个数]
	 */
	public function actionSetPageSizeByType($type)
	{
		switch ($type) {
			case '1':
				return 6;
				break;
			case '2':
				return 4;
				break;
			case '3':
				return 6;
				break;
			default:
				return 10;
				break;
		}
	}

	/**
	 * @name 上传文件保存，编辑
	 * author caolei
	 * @time 2017年11月20日10:34:29
	 * @method post
	 * @return
	 */
	public function actionEdit()
	{
		try {
			$data = $this->_request->post();
			$data['id'] = $this->_request->post('id', '');
			if ($model = UploadFile::findOne($data['id'])) {
				$model->updated_time = time();
				$msg = '修改成功';
			} else {
				$model = new UploadFile;
				$msg = '添加成功';
				$model->created_time = time();
			}
			if ($model->add($data)) {
				$this->success('', $msg);
			} else {
				$this->error(11000, $this->getFullError($model->getErrors()));
			}
		} catch (\Exception $e) {
			$this->error(12001, '内部错误:', ['line' => $e->getLine(), 'message' => $e->getMessage()]);
		}
	}
}
