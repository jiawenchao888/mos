<?php
/**
 * Created by PhpStorm.
 * User: bravo
 * Date: 17/10/2017
 * Time: 10:02 AM
 */
namespace app\controllers;

use app\models\Resource;
use app\models\Terminal;
use \Yii;
use yii\data\Pagination;

/**
	 * 对外api接口
	 */

class ExtapiController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 根据素材id获取素材名称
	 * @author yongkang
	 * @time 2017年09月27日19:11:15
	 * @param array $id id
	 */

	public function actionGetResourceNameById()
	{
		$id = Yii::$app->request->get('rid', '0');

		$resourceName = Resource::findOne($id);
		if(empty($resourceName)){
			$data = '';
		}else{
			$data = $resourceName->resource_name;
		}
		$this->success($data, '查询成功');
	}

	/**
	 * @name 获取素材列表
	 * @author yongkang
	 * @time 2017年09月27日19:11:15
	 * @param array $id id
	 */

	public function actionGetResourceList()
	{

		$get['page'] = Yii::$app->request->get('page', '');
		$field = Yii::$app->request->get('field', 'id,resource_name,content,icon_url');
		$advOwner = Yii::$app->request->get('advowner', '');
		$model = Resource::find()->where(['is_deleted' => 0, 'lay_status'=>1])->andFilterWhere(['adv_owner' => $advOwner]);
		$count = $model->count();
		$pageSize = Yii::$app->params['pageSize']['resource'];
		$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
		//如果传递page参数，进行分页查询，如果没有传递page参数就查询所有
		if ($get['page']) {
			$model = $model->offset($pager->offset)->limit($pager->limit);
		}
		$data['list'] =$model->select($field)->orderBy('created_time desc')->asArray()->all();
		$result = $data['list'];
		foreach($data['list'] as $key => $value){
			$arr = json_decode($value['content'],1);

			$video_time = empty($arr['video_time'])?'0':$arr['video_time'];
			$result[$key]['video_time'] = $video_time;
			$result[$key]['icon'] = $this->getFullUrl($value['icon_url']);
			unset($result[$key]['content']);
		}
		//添加12306,临时添加后面要删除
		$temp = ['id' => -1000, 'resource_name' => '12306智能客服', 'icon_url' => 'mos/api/20180104/20180104164118_5a4de8aee93b6.png', 'video_time' => 12, 'icon' => 'http://su.bcebos.com/datu-ad/mos/api/20180104/20180104164118_5a4de8aee93b6.png'];
		array_unshift($result, $temp);
		$data['list'] = $result;
		$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
		$this->success($data['list'], '素材列表查询成功');
	}

	public function getFullUrl($url)
	{
		return Yii::$app->request->hostInfo . '/' . $url;
	}

	public function actionGetSuccessNumByResource()
	{
		$request = Yii::$app->request;
		$equNum =$request->post('equnum', '');
		$resid =$request->post('resid', '');
		$type =$request->post('type', 1);
		$status = $request->post('status', 1);

		$equNum = explode(',',$equNum);

		$result = Terminal::find()->where([
			'res_id' => $resid,
			'type' => $type,
			'status' => $status,
		])->andFilterWhere(['equ_number'=>$equNum])->count();

		$this->success($result,'成功');
	}
}