<?php

namespace app\controllers;

use app\commands\Rsa;
use app\models\Award;
use app\models\Resource;
use app\models\Terminal;
use app\service\CommonService;
use app\service\CurlService;
use app\service\RedirectService;
use yii\base\Response;
use \Yii;

class RedirectController extends CommonController
{
	/**
	 * @name 领奖域名跳转
	 * @remark 领奖域名跳转
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return null
	 */
	public function actionIndex()
	{
		$secrect = Yii::$app->request->get('secrect','');
		$secrect = str_replace(' ','+',$secrect);

		if(empty($secrect)){
			return 'null';
		}


		$param = Yii::$app->params;
		$config = [
			'publicKey' => $param['key']['selfPublickKey'],
			'privateKey' => $param['key']['privateKey'],
		];
		$Rsa = new Rsa($config);

//		$data = [
//			'mac' => '00:e0:70:25:14:e1',
//			'aid' => 31,
//			'awid' => 31,
//			'planid' => 21,
//			'resid' => 52,
//			'time' => 1507793450
//		];

//		$data = json_encode($data);

//		$pass = $Rsa->shortEncrypt($data);
//		var_dump($pass);
//		die;

		$secrect = $Rsa->shortDecrypt($secrect);
		$secrect = json_decode($secrect,1);

		$machineId = Terminal::getMachineInfoByMac($secrect['mac'])['id'];

		$data = [
			'dataId' => $machineId, // 设备id
			'typeId' => \Yii::$app->params['statisticsList']['acceptThePrizeTypeId'], // 领奖typeid
			'key' => $secrect['aid'], //奖品id
			'value1' => $secrect['planid'], //投放计划id
			'value2' => $secrect['awid'], //奖池id
			'date' => date('Ymd',$secrect['time']) //时间
		];
		$url = $param['apiBaseList']['apiCountCreate'];
		//写入 统计接口

		CurlService::httpShenYao($url,$data);

		$award = $secrect['aid'];

		$awardInfo = Award::findOne($award);
		if(!empty($awardInfo)){
			$url = $awardInfo->url;

			if(strpos($url,'?') !== false){
				$url .= '&';
			} else {
				$url .= '?';
			}

			//sign = md5(aid . macid . planid .time . 1555900b18c641bf)
			$authKey = \Yii::$app->params['authKey'];
			$sign = md5($data['key'].$data['dataId'].$data['value1'].$secrect['time'].$authKey);
			$url .= 'macid='. $data['dataId'] . '&aid=' . $data['key'] . '&planid=' . $data['value1'] . '&time=' . $secrect['time'] . '&sign=' . $sign;

		}else{
			$url = 'https://www.datuhongan.com/';
		}

		// 跳转
		$this->redirect($url);
	}

	/**
	 * @name 二维码域名跳转
	 * @remark 二维码域名跳转
	 * @author yongkang
	 * @time 2017年10月18日10:40:12
	 * @method get
	 * return null
	 */
	public function actionQrCodeRedirect()
	{
		$request = Yii::$app->request;
		$param = Yii::$app->params;
		$url = $request->get('url','');
		$mac = $request->get('mac','');
		$resourceId = $request->get('adid','');
		$planId = $request->get('planid','');
		$time = $request->get('time',time());

		$machineId = Terminal::getMachineInfoByMac($mac)['id'];

		$data = [
			'dataId' => $machineId, // 设备id
			'typeId' => \Yii::$app->params['statisticsList']['QrCodeTypeId'], // 二维码跳转typeid
			'key' => $resourceId, //素材id
			'value1' => $planId, //投放计划id
			'date' => date('Ymd',$time) //时间
		];
		$apiurl = $param['apiBaseList']['apiCountCreate'];
		//写入 统计接口
		CurlService::httpShenYao($apiurl,$data);

		if(!empty($url)){

			if(strpos($url,'?') !== false){
				$url .= '&';
			} else {
				$url .= '?';
			}

//			if(strpos($url,'http') == false){
//				$url = 'http://'.$url;
//			}

			$url .= 'mac=' . $mac . '&id=' . $data['key'] . '&planid=' . $data['value1'];

		}else{
			$url = 'https://www.datuhongan.com/';
		}

//		var_dump($url);
		// 跳转
		$this->redirect($url);
	}


	/*
	 * @name 获取领奖公众号二维码
	 * @remark 获取二维码
	 * @author yongkang
	 * @time 2017年10月18日10:40:12
	 * @method get
	 * return null
	 */
	public function actionGetErweima()
	{
		try {
			$secrect = Yii::$app->request->get('secrect','');
			$secrect = str_replace(' ','+',$secrect);

			$param = Yii::$app->params;
			$config = [
				'publicKey' => $param['key']['selfPublickKey'],
				'privateKey' => $param['key']['privateKey'],
			];
			$Rsa = new Rsa($config);


			$secrect = $Rsa->shortDecrypt($secrect);

			$secrect = json_decode($secrect,1);
			$machineId = Terminal::getMachineInfoByMac($secrect['mac'])['id'];

			$data = [
				'macid' => $machineId, // 设备id
				'aid' => $secrect['aid'], //奖品id
				'planid' => 1, //投放计划id
				'time' => time() //时间
			];
			// 生成 公众号 二维码
			$qrCode = RedirectService::getWxQrCode($data);
			$this->success($qrCode,'二维码获取成功');
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/*
	 * @name 获取推广二维码
	 * @author yongkang
	 * @time 2017年10月18日10:40:12
	 * @method get
	 * return null
	 */
	public function actionGetTuiGuangErCode()
	{
		$request = Yii::$app->request;
		$mac = $request->get('mac', '');
		$planid = $request->get('planid', '');
		$scene = $request->get('scene' ,'tg');
		$resid = $request->get('resid','');

		$url = Yii::$app->redis->hget('resourceContent', 'resId_' . $resid);
		if (!is_null($url)) {
		} else {
			$content = Resource::findOne($resid)->content;
			$url = json_decode($content,1)['tuiguang'];
			Yii::$app->redis->hset('resourceContent', 'resId_' . $resid, $url);
		}
		// 判断是否直接 扫码跳转H5
		if(strpos($url,'http://pan.baidu.com/share/qrcode') !== false){
			$qrCode = $url;
		}else {

			if(!empty($url)){
				$machineId = Terminal::getMachineInfoByMac($mac)['id'];
				$data = [
					'macid' => $machineId,
					'planid' => $planid,
				];
				$qrCode = RedirectService::getWxQrCode2($data,$url,$scene);
			} else {
				$qrCode = '';
			}
		}

		$this->success($qrCode,'二维码获取成功');


//		http://pre-testtravel.datuhongan.com/weixin/qr-code/limit?macid=1&planid=2&scene=tg
	}


	/**
	 * @name 获取抽奖二维码
	 * @author caolei
	 * @time 2017年12月4日11:08:50
	 * @method get
	 * 抽奖的二维码字段  awardCode
	 * @return [json] [二维码的地址]
	 */
	public function actionGetAwardCode()
	{
		try {
			$request = Yii::$app->request;
			$mac = $request->get('mac', '');
			$planid = $request->get('planid', '');
			$scene = $request->get('scene' ,'tg');
			$resid = $request->get('resid','');

			$content = Resource::findOne($resid)->content;

			$url = json_decode($content,1)['award_code'];

			// 判断是否直接 扫码跳转H5
			if(strpos($url,'http://pan.baidu.com/share/qrcode') !== false){
				$qrCode = $url;
			}else {
				//如果传递了二维码图片，则返回上传二维码图片的地址
				if(!empty($url) && (strpos($url, 'mos/api/') !== false)){
					$qrCode = $this->getFullUrl($url);
				} else if (!empty($url)){ //生成微信的二维码地址
					$machineId = Terminal::getMachineInfoByMac($mac)['id'];
					$data = [
						'macid' => $machineId,
						'planid' => $planid,
					];
					$qrCode = RedirectService::getWxQrCode2($data,$url,$scene);
				} else {
					$qrCode = '';
				}
			}
			$this->success($qrCode,'二维码获取成功');
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

}