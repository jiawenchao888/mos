<?php

namespace app\controllers;

use app\commands\STD3Des;
use app\models\Apk;
use app\models\Terminal;
use app\service\TerminalService;
use app\models\Resource;
use app\service\CommonService;
use yii\data\Pagination;
use Yii;

class MosapkController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name mos资源包添加
	 * @remark mos资源包添加
	 * @author yongkang
	 * @time 2017年09月26日14:57:35
	 * @method post
	 * return json
	 */
	public function actionEdit()
	{
		//如果是get提交，就是查询详情
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get('id');
			$model = new Apk();
			$data = $model->details($get);
			if ($data) {
				$this->success($data, '详情查询成功');
			} else {
				$this->error(11000, '详情查询错误');
			}
			return ;
		}


		//如果是post 提交，根据是否传入id进行判断是添加还是修改
		if (Yii::$app->Request->isPost) {
			$post = Yii::$app->request->post();
			$post = $this->arrUp('Apk', $post);
			if (empty($post['Apk']['id'])) {
				$model = new Apk;
				$model->size = filesize($_SERVER['DOCUMENT_ROOT'] . '/' . $post['Apk']['upload_url']);
				$model->md5 = parent::makeMd5File($post['Apk']['upload_url']);
				$model->created_time = time();
				$model->upload_time = time();
				// 生成压缩包开始
				$password = CommonService::generate_password(6);
				$model->zip_password = $password;
				$webroot  = Yii::getAlias('@webroot');

				$confFileNmae = explode('/', $post['Apk']['upload_url']);
				$name = explode('.',end($confFileNmae));
				array_pop($confFileNmae);


				$fileroot = implode('/',$confFileNmae);


				if($post['Apk']['type']=='OTA'||$post['Apk']['type']=='ota'){
					$command = 'cd ' . $webroot .'/'. $fileroot . '/; zip -rq -P '.$password . ' '. $name['0'] . 'ota.zip ' . './'.$name[0]. '.' .$name[1];
					$model->zip_name = $fileroot . '/' . $name[0] . 'ota.zip';

				}else{
					$command = 'cd ' . $webroot .'/'. $fileroot . '/; zip -rq -P '.$password . ' '. $name['0'] . '.zip ' . './'.$name[0]. '.' .$name[1];
					$model->zip_name = $fileroot . '/' . $name[0] . '.zip';
				}
				exec($command);

				// 生成压缩包结束

				$msg = '添加成功';

			} else {
				$model = Apk::findOne($post['Apk']['id']);
				$msg = '修改成功';
			}
			if ($model->add($post)) {
				$this->success('', $msg);
			} else {
				$error = $model->getErrors();
				$this->error(11000, $this->getFullError($error), $model->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name mos资源包列表
	 * @remark mos资源包获取配置文件
	 * @author yongkang
	 * @time 2017年09月26日14:57:35
	 * @method post
	 * return json
	 */
	public function actionList()
	{
		if (Yii::$app->Request->isGet) {
			$request = Yii::$app->request;
			$get['id_name'] = $request->get('id_name', '');
			$get['type'] = $request->get('type', '');
			$get['page'] = $request->get('page', '');
			$get['issue'] = $request->get('issue', '');
			$model = Apk::find();
			if ($get['issue']) {
				$model->andWhere(['is_test' => 1]);
				$get['type'] = 'mos';
			}
			if (empty($get)) {
			} else {
				if (is_numeric($get['id_name'])) {
					$model->andWhere(['id' => $get['id_name']]);
				} else {
					$model->andfilterWhere(['like', 'version', $get['id_name']])->andfilterWhere(['type' => $get['type']]);
				}
			}
			$count = $model->count();
			$pageSize = Yii::$app->params['pageSize']['mos'];
			$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);

			$mos = $model->andWhere(['is_deleted' => 0])->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			//增加全路径
			foreach ($mos as $key => $value) {
				$mos[$key]['mos_url'] = $this->getFullUrl($value['upload_url']);
			}
			$data['list'] = $mos;
			$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
			$this->success($data, '列表查询成功');
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name mos包删除
	 * @time 2017年10月12日14:44:12
	 * @author caolei
	 * @method get
	 * @return [type] [description]
	 */
	public function actionDel()
	{
		if (Yii::$app->request->isGet) {
			$get = Yii::$app->request->get('id', '');
			$model = new Apk();
			if ($model->delApk($get)) {
				$this->success('', '该版本删除成功');
			} else {
				$this->error('11000', '该版本删除失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 发布外网多选
	 * @time 2017年10月16日11:47:31
	 * @author caolei
	 * @method get
	 * @return [type] [description]
	 */
	public function actionMultiMachineOrder()
	{
		set_time_limit(0);
		$get['channel_id'] = Yii::$app->request->get('channel_id', '');
		$get['version_id'] = Yii::$app->request->get('version_id', '');
		//type为设备类型
		$get['type'] = Yii::$app->request->get('type', '');
		//如果传递多个
		$arrChannelId = explode(',', $get['channel_id']);
		$res = [];
		foreach ($arrChannelId as $key => $value) {
			$count = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineCountByChannelId'], ['channelId' => $value, 'typeId' => $get['type']]);
			$temp = $this->getAllMachineListByChannelId($count['data']['totalCount'], $value, $get['type']);
			$res = array_merge($res, $temp);
		}
		$noRepeatMachineId = $this->actionRemoveRepeatMachineId($get['version_id'], $res);

		$err = [];
		//给终端发送指令，并记录没有发送成功的机器
		foreach ($noRepeatMachineId['different'] as $key => $value) {
			$instruct = [
				'machineId' => $value['id'],
				'key' => 'Mos_Download_Conf',
				'value' => $get['version_id'],
				'expired' => 300,
			];
			$arr = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandCreateByManchineId'], $instruct);
			$model = new Terminal();
			if (0 !==$arr['code']) {
				$value['msg'] = $arr['msg'];
				$err[] = $value;
			}
			$data = [
				'res_id' => $get['version_id'],
				'mac' => $value['macAddress'],
				'type' => 3,
				'status' => 5,
				'updated_time' => time()
			];
			//多选发布外网是先入数据库状态5，终端在修改数据
			$model->addTerminalsingle($data);
		}
		$data = ['error' => $err, 'repeat' => $noRepeatMachineId['intersect']];
		$this->success($data, 'success');
	}

	/**
	 * @name 根据渠道id,查询所有的设备列表
	 * @param int $totalCount 列表总数
	 * @param int $channelId 渠道id
	 * @param string $typeId 设备类型
	 * @author caolei
	 * @time 2018年1月4日
	 * @return [type] [description]
	 */
	public function getAllMachineListByChannelId($totalCount, $channelId, $typeId)
	{
		$times = ceil($totalCount / 50);
		$allList = [];
		for ($i = 1; $i <= $times; $i++) {
			$allList = array_merge($allList,  CommonService::getMachineListByChannelId($channelId, $typeId, 50, $i)['data']);
		}
		return $allList;
	}

	/**
	 * @name 筛选发布外网的设备，根据mos的id筛选出来没有没有发布的设备id
	 * @param  int   $versionId [版本id]
	 * @param  array $res       [根据渠道选择的设备id]
	 * @return [array]        [返回已经去除重复id值的数组]
	 */
	public function actionRemoveRepeatMachineId($versionId, $res)
	{
		// 根据versionId,查询已经更新该版本的所有的设备id
		$tempMachineid = Terminal::find()->select(['equ_number'])->where(['type' => 3, 'res_id' => $versionId])->asArray()->all();
		// 获取已经发布过的机器id
		$publishMachineId = array_column($tempMachineid, null, 'equ_number');
		// 后台选择的机器id,处理数组，将equ_number转换id
		$res = $this->disposeEquNumberToId($res);
		$selectMachineId = array_column($res, null,'id');
		// 将已经发布过的机器id，从后台选择的机器id去重
		return [
				'different' => array_diff_key($selectMachineId, $publishMachineId),
			    'intersect' => array_intersect_key($selectMachineId, $publishMachineId),
			];
	}

	/**
	 * @name 处理数组中equ_number字段 ，将equ_number转换id
	 * @param  [array] $data [actionRemoveRepeatMachineId中的$res数组]，当时和前端约定的字段有误，这里处理一下
	 * @return [array]       [转换后的数组]
	 */
	public function disposeEquNumberToId($data)
	{
		if (isset($data[0]['equ_number'])) {
			foreach ($data as $key => &$value) {
				$value['id'] = $value['equ_number'];
			}
		}
		return $data;
	}

	/**
	 * @name 发布外网单选
	 * @time 2017年10月16日14:42:06
	 * @author caolei
	 * @method get
	 * @return [type] [description]
	 */
	public function actionSingleMachineOrder()
	{
		try {
			$post['version_id'] = Yii::$app->request->post('version_id', '');
			$post['type'] = Yii::$app->request->post('type', '');
			$post['mac_msg'] = Yii::$app->request->post('mac_msg', '');
			//different,去除重复的信息，intersect已经发布的信息
			$post['repeat'] = Yii::$app->request->post('repeat', 'different');
			$mac_msg = json_decode($post['mac_msg'], true);
			$noRepeatMachineId = $this->actionRemoveRepeatMachineId($post['version_id'], $mac_msg);
			$err = [];
			foreach ($noRepeatMachineId[$post['repeat']] as $key => $value) {
				$instruct = [
					'machineId' => $value['id'],
					'key' => 'Mos_Download_Conf',
					'value' => $post['version_id'],
					'expired' => 300,
				];
				$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandCreateByManchineId'],$instruct);
				$model = new Terminal();
				if (0 !== $res['code']) {
					$value['msg'] = $res['msg'];
					$err[] = $value;
				}
				$data = [
					'res_id' => $post['version_id'],
					'mac' => $value['mac'],
					'type' => $post['type'],
					'status' => '5',
					'updated_time' => time()
				];
				//单选发布外网，终端请求接口提交数据发布外网入库，状态是5未更新。先入库数据，在修改更新状态
				//多选发布外网是所有更新完毕再提交数据，状态直接就是已更新
				$model->addTimes($value['id'], $post['version_id']);
				$model->addTerminalsingle($data);
			}
			$data = ['error' => $err, 'repeat' => $noRepeatMachineId['intersect']];
			$this->success($data, 'success');
		} catch (\Exception $e) {
			$this->error(15000, '内部错误', ['line' => $e->getLine(), 'message' => $e->getMessage()]);
		}
	}

	/**
	 * @name 更改mos包测试成功状态
	 * @time 2017年10月12日16:23:10
	 * @author caolei
	 * @methor post
	 * @param string $value [description]
	 */
	public function actionChangeteststatus()
	{
		try {
			$request = Yii::$app->request;
			$post['id'] = $request->post('id', '');
			$post['status'] = $request->post('status', '');
			$model = Apk::findOne($post['id']);
			if ($model->is_test == 1) {
				$this->success('', '已经测试成功，不允许修改');
			} else {
				$model->is_test = $post['status'];
				if ($model->save()) {
					$this->success('', '状态修改成功');
				} else {
					$this->error(11000, '请求修改失败', []);
				}
			}
		} catch (Exception $e) {
			$this->error(12001, '内部错误', []);
		}
	}


	/**
	 * @name 获取mos的配置文件
	 * @remark U盘刊例获取配置文件
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionGetMosConf()
	{
		$id = Yii::$app->request->get('id', '');
		$mos = Apk::findOne($id);
		$uploadUrl = $mos->zip_name;
		$filename = explode('.', $uploadUrl);
		$webroot  = Yii::getAlias('@webroot');

		$fileConf = $webroot . '/' .$filename[0] . '.conf';

		if(!file_exists($fileConf)){
			$allfile = $webroot . '/' .$mos->zip_name;

			$mos->zip_size = filesize($allfile);
			$mos->zip_md5 = md5_file($allfile);
			$mos->save();

			$confFileNmae = explode('/', $uploadUrl);
			$confFileNmae2 = explode('.',end($confFileNmae));
//			$name = end($confFileNmae);
			$name = $confFileNmae2[0];
			$data = [
				'id' => $mos->id,
				'name' => $name,
				'zipname' => $name,
				'type' => $mos->type,
			];
			$data['secret'] = $this->genertaSecretByArray($data);
			$data['version']= 'v'.$mos->version;

			file_put_contents($fileConf,json_encode($data));
		}

		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.basename($fileConf));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		header('Content-Length: ' . filesize($fileConf));
		readfile($fileConf);
	}


	/**
	 * @name Mos文件详情
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionGetZipInfo(){

		$id = Yii::$app->request->get('id', '1');
		$mos = Apk::findOne($id);

		if(empty($mos)){
			echo '不存在该mos/ota 请查询请求id是否正常';
			die;
		}

		$uploadUrl = $mos->zip_name;
		$confFileNmae = explode('/', $uploadUrl);
		$confFileNmae2 = explode('.',end($confFileNmae));
		$name = end($confFileNmae);
		$name = explode('.',$name)[0];

		$data = [
			'id' => $mos->id,
			'md5'=> $mos->zip_md5,
			'zipname' => $name,
			'name' => $name,
			'size' => $mos->zip_size,
			'password' => $mos->zip_password
		];

		$this->success($data,'查询成功');
	}

	/**
	 * @name 获取配置文件接口
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
	public function actionGetZipConf()
	{
		try {
			$id = Yii::$app->request->post('id', '1');
			$mac = Yii::$app->request->post('mac','');
			$equ_info = Terminal::getMachineInfoByMac($mac);
			$equ_number = $equ_info['id'];  //设备id

			$mos = Apk::findOne($id);

			$uploadUrl = $mos->zip_name;
			$confFileNmae = explode('/', $uploadUrl);
			$confFileNmae2 = explode('.',end($confFileNmae));
			$name = end($confFileNmae);

			$data = [
				'id' => $mos->id,
				'file' => [
					'md5' => $mos->md5,
					'url' => CommonService::joinFileUrl($mos->upload_url)
					],
				'size' => $mos->size,
				];
			CommonService::delMachineOrder($equ_number, 'Mos_Download_Conf');
			$this->success($data,'查询成功');

		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name mos包 还原
	 * @param  int $id [mos包id]
	 * @author caolei
	 * @method get
	 * @time 2018年3月23日
	 * @return
	 */
	public function actionRestore($id)
	{
		$get = Yii::$app->request->get('id', '');
		$model = new Apk();
		if ($model->restore($get)) {
			$this->success('', '还原成功');
		} else {
			$this->error(11000, '还原失败');
		}
	}

	/**
	 * @name 素材回收站列表
	 * @author caolei
	 * @time 2018年3月23日
	 * @return
	 */
	public function actionRecycleBinList()
	{
		$request = Yii::$app->request;
		$get['id_name'] = $request->get('id_name', '');
		$get['type'] = $request->get('type', '');
		$get['page'] = $request->get('page', '');
		$get['issue'] = $request->get('issue', '');
		$model = Apk::find()->select(['id', 'type', 'version', 'size', 'upload_time', 'upload_url', 'version_explain', 'md5', 'created_time', 'is_test'])->andWhere(['is_deleted' => 1]);
		if ($get['issue']) {
			$model->andWhere(['is_test' => 1]);
			$get['type'] = 'mos';
		}
		if (empty($get)) {
		} else {
			if (is_numeric($get['id_name'])) {
				$model->andWhere(['id' => $get['id_name']]);
			} else {
				$model->andfilterWhere(['like', 'version', $get['id_name']])->andfilterWhere(['type' => $get['type']]);
			}
		}
		$count = $model->count();
		$pageSize = Yii::$app->params['pageSize']['mos'];
		$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);

		$mos = $model->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
		//增加全路径
		foreach ($mos as $key => $value) {
			$mos[$key]['mos_url'] = $this->getFullUrl($value['upload_url']);
		}
		$data['list'] = $mos;
		$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
		$this->success($data, '列表查询成功');
	}

}
