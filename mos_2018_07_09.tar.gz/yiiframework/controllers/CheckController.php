<?php
namespace app\controllers;

use Yii;
use app\models\AuditOperator;
use app\common\Common;
use yii\data\Pagination;

class CheckController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 审核人添加
	 * @author caolei
	 * @time 2018年4月10日
	 * @return [json]
	 */
	public function actionAdd()
	{
		$data = Yii::$app->request->post();
		$model = new AuditOperator;
		if ($model->add($data)) {
			$this->success('', '添加成功');
		} else {
			$this->error(11000, Common::disposeModelError($model->getErrors()));
		}
	}

	/**
	 * @name 审核人列表
	 * @author caolei
	 * @time 2018年4月10日
	 * @return json
	 */
	public function actionList()
	{
		$post['userName'] = Yii::$app->request->post('user_name', '');
		$post['accountNumber'] = Yii::$app->request->post('account_number', '');
		$post['id'] = Yii::$app->request->post('id', '');
		$post['page'] = Yii::$app->request->post('page', 1);
		$auditOperatorObj = AuditOperator::find()->andWhere(['is_deleted' => 0])
												 ->andFilterWhere(['id' => $post['id']])
												 ->andfilterWhere(['like', 'user_name', $post['userName']])
												 ->andFilterWhere(['like', 'account_number', $post['accountNumber']]);
		$pageSize = 10;
		$count = $auditOperatorObj->count();
		$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
		$list = $auditOperatorObj->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
		$data['list'] = $list;
		$data['paginate'] = self::paginate($post['page'], $pageSize, $count);
		$this->success($data, 'success');
	}

	/**
	 * @name 编辑
	 * @return json
	 */
	public function actionEdit()
	{
		$get['id'] = Yii::$app->request->get('id', '');
		$data = Yii::$app->request->post();
		$model = AuditOperator::findOne($get['id']);
		if (empty($get['id']) || empty($model)) {
			return $this->error(11000, 'id为空');
		}
		if ($model->edit($data)) {
			$this->success('', '编辑成功');
		} else {
			$this->error(11000, $model->getErrors());
		}
	}

	/**
	 * @name 详情
	 * @return [type] [description]
	 */
	public function actionDetail()
	{
		$get['id'] = Yii::$app->request->get('id', '');
		if ($model = AuditOperator::findOne($get['id'])) {
			$data = $model->toArray();
			$this->success($data, 'success');
		} else {
			$this->error(11000, '未找到该用户');
		}
	}

	/**
	 * @name 邮箱提醒
	 * @return json
	 */
	public function actionEmailRemind()
	{
		$get['id'] = Yii::$app->request->get('id', '');
		$get['status'] = Yii::$app->request->get('status', 1);
		$model = AuditOperator::findOne($get['id']);
		if ($model) {
			$model->email_remind = $get['status'];
			if ($model->save()) {
				$this->success('', '修改成功');
			} else {
				$this->error(11000, '修改失败');
			}
		} else {
			$this->error(11000, '未找到该用户');
		}
	}

	/**
	 * @name del
	 * @return json
	 */
	public function actionDel()
	{
		$get['id'] = Yii::$app->request->get('id', '');
		$model = AuditOperator::findOne($get['id']);
		if ($model) {
			$model->is_deleted = 1;
			if ($model->save()) {
				$this->success('', '删除成功');
			} else {
				$this->error(11000, '删除失败');
			}
		} else {
			$this->error(11000, '未找到该用户');
		}
	}

}