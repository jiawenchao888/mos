<?php
namespace app\controllers;

use app\commands\Rsa;
use Yii;
use yii\web\Controller;
use app\models\Jackpot;
use app\models\Award;
use app\logic\JackpotLogic;
use yii\data\Pagination;

class JackpotController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 奖池上下架
	 * @remark 奖池上下架接口
	 * @author caolei
	 * @time 2017年9月18日16:18:30
	 * @method get
	 * @return json
	 */
	public function actionIsenable()
	{
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get();
			$model = Jackpot::findOne($get['id']);
			$model->is_enable = $get['status'];
			if ($model->save()) {
				$this->success('', '设置成功');
			} else {
				$this->error(11000, '设置失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 奖池列表查询
	 * @remark 奖池列表接口
	 * @author caolei
	 * @time 2017年9月18日16:40:24
	 * @method get
	 * @return [json] [奖池信息]
	 */
	public function actionList()
	{
		if (Yii::$app->Request->isGet) {
			//奖池
			$get['JIdName'] = Yii::$app->request->get('JIdName', '');
			$get['AIdName'] = Yii::$app->request->get('AIdName', '');
			$get['is_enable'] = Yii::$app->request->get('is_enable', '');
			$get['page'] = Yii::$app->request->get('page', '');
			$model = Jackpot::find();
			if (empty($get)) {
			} else {
				if (is_numeric($get['JIdName'])) {
					$model->andWhere(['id' => $get['JIdName']]);
				} else {
					$model->andFilterWhere(['like', 'name', $get['JIdName']])->andFilterWhere(['like', 'award_list', $get['AIdName']])->andFilterWhere(['is_enable' => $get['is_enable']]);
				}
			}
			$count = $model->andWhere(['is_deleted' => 0])->count();
			$pageSize = Yii::$app->params['pageSize']['jackpot'];
			$pager = new Pagination(['totalCount'=>$count,'pageSize'=>$pageSize]);
			$data['list'] = $model->andWhere(['is_deleted' => 0])->orderBy('id desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			foreach ($data['list'] as $key => &$value) {
				$value['award_list'] = json_decode($value['award_list'], true);
			}
			$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
			$this->success($data, '奖池列表查询成功');
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 奖池添加
	 * @remark 奖池添加接口
	 * @author caolei
	 * @time 2017年9月15日15:09:47
	 * @method post
	 * @return [json] [description]
	 */
	public function actionAdd()
	{
		if (Yii::$app->Request->isPost) {
			$post = Yii::$app->request->post();
			$post = $this->arrUp('Jackpot', $post);
			$model_jackpot = new Jackpot;
			$model_award = new Award;
			//处理award_list
			$award_list = $this->json2array($post['Jackpot']['award_list']);
			$arr = array_keys($award_list);
			//将award_list 奖品设置为已关联
			if ($model_jackpot->add($post) && $model_award->setIsRelevance($arr)) {
				$this->success('', '奖池添加成功');
			} else {
				$this->error(11000, '奖池添加错误', $model_jackpot->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 终端获取资源配置(奖池)
	 * @remark 终端获取资源配置(奖池)接口
	 * @author caolei
	 * @time 2017年9月22日14:31:50
	 * @method post
	 * @return json
	 */
	public function actionGetresconjack()
	{
		try {
			$id = $id = Yii::$app->request->post('id','');
			$data = JackpotLogic::getResConJackPot($id);
			if (!empty($data)) {
	 			$this->success($data, '终端获取资源配置(奖池)成功');
			} else {
				$this->error(11000, '获取失败', []);
			}
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 奖池删除
	 * @remark 奖池删除接口
	 * @time 2017年9月25日16:50:17
	 * @author caolei
	 * @method get
	 * @return [type] [description]
	 */
	public function actionDel()
	{
		if (Yii::$app->request->isGet) {
			$get = Yii::$app->request->get('id');
			$model = new Jackpot();
			if ($model->delJackpot($get)) {
				$this->success('', '奖池删除成功');
			} else {
				$this->error('11000', '奖池删除失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 中奖
	 * @remark 中奖接口
	 * @time 2017年9月25日17:00:55
	 * @author caolei
	 * @method post
	 * @return [type] [description]
	 */
	public function actionPrize()
	{
		$post['id'] = Yii::$app->request->post('id', '');
		$get['secrect'] = Yii::$app->request->post('secrect', '');
		$model = new Jackpot();
		$data = $model->listt($post['id']);
		$data = json_decode($data[0]['award_list'], true);
		$res = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["probability"]; return $res;'));
		//奖品名称对应过期时间
		$res_time = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["end_time"]; return $res;'));
		$award = $this->getRand($res);
		if ($res_time[$award] < time()) {
			$award = 0;
		}
		if ($res) {
			$this->success($award, '中奖接口请求成功');
		} else {
			$this->error(11000, '中奖接口请求失败', []);
		}
	}

	/**
	 * @name 奖池添加，编辑修改
	 * @remark 奖池编辑修改
	 * @time 2017年9月25日18:36:25
	 * @author caolei
	 * @method post
	 * @return [type] [description]
	 */
	public function actionEdit()
	{
		//如果是get提交，就是查询详情
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get('id');
			$model = new Jackpot();
			$data = $model->details($get);
			if ($data) {
				$this->success($data, '奖池详情查询成功');
			} else {
				$this->error(11000, '奖池详情查询错误');
			}
			return ;
		}
		//如果是post 提交，根据是否传入id进行判断是添加还是修改
		if (Yii::$app->Request->isPost) {
			$post = Yii::$app->request->post();
			$post = $this->arrUp('Jackpot', $post);
			//判断是否有id值，有则修改，没有则新增
			if (empty($post['Jackpot']['id'])) {
				$model_jackpot = new Jackpot;
				$msg = '奖池添加成功';
			} else {
				$model_jackpot = Jackpot::findOne($post['Jackpot']['id']);
				$msg = '奖池修改成功';
			}
			//$model_award = new Award;
			// //处理award_list
			// $award_list = $this->json2array($post['Jackpot']['award_list']);
			// $arr = array_column($award_list, 'id');
			//将award_list 奖品设置为已关联  && $model_award->setIsRelevance($arr)
			if ($model_jackpot->add($post)) {
				$this->success('', $msg);
			} else {
				$error = $model_jackpot->getErrors();
				$this->error(11000, $this->getFullError($error), $model_jackpot->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 成功获取奖品后的页面
	 */
	public function actionGetAwardById()
	{
		die;
		$request = Yii::$app->request;
		$authkey = Yii::$app->params['authKey'];
		$id = $request->get('id', 0);
		$awid = $request->get('aid', 0); // 奖池id
		$pid = $request->get('pid', 0); // 投放计划id
		$time = $request->get('time', time()); // 时间
		$mac = $request->get('mac',''); // mac
		$secret = $request->get('secrect', ''); // 密文
		$mysecret = md5($awid.$time.$pid.md5($authkey));


		#10 分钟间隔
//		if($secret!=$mysecret||time()>$time()+600){


		if($secret!=$mysecret){
		    $this->error('404','非法请求');
		    die;
		}

		// 抽奖开始
		$post = $awid;
		$model = new Jackpot();
		$data = $model->listt($post);
		$data = json_decode($data[0]['award_list'], true);
		$res = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["probability"]; return $res;'));
		//奖品名称对应过期时间
		$res_time = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["end_time"]; return $res;'));
		$award = $this->getRand($res);
		if ($res_time[$award] < time()) {
			$award = 0;
		}

		// 抽奖结束

		if($award==0){
			$msg = '抱歉,没中奖';
		}else{
			$jiang = Award::findOne($award);
			$msg = '恭喜你中了'. $jiang->name;
//			var_dump($jiang);
			$secrect =[
				'mac' => $mac,
				'aid' => $award,
				'planid' => $pid,
				'awid' => $awid,
				'time' => $time,
			];

			$param = Yii::$app->params;
			$config = [
				'publicKey' => $param['key']['selfPublickKey'],
				'privateKey' => $param['key']['privateKey'],
			];
			$Rsa = new Rsa($config);
			$secrect = $Rsa->shortEncrypt(json_encode($secrect));


			$url = Yii::$app->request->hostInfo;
			$url .= '/redirect/?secrect=' .$secrect;
			$msg .= ' 领奖连接:'.$url;
		}


		echo $msg;

	}
}
