<?php
namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Award;
use yii\data\Pagination;
use app\service\CommonService;

class AwardController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * @name 奖品添加,修改
	 * @remark 奖品添加接口
	 * @author caolei
	 * @time 2017年9月15日15:09:47
	 * @method post
	 * @return [json] [description]
	 */
	public function actionEdit()
	{
		//如果是get提交，就是查询详情
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get('id');
			$model = new Award();
			$data = $model->details($get);
			if ($data) {
				$this->success($data, '奖品详情查询成功');
			} else {
				$this->error(11000, '奖品详情查询错误');
			}
			return ;
		}

		//如果是post 提交，根据是否传入id进行判断是添加还是修改
		if (Yii::$app->Request->isPost) {
			$post = Yii::$app->request->post();
			$post = $this->arrUp('Award', $post);
			if (empty($post['Award']['id'])) {
				$model = new Award;
				$model->created_time = time();
				$msg = '奖品添加成功';
			} else {
				Yii::$app->redis->del('award_' . $post['Award']['id']);
				$model = Award::findOne($post['Award']['id']);
				$model->updated_time = time();
				$msg = '奖品修改成功';
			}
			if ($model->add($post)) {
				$this->success('', $msg);
			} else {
				$error = $model->getErrors();
				$this->error(11000, $this->getFullError($error), $model->getErrors());
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 奖品详情
	 * @remark 奖品详情接口
	 * @author caolei
	 * @time 2017年9月15日16:45:22
	 * @method get
	 * @param string $value [description]
	 */
	public function actionDetails()
	{
		if (Yii::$app->request->isGet) {
			$model = new Award;
			$get = Yii::$app->request->get('id');
			$data = $model->details($get);

			if ($data) {
				$this->success($data, '奖品详情查询成功');
			} else {
				$this->error(11000, '奖品详情查询失败');
			}
		} else {
			$this->error(10001,'请求方式错误');
		}
	}

	/**
	 * @name 奖品列表查询
	 * @remark 奖品列表接口
	 * @author caolei
	 * @time 2017年9月15日17:55:59
	 * @method get
	 * @return [json] [奖品信息]
	 */
	public function actionList()
	{
		if (Yii::$app->Request->isGet) {
			$get['id'] = Yii::$app->request->get('id', '');
			$get['status'] = Yii::$app->request->get('status', '');
			$get['type'] = Yii::$app->request->get('type', '');
			$get['page'] = Yii::$app->request->get('page', '');
			$model = Award::find();
			if (empty($get)) {
			} else {
				if (is_numeric($get['id'])) {
					$model->andWhere(['id' => $get['id']]);
				} else {
					if (!empty($get['status'])) {
						$model->andWhere([$get['status'], 'end_time', time()]);
					}
					$model->andfilterWhere(['like', 'name', $get['id']])->andfilterWhere(['type' => $get['type']]);
				}
			}
			$count = $model->andWhere(['is_deleted' => 0])->count();
			$pageSize = Yii::$app->params['pageSize']['award'];
			$pager = new Pagination(['totalCount'=>$count, 'pageSize'=>$pageSize]);
			$awards = $model->andWhere(['is_deleted' => 0])->orderBy('created_time desc')->offset($pager->offset)->limit($pager->limit)->asArray()->all();
			//获取每个奖品的完整路径
			foreach ($awards as $key => &$value) {
				$value['full_url'] = $this->getFullUrl($value['img_url']);
			}
			$data['list'] = $awards;
			$data['paginate'] = self::paginate($get['page'], $pageSize, $count);
			$this->success($data, '奖品列表查询成功');
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 奖品删除
	 * @remark 奖品删除接口
	 * @time 2017年10月11日17:21:42
	 * @author caolei
	 * @method get
	 * @return [type] [description]
	 */
	public function actionDel()
	{
		if (Yii::$app->request->isGet) {
			$get = Yii::$app->request->get('id');
			$model = new Award();
			if ($model->delAward($get)) {
				$this->success('', '奖品删除成功');
			} else {
				$this->error('11000', '奖品删除失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	/**
	 * @name 奖品上下架
	 * @remark 奖品上下架接口
	 * @author caolei
	 * @time 2017年9月18日15:54:13
	 * @method get
	 * @return [type] [description]
	 */
	public function actionIsenable()
	{
		if (Yii::$app->Request->isGet) {
			$get = Yii::$app->request->get();
			$model = Award::findOne($get['id']);
			$model->is_enable = $get['status'];
			if ($model->save()) {
				$this->success('', '设置成功');
			} else {
				$this->error(11000, '设置失败', $model->getErrors());
			}
		} else {
			$this->error(10001, '请求方式错误');
		}
	}

	public function actionTest()
	{
		$data = [
			'projectName' => 'mos',
			//'controllerName' => Yii::$app->controller->id,
			//'actionName' => '',
			//'type' => '', //新增=insert、更新=update、删除=delete
			'userId' => 117,
			//'matter' => '',
			//'data1' => '编辑素材', //操作类型
			'data2' => '素材', //资源类型
			//'data3' => '', //资源类型对应的id
			//'time' => '',
			'field' => 'id, type, user_id, matter, time, data1, data2, data3',
		];
		$log = $this->operateLog($data, $type = 1);
		return $log;
	}



}
