<?php

namespace app\controllers;

use app\models\Resource;
use app\service\CommonService;
use Yii;

class BrowserController extends CommonController
{
	public $enableCsrfValidation = false;

	/**
	 * 终端扫码下载h5
	 * @return [type] [description]
	 */
	public function actionApiRes()
	{
			//$this->layout = false;
			$request = Yii::$app->request;
			$get['mac'] = $request->get('mac', '');
			$get['adId'] = $request->get('adid', '');
			$get['planId'] = $request->get('planid', '');
			$get['source'] = $request->get('source', '');
			$get['out'] = $request->get('out', 1);
			//处理url地址
			$model = new Resource();
			$res = $model->details($get['adId']);
			$res['icon_url'] = $this->getFullUrl($res['icon_url']);
			$res['content'] = json_decode($res['content'], true);
			foreach ($res['content'] as $key => $value) {
				if (substr($key, -3) == 'url') {
					$res['content'][$key] = $this->getFullUrl($value);
				}
			}
			if (!empty($res['content']['app_platform']['Android'])) {
				$res['content']['app_platform']['Android']['apk_url'] = $this->getFullUrl($res['content']['app_platform']['Android']['apk_url']);
			}
			$res['android_error'] = '/browser/android';
			$res['apple_error'] = '/browser/apple';
			$data = ['code'=>0, 'msg'=>'success', 'data'=>$res];
			return json_encode($data);
	}

	/**
	 * @name 展示h5页面
	 * @time 2017年11月1日14:12:18
	 * @author caolei
	 * @return [type] [description]
	 */
	public function actionRes()
	{
		$this->layout = false;
		return $this->render('res');
	}

	/**
	 * @name 重定向跳转到h5
	 * @time 2017年11月1日14:12:18
	 * @author caolei
	 * @return [type] [description]
	 */
	public function actionRedirt()
	{
		$request = Yii::$app->request;
		$get['mac'] = $request->get('mac', '');
		$get['adId'] = $request->get('adid', '');
		$get['planId'] = $request->get('planid', '');
		$get['source'] = 'outerNet';
		$get['number'] = $request->get('number','');
		$this->redirect(['/browser/res',
			'adid' => $get['adId'],
			'mac' => $get['mac'],
			'planid' => $get['planId'],
			'source' => $get['source'],
			'number' => $get['number']
		]);
	}

	/**
	 * iOS报错页面
	 * @return [type] [description]
	 */
	public function actionApple()
	{
		return $this->render('apple');
	}

	/**
	 * Android 报错页面
	 * @return [type] [description]
	 */
	public function actionAndroid()
	{
		return $this->render('android');
	}
}