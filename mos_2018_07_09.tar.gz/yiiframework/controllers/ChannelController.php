<?php
namespace app\controllers;

use app\commands\Rsa;
use app\service\ChannelService;
use app\service\CommonService;
use \Yii;
class ChannelController extends CommonController
{


	/**
	 * @name 获取设备类型列表
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public function actionMachineTypeList()
	{
		$data = ChannelService::machineTypeList();
		$this->success($data,'查询成功');
	}

	/**
	 * @name 根据渠道信息获取下面的点位
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public function actionIndexForSearch()
	{
		try {
			$redis = Yii::$app->redis;
			set_time_limit(0);
			if ($temp = $redis->get('ProvinceList')) {
				$result = $temp;
			}else{
				$result = $this->recursionChannelId(0);
				$result = json_encode($result);
				$redis->set('ProvinceList',$result);
			}

			$result = json_decode($result,1);

			$this->success($result,'查询成功');

		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}

	}

	/**
	 * @name  获取所有渠道省份信息
	 * @param $tag int 1表示输出网页的信息，0表示只输出信息
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public function actionProvinceList($tag=0)
	{
		$res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelChildChannelByChannelId'], ['channelId' => 0, 'level' => 1]);

		if($tag){
			$this->success($res['data'], 'success');
		}else{
			return json_encode($res['data'], JSON_UNESCAPED_UNICODE);
		}
	}

	/**
	 * @name 根据渠道ID获取子渠道
	 * @param $tag int 1表示输出网页的信息，0表示只输出信息
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public function actionChildChannelByChannelId($id= '', $level = 2, $field='id,name,short_name', $tag = 0)
	{
		$res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelChildChannelByChannelId'], ['channelId' => $id, 'level' => $level, 'field' => $field, 'isWithout' => 1]);
		if($tag){
			foreach ($res['data'] as $key => &$value) {
				$value['label'] = $value['name'];
			}
			$this->success($res['data'], 'success');
		}else{
			return json_encode($res['data'], JSON_UNESCAPED_UNICODE);
		}
	}

	/**
	 * @name 根据渠道ID获取设备信息
	 * @author caolei
	 * @param @all 默认获取20条数据
	 * @param $type 设备类型
	 * @param $tag int 1表示输出网页的信息，0表示只输出信息
	 * @time 2017年10月13日14:06:01
	 * @method get
	 * @return [type] [description]
	 */
	public function actionMachineListByChannelId($id = '', $all = 0, $type = '', $tag = 0)
	{
		$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['arrayDataByChannelId'], ['channelId' => $id]);
		//获取渠道id下的所有的数据
		if ($all) {
			$machine_id = explode(',' ,$id);
			$field = 'id,serial_no,mac_address,type_id';
			foreach ($machine_id as $value) {
				$count = $this->actionMachineCountByChannelId($value);
				$res = $this->getAllMachineListByChannelId($count, $value, $type, $field);
			}
		}
		if($tag){
			$this->success($res, 'success');
		}else{
			return json_encode($res, JSON_UNESCAPED_UNICODE);
		}
	}

	/**
	 * @name 根据渠道id,查询所有的设备列表
	 * @param int $totalCount 列表总数
	 * @param int $channelId 渠道id
	 * @param string $typeId 设备类型
	 * @param string $field 需要获取的字段
	 * @author caolei
	 * @time 2018年1月4日
	 * @return [type] [description]
	 */
	public function getAllMachineListByChannelId($totalCount, $channelId, $typeId, $field)
	{
		$times = ceil($totalCount / 50);
		$allList = [];
		for ($i = 1; $i <= $times; $i++) {
			$allList = array_merge($allList,  CommonService::getMachineListByChannelId($channelId, $typeId, 50, $i, $field)['data']);
		}
		return $allList;
	}

	/**
	 * @name 根据渠道id获取设备总数
	 * @author caolei
	 * @param $tag int 1表示输出网页的信息，0表示只输出信息
	 * @time 2017年10月13日15:32:03
	 * @method get
	 * @return [type] [description]
	 */
	public function actionMachineCountByChannelId($id = '', $tag = 0)
	{
		$channelId = explode(',' ,$id);
		$count = 0;
		foreach ($channelId as $key => $value) {
			$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineCountByChannelId'], ['channelId' => $value]);
			$count += intval($res['data']['totalCount']);
		}
		if($tag){
			$this->success($count, 'success');
		}else{
			return $count;
		}
	}

	/**
	 * @name 获取所有渠道信息
	 * @author caolei
	 * @time 2017年10月13日17:44:18
	 * @method get
	 * @return [type]        [description]
	 */
	public function actionGetChannelAll()
	{
		//判断是否有缓存
		if ($res = Yii::$app->redis->get('allChinnel')) {
			return $res;
		}
		$province = $this->actionChildChannelByChannelId(0, $level = 1);

		$province = json_decode($province, true);
		//获取所有的渠道信息
		foreach ($province as &$proValue) {
			$proValue['parentId'] = 0;
			$proValue['type'] = 'province';
			$proValue['label'] = $proValue['name'];
			unset($proValue['name']);
			$proValue['children'] = json_decode($this->actionChildChannelByChannelId($proValue['id'], $level = 2), true);
			foreach ($proValue['children'] as &$cityValue) {
				$cityValue['parentId'] = $proValue['id'];
				$cityValue['type'] = 'city';
				$cityValue['label'] = $cityValue['name'];
				unset($cityValue['name']);
				$cityValue['children'] = json_decode($this->actionChildChannelByChannelId($cityValue['id'], $level = 4), true);
				foreach ($cityValue['children'] as &$pointValue) {
					$pointValue['parentId'] = $cityValue['id'];
					$pointValue['type'] = 'point';
					$pointValue['label'] = $pointValue['name'];
					unset($pointValue['name']);
				}
			}
		}
		if ($province) {
			$res['code'] = 0;
			$res['msg'] = 'success';
			$res['data'] = $province;
		}
		$res = json_encode($res, JSON_UNESCAPED_UNICODE);
		Yii::$app->redis->set('allChinnel', $res);
		Yii::$app->redis->expire('allChinnel', 1200);
		return $res;
	}

	/**
	 * @name 递归根据渠道ID获取子渠道
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public function recursionChannelId($id, $level=1)
	{
		$result = json_decode($this->actionChildChannelByChannelId($id,$level),1);

		if(!empty($result)){
			foreach($result as $key=>$value){
				$result[$key]['level'] = $level;
				$result[$key]['child'] = $this->recursionChannelId($value['id'],$level+1);
				if(empty($result[$key]['child'])){
				    unset($result[$key]['child']);
				}
			}
		}
		return $result;
	}

	/**
	 * @name 根据渠道id获取渠道类型，是province,还是city,还是point
	 * @param  [type] $level [description]
	 * @author caolei
	 * @time 2017年12月7日16:13:17
	 * @return [string]        [对应的渠道等级]
	 */
	public function actionGetChannelTypeByLevel($level)
	{
		switch ($level) {
			case '1':
				return 'province';
				break;
			case '2';
				return 'city';
			case '3';
				return 'point';
			default:
				'4';
				return 'point_p';
				break;
		}
	}

	/**
	 * @name 根据渠道id获取这个渠道下所有的子渠道信息
	 * @author caolei
	 * @time 2017年12月7日16:00:51
	 * @param  [int] $id [渠道id]
	 * @param [int] $channelLevel 要获取的子渠道的等级 1省份、2城市、3渠道商、4网点、5点位
	 * @param [int] $type 区分类型
	 * @return [json]
	 */
	public function actionAllChannelInfoByChannelId($id, $channelLevel, $type = 1)
	{
		if ($channel = Yii::$app->redis->get('channel_' . 'level_' . $channelLevel . '_id_' . $id . '_type_' . $type)) {
			return $this->success(json_decode($channel, true), 'success');
		}
		$arrId = explode(',', $id);
		$data = [];
		foreach ($arrId as $key => $value) {
			$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiChannelInfoByChannelId'], ['channelId' => $value, 'field' => 'id, name, parent_id,level']);
			$field = 'id, name, parent_id,level';
			$res['data']['label'] = $res['data']['name'];
			if ($res['data']['level'] != $channelLevel) {
				$res['data']['children'] = $this->actionRecursionGetChannel($res['data']['id'], $res['data']['level'], $field, $channelLevel+1);
			}
			$res['data']['type'] = $this->actionGetChannelTypeByLevel($res['data']['level']);
			$data[] = $res['data'];
		}
		Yii::$app->redis->set('channel_' . 'level_' . $channelLevel . '_id_' . $id . '_type_' . $type, json_encode($data, JSON_UNESCAPED_UNICODE));
		Yii::$app->redis->expire('channel_' . 'level_' . $channelLevel . '_id_' . $id . '_type_' . $type, 1200);
		// $this->success($res['data'], 'success');
		$this->success($data, 'success');
	}

	/**
	 * @name 递归查询子渠道的信息  嵌套结构
	 * @param  [int] $id    [渠道id]
	 * @param  [int] $level [渠道等级]
	 * @param  [string] $field [接口要查询的字段]
	 * @param  [int] $channelLevel  [要获取的子渠道等级]
	 * @return [array]        [嵌套包含关系的渠道信息]
	 */
	public function actionRecursionGetChannel($id, $level, $field, $channelLevel)
	{
		$field = 'id, name, parent_id,level';
		$data = json_decode($this->actionChildChannelByChannelId($id, $level+1, $field), true);
		//如果没有网点直接跳过
		if(empty($data)){
			return;
		}
		if ($data[0]['level'] != $channelLevel) {
			foreach ($data as $key => &$value) {
				$value['label'] = $value['name'];
				$value['type'] = $this->actionGetChannelTypeByLevel($value['level']);
				$value['children'] = $this->actionRecursionGetChannel($value['id'], $value['level'], $field, $channelLevel);
			}
			return $data;
		} else {
			return;
		}
	}

	/**
	 * @name 递归查询子渠道的信息 树状结构
	 * @param  [int] $id           [渠道id]
	 * @param  [int] $level        [渠道等级]
	 * @param  [int] $channelLevel [要获取的子渠道等级]
	 * @return [type]               [description]
	 */
	public function actionTreeRecursionGetChannel($id, $level, $channelLevel)
	{
		static $list = [];
		$field = 'id, name, parent_id,level';
		$data = json_decode($this->actionChildChannelByChannelId($id, $level+1, $field), true);
		if ($data[0]['level'] != $channelLevel) {
			foreach ($data as $key => &$value) {
				$value['label'] = $value['name'];
				$value['type'] = $this->actionGetChannelTypeByLevel($value['level']);
				$list[] = $value;
				$this->actionTreeRecursionGetChannel($value['id'], $value['level'], $channelLevel);
			}
			return $list;
		} else {
			return;
		}
	}

	/**
	 * @name 根据渠道id跨等级查询子信息
	 * @param  [int] $id           [渠道id]
	 * @param  [int] $level        [等级]
	 * @param  [int] $channelLevel [要获取的子渠道等级]
	 * @return [type]               [description]
	 */
	public function actionTest($id, $level)
	{
		$field = 'id, name, parent_id, level';
		$res = $this->actionChildChannelByChannelId($id, $level, $field);
		return $res;
		// var_dump($res);
	}
}