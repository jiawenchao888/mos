<?php
namespace app\modules\v2;

use Yii;

/**
 * v2 module definition class
 */
class Module extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'app\modules\v2\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        if (Yii::$app instanceof \yii\console\Application) {
            $this->controllerNamespace = 'app\modules\v2\commands';
            // custom initialization code goes here
            // 从config.php加载配置来初始化模块
            Yii::configure($this, require(__DIR__ . '/config/console.php'));
        } else {
            // custom initialization code goes here
            // 从config.php加载配置来初始化模块
            Yii::configure($this, require(__DIR__ . '/config/web.php'));
        }
    }
}
