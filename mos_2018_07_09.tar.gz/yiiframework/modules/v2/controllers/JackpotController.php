<?php
namespace app\modules\v2\controllers;

use app\controllers\CommonController;
use Yii;
use yii\web\Controller;
use app\models\Jackpot;
use app\models\Award;
use app\models\AcceptAward;
use app\models\AwardTicket;
use app\logic\JackpotLogic;
use app\commands\Rsa;

class JackpotController extends CommonController
{

	private $__salt = 'dthaforever';

	public function beforeAction($action)
	{
		return [
			'verbs' => [
				'class' => \yii\filters\VerbFilter::className(),
				'actions' => [
					'prize' => ['post'],
				],
			],
		];
	}

	/**
	 * @name 中奖终端使用接口
	 * @remark 中奖接口
	 * @time 2018年5月2日
	 * @author caolei
	 * @method post
	 * @return [type] [description]
	 */
	public function actionPrize()
	{
		try {
			$post = Yii::$app->request->post();
			// var_dump(JackpotLogic::uniqueCodePrize());die;
			// $param = Yii::$app->params;
			// $config = [
			// 	'publicKey' => $param['key']['selfPublickKey'],
			// 	'privateKey' => $param['key']['privateKey'],
			// ];
			// $Rsa = new Rsa($config);
			// $secrect = $Rsa->shortDecrypt($post['secrect']);
			// $secrect = json_decode($secrect,1);
			// var_dump($secrect);die;

			$model = new Jackpot();
			$data = $model->listt($post['id']);
			$data = json_decode($data[0]['award_list'], true);
			// var_dump($data);die;
			$res = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["probability"]; return $res;'));
			//获取奖品对应的url
			$res_time = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["url"]; return $res;'));
			$award['awardId'] = $this->getRand($res);
			$unique_code = JackpotLogic::uniqueCodePrize();
			$salt = md5($unique_code . $post['res_id'] . $this->__salt);
			$award['erCodeUrl'] = $res_time[$award['awardId']] . "?unique_code=" . $unique_code . "&res_id=" . $post['res_id'] . "&salt=" . $salt;
			$this->success($award, '中奖接口请求成功');
		} catch ( \ErrorException $exception ) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 中奖小程序使用接口
	 * @return
	 */
	public function actionPrizeMiniPrograms()
	{
		try {
			$post = Yii::$app->request->post();
			$model = new Jackpot();
			$data = $model->listt($post['id']);
			$data = json_decode($data[0]['award_list'], true);
			// var_dump($data);die;
			$res = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["probability"]; return $res;'));
			//获取奖品对应的url
			$res_time = array_reduce($data,create_function('$res,$item', '$res[$item["id"]] = $item["url"]; return $res;'));
			$award['awardId'] = $this->getRand($res);
			$unique_code = JackpotLogic::uniqueCodePrize();
			$salt = md5($unique_code . $post['res_id'] . $this->__salt);
			$award['erCodeUrl'] = $res_time[$award['awardId']] . "?unique_code=" . $unique_code . "&res_id=" . $post['res_id'] . "&salt=" . $salt;
			$this->success($award, '中奖接口请求成功');
		} catch ( \ErrorException $exception ) {
			$this->error(11000, $exception->getMessage());
		}
	}

	/**
	 * @name 领奖接口
	 * @return
	 */
	public function actionGetPrize()
	{
		//unique_code, open_id, res_id
		$post = Yii::$app->request->post();
		$AwardTicket = AwardTicket::findOne(['unique_code' => $post['unique_code']]);
		if ((NULL === $AwardTicket) || $AwardTicket->is_get === 1) {
			return $this->success('', '奖品已经被领取');
		}
		$AcceptAward = AcceptAward::findOne(['open_id' => $post['open_id'], 'res_id' => $post['res_id']]);
		if (NULL === $AcceptAward) {
			$AwardTicket->is_get = 1;
			$AwardTicket->save();
			$model = new AcceptAward;
			$post['is_get'] = 1;
			$model->add($post);
			//调用发奖接口
			return $this->success('','恭喜您中奖');
		} elseif ($AcceptAward->is_get === 1) {
			return $this->success('', '您已经领取过奖品');
		}
	}
}