<?php

return [
    'appId' => '100003',
    'appSecret' => '1mB23PN_Ck1qweff3asfdsfgECeu1KL50',
    //终端机权限key
    'authKey' => '1555900b18c641bf',
    'pageSize' => [
        'award' => 10,
        'jackpot' =>10,
        'resource' =>10,
        'terminallog' =>10,
        'terminal' =>10,
        'mos' => 10,
        //U盘刊例列表
        'zip' => 10,
        //根据设备id获取素材详情
        'machineRes' => 10,
        //根据设备id获取素材或者奖池缓存日志
        'machineResLog' => 10,
        //根据设备id获取奖池详情
        'machineJackpot' => 10,
        //终端缓存列表
        'terminallist' =>10,
        //审核页面的操作记录日志
        'operateRecord' => 5,
    ],
    //公钥秘钥
    'key' => [
        //生产环境的公钥
        'publicKey' => __DIR__ . "/key/public_key.pem",
        //mos私钥
        'privateKey' => __DIR__ . "/key/mos_private_key.pem",
        //mos公钥
        'selfPublickKey' => __DIR__ . "/key/mos_public_key.pem",
    ],
    //域名列表
    'domainList' => [
        'domain' => 'http://fangyuan.datuhongan.net',
    ],
    //api列表
    'apiBaseList' => [
        // 按设备 MAC 地址获取设备信息
        'apiMachineMacAddress' => '/v3/machine/machine-info-by-mac-address',
        // 根据渠道 ID 获取设备列表
        'arrayDataByChannelId' => '/v3/machine/machine-list-by-channel-id',
        // 根据设备 ID 创建指令
        'apiCommandCreateByManchineId' => '/v3/command/create-by-machine-id',
        // 获取所有 渠道 省份信息
        'apiChannelProvinceList' => '/v3/channel/province-list',
        // 根据渠道 ID 获取子渠道
        'apiChannelChildChannelByChannelId' => '/v3/channel/child-channel-by-channel-id',
        // 根据渠道id获取设备总数
        'apiMachineCountByChannelId' => '/v3/machine/machine-count-by-channel-id',
        // 根据设备id 获取设备消息
        'apiMachineInfoByMachineId' => '/v3/machine/machine-info-by-machine-id',
        // 根据指定条件获取日志列表
        'aipOtherLogList' => '/v3/log/list',
        // 新增操作日志
        'apiOtherRecordLog' => '/v3/log/create',
        // 获取设备类型接口
        'apiMachineMachineTypeList' => '/v3/machine/machine-type-list',
        // 根据设备编号获取设备信息
        'apiMachineMachineInfoBySerialNo' => '/v3/machine/machine-info-by-serial-no',
        // 新增统计数据
        'apiCountCreate' => '/v3/count/create',
        // 根据条件获取日志总数量
        'apiOtherLogCount' => '/v3/log/count',
        // 根据用户id查询用户名
        'apiUserGetDataById' => '/v3/user/get-data-by-id',
        // 用户扫码统计
        'apiCountCreateDownload' => '/v3/download/create',
        //分块上传事件之初始化
        'apiFileInitPart' => '/v3/upload-file/init-part',
        //事件上传之分块
        'apiFileUploadPart' => '/v3/upload-file/upload-part',
        //事件上传之合并分块
        'apiFileCompetePart' => '/v3/upload-file/compete-part',
        //获取文件的url
        'apiFileGetFileUrl' => '/v3/upload-file/get-file-url',
        //取消文件上传
        'apiFileAboutPart' => '/v3/upload-file/abort-part',
        //根据设备ID删除指令
        'apiCommandDeleteByMachineId' => '/v3/command/delete-by-machine-id',
        //获取token
        'apiUserGetAccessToken' => '/v3/oauth/get-access-token',
        //根据渠道id获取渠道信息
        'apiChannelInfoByChannelId' => '/v3/channel/info-by-channel-id',
        //根据渠道LEVEL获取渠道列表
        'apiChannelListByChannelLevel' => '/v3/channel/list-by-channel-level',
        //根据渠道LEVEL获取渠道列表总数
        'apiChannelCountByChannelLevel' => '/v3/channel/count-by-channel-level',
        //根据渠道ID获取对应的父级渠道列表
        'apiChannelParentChannelListByChannelId' => '/v3/channel/parent-channel-list-by-channel-id',
    ],
    //统计接口 typeid 配置
    'statisticsList' => [
        'acceptThePrizeTypeId' => '2333',
        'QrCodeTypeId' => '6666'
    ],
    //铁路局
    'railway' => [
        'callAIQuestion' => 'http://port.st12306.cn/pisp/service/service.asmx/callAIQuestion',
    ],
    //微信
    'weChat' => [
        'makeErCode' => 'http://travel.datuhongan.com/weixin/qr-code/limit',
    ],
];
