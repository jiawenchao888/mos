<?php

return [
	'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=10.19.155.124;port=3306;dbname=datu_mosexhibition',
	'username' => 'root',
	'password' => 'MySQL123Pwd',
	'charset' => 'utf8',
	'tablePrefix' => 'mos_',
];
