<?php
return [
	 'class' => 'yii\redis\Connection',
	 'hostname' => '192.168.100.37',
	 //'password' => 'datu@com',
	 'port' => 6379,
	 'database' => 3,

];