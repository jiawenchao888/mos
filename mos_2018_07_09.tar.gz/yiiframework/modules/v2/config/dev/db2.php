<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.100.37;dbname=advertisement',
    'username' => 'advertisement',
    'password' => 'BYFZdkyakFCP1Ojg',
    'charset' => 'utf8',
];
