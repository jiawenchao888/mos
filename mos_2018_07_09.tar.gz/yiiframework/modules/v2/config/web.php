<?php
return [
    'params' => require ( __DIR__ . '/params.php' ),
];