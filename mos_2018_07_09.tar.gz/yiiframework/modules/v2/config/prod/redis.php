<?php
return [
    'class' => 'yii\redis\Connection',
    'hostname' => '10.19.108.196',
    'password' => 'datu@com',
    'port' => 6379,
    'database' => 3,
];