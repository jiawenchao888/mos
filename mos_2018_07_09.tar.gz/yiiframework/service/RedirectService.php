<?php

namespace app\service;

use app\models\Award;
use \Yii;

class RedirectService extends CommonService
{
	/*
	 * @name 请求公众号后台获取 二维码
	 * @remark 二维码域名跳转
	 * @author yongkang
	 * @time 2017年10月18日10:40:12
	 * @method get
	 * @data 请求数据
	 * return null
	 */
	public static function getWxQrCode($data)
	{
		$awardInfo = Award::findOne($data['aid']);
		if(!empty($awardInfo)){
			$url = $awardInfo->url;

			if(strpos($url,'?') !== false){
				$url .= '&';
			} else {
				$url .= '?';
			}

			//sign = md5(aid . macid . planid .time . 1555900b18c641bf)
			$authKey = \Yii::$app->params['authKey'];
			$sign = md5($data['aid'].$data['macid'].$data['planid'].$data['time'].$authKey);
			$url .= 'macid='.$data['macid'].'&aid='.$data['aid'].'&planid='.$data['planid'].'&time='.$data['time'].'&sign='.$sign;

			$data = CommonService::httpClient($url,'','get');
			if(is_array($data) && ($data['code'] === 0)){
				return $data['data'];
			} else {
				echo '';
			}
		} else {
			echo '';
		}
	}

	/*
	 * @name 请求公众号后台获取 二维码2
	 * @remark 二维码域名跳转
	 * @author yongkang
	 * @time 2017年10月18日10:40:12
	 * @method get
	 * @data 请求数据
	 * return null
	 */
	public static function getWxQrCode2($data = [], $url, $scene='tg')
	{

		try{
			if(strpos($url,'?') !== false){
				$url .= '&';
			} else {
				$url .= '?';
			}
			$url .= 'macid='.$data['macid'] . '&planid='.$data['planid'] . '&scene=' . $scene;

			$data = CommonService::httpClient($url);

			if($data['code'] == 0){
				return $data['data'];
			} else {
				echo 'n';
			}

		}catch(\Exception $e){
			return $e->getMessage();
		}
	}

}