<?php

namespace app\service;

use app\controllers\CommonController;
use app\models\Terminal;
use Yii;
use yii\data\Pagination;

class TerminalService extends CommonService
{
	/**
	 * @name 根据渠道id获取渠道设备信息
	 * @param $channelId
	 * @return array
	 * @author yongkang
	 * @time 2017年10月11日11:19:10
	 */

	public static function getTerminalMachineListByTerminalId($channelId)
	{
		return CurlService::getTerminalMachineListByTerminalId($channelId);
	}

	/**
	 * @name 根据设备编号获取设备信息
	 * @param $serialNo
	 * @return array
	 * @author yongkang
	 * @time 2017年10月11日11:19:10
	 */

	public static function getTerminalMachineListByTerminalSeriaNo($serialNo)
	{
		return CurlService::getTerminalMachineListByTerminalSeriaNo($serialNo);
	}

	/**
	 * @name 根据设备id获取设备信息
	 * @param $machineId
	 * @return array
	 * @author yongkang
	 * @time 2017年11月03日17:20:42
	 */

	public static function getTerminalMachineInfoByMachineId($machineId)
	{
		return CurlService::getTerminalMachineInfoByMachineId($machineId);
	}

	/**
	 * @name 判断传入的id是否是内网设备id
	 * @param $id INT 传入ID
	 * @time 2017年10月11日11:19:10
	 * @author yongkang
	 * return bool
	 */
	Public static function checkIsInsideTerminalMachine($id = '')
	{
		$insertMachineList = Yii::$app->redis->get('insertMachineList');
		if(empty($insertMachineList)){
			$inserList = ChannelService::getInsideMachineList();
			$inserList = array_column($inserList['data'],'id');
			$insertMachineList = json_encode($inserList);
			Yii::$app->redis->set('insertMachineList',$insertMachineList,'ex',7200);
		}

		$list = json_decode($insertMachineList);

		return in_array($id,$list);
	}


	/**
	 * @name 根据条件获取素材缓存状态
	 * @param string $id
	 * @param string $equ
	 * @param string $type
	 * @param string $page
	 * @author yongkang
	 * @return mixed
	 */
	Public static function getTerminalStatusByCondition($id='', $equ='', $type='', $page='')
	{
		$equ = explode(',',$equ);
		$model = Terminal::find();
		$model->where(['res_id' => $id,'equ_number' => $equ])
			->andFilterWhere(['in','equ_number',$equ])
			->andFilterWhere(['type' => $type]);
		$data= $model->all();
		return $data;
	}


}