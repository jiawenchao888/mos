<?php
namespace app\service;

use \Yii;

class ResourceService extends CommonService
{
	/**
	 * @name 删除redis,资源配置接口
	 * @author yongkang
	 * @time 2017年11月06日14:59:34
	 * @param $id int id
	 * @param int $tag tag
	 */
	public static function delRedisResourceById($id, $tag=1)
	{
		Yii::$app->redis->hdel('resourceConf','id_'.$id);
	}
}