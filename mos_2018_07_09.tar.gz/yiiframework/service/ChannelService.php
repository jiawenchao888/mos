<?php
namespace app\service;

use app\commands\Rsa;
use Yii;

class ChannelService extends CommonService
{

	/**
	 * @name 获取设备类型接口
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public static function machineTypeList()
	{
		return CurlService::getTerminalTypeList();
	}


	/**
	 * @name 获取内网设备列表
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @return array|bool
	 */
	public static function getInsideMachineList()
	{
		//上海channelid 392
		$api = Yii::$app->params['apiBaseList']['arrayDataByChannelId'];
		$arr = ['channelId'=>392,'showNum' => 200];
		return CommonService::httpShenYao($api,$arr);
	}

}