<?php
namespace app\service;

use Yii;
use app\service\CommonService;
/**
 * @name CURL
 * Class CurlService
 * @package app\service
 */
class OrderService
{

	/**
	 * @name 单个创建心跳下载微信二维码
	 * @param $machineId int 设备id
	 * @param $value string 默认值
	 * @author caolei
	 * @time 2018年3月16日
	 * @return
	 */
	public static function createHeartSingleDownloadWechatErCode($machineId, $value = 1)
	{
		$instruct = [
			'machineId' => $machineId,
			'key' => Yii::$app->params['machineOrder']['downloadWechatErCode'],
			'value' => $value,
			'expired' => 1200,
		];
		return $res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandCreateByManchineId'], $instruct);
	}

	/**
	 * @name 批量创建心跳下载微信二维码
	 * @param array $machineId 设备id
	 * @param string $value  默认值 01
	 * @author caolei
	 * @time 2018年3月16日
	 * @return
	 */
	public static function createHeartBatchDownloadWechatErCode($machineId, $value = 1)
	{
		$instruct = [
			'machineIds' => $machineId,
			'key' => Yii::$app->params['machineOrder']['downloadWechatErCode'],
			'value' => $value,
			'expired' => 1200,
		];
		return $res = CommonService::httpShenYao(Yii::$app->params['newApiList']['batchCreateByMachineIds'], $instruct);
	}

	/**
	 * @name 批量重置素材配置资源
	 * @param   array $machineId 设备id
	 * @param   int $resId 素材id
	 * @author caolei
	 * @time 2018年3月19日
	 * @return
	 */
	public static function resetResConf($machineId, $resId)
	{
		$instruct = [
			'machineIds' => $machineId,
			'key' => Yii::$app->params['machineOrder']['downloadResConf'],
			'value' => $resId,
			'expired' => 1200,
		];
		return $res = CommonService::httpShenYao(Yii::$app->params['newApiList']['batchCreateByMachineIds'], $instruct);
	}

	/**
	 * @name 同步投放计划
	 * @param array $machineId 设备id
	 * @param int $planId 投放计划id
	 * @author caolei
	 * @time 2018年3月21日
	 */
	public static function syncPlan($machineId, $planId = '')
	{
		$key1 = 'update_plan_home'; //广告组相关投放计划的指令
		$key2 = 'update_plan_list'; //广告组相关投放计划的指令
		$setHeartBeat_update_plan_home = self::commonOrder($machineId, $key1, 1, 86400);
		$setHeartBeat_update_plan_list = self::commonOrder($machineId, $key2, 1, 86400);
		if (0 !== $setHeartBeat_update_plan_home['code']) {
			Yii ::$app -> redis -> set( 'error_create_hear_beat_home:' . $planId , json_encode($setHeartBeat_update_plan_home, JSON_UNESCAPED_UNICODE) );
		}
		if (0 !== $setHeartBeat_update_plan_list['code']) {
			Yii ::$app -> redis -> set( 'error_create_hear_beat_list:' . $planId , json_encode($setHeartBeat_update_plan_list, JSON_UNESCAPED_UNICODE) );
		}
		return $setHeartBeat_update_plan_list;
	}

	/**
	 * @name 公用指令
	 * @param array $machineId 设备id
	 * @param string $key 指令
	 * @param mix $value
	 * @param int $time 过期时间戳
	 * @return
	 */
	public static function commonOrder($machineId, $key, $value, $time)
	{
		$instruct = [
			'machineIds' => $machineId,
			'key' => $key,
			'value' => $value,
			'expired' => $time,
		];
		return $res = CommonService::httpShenYao(Yii::$app->params['newApiList']['batchCreateByMachineIds'], $instruct);
	}

}