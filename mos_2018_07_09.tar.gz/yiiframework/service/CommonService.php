<?php

namespace app\service;

use app\commands\Rsa;
use app\models\CommonModel;
use Yii;
use yii\httpclient\Client;


class CommonService
{
	/**
	 * @name http请求
	 * @author yongkang
	 * @param $api string 请求的接口
	 * @param $data array 发送的数据
	 * @param $type string 请求的类型
	 * @return bool|array
	 */
	public static function httpClient($api, $data='', $type='get')
	{
		$client = new Client();
		$client->setTransport('yii\httpclient\CurlTransport');
		$response = $client->createRequest()
			->setMethod($type)
			->setUrl($api)
			->setData($data)
			->send();
		if($response->isOk){
			return $data = $response->data;
		}
		return $response;
	}

	/**
	 * @name 获取应用授权码
	 * @time 2017年9月26日17:26:03
	 * @author caolei
	 * @return [type] [description]
	 */
	public static function getToken()
	{
		if($accessToken = Yii::$app->redis->get('accessToken')){
			return $accessToken;
		} else {
			$config = [
				'publicKey' => Yii::$app->params['key']['publicKey'],
				'privateKey' => Yii::$app->params['key']['privateKey'],
			];
			$key = new Rsa($config);
			// 加密数据
			$data = [
				'appSecret' => Yii::$app->params['appSecret'],
			];
			$encrypted = $key->encrypt($data);
			$arr = ['data' => $encrypted,'appId' => Yii::$app->params['appId']];
			$api = Yii::$app->params['domainList']['domain'].Yii::$app->params['apiBaseList']['apiUserGetAccessToken'];
			$res = self::HttpClient($api,$arr,'post');
			$token = $key->decrypt($res['data']);
			Yii::$app->redis->set('accessToken',$token['accessToken']);
			Yii::$app->redis->expireat('accessToken',$token['expire']);

			return $accessToken = Yii::$app->redis->get('accessToken');
		}
	}

	/**
	 * @name 请求沈瑶通用接口
	 * @author yongkang
	 * @time 2017年10月11日10:40:24
	 * @param $url string 地址
	 * @param $data array 数据内容
	 * return array
	 */
	public static function httpShenYao($url, $data)
	{
		$api = Yii::$app->params['domainList']['domain'].$url;
		$config = [
			'publicKey' => Yii::$app->params['key']['publicKey'],
			'privateKey' => Yii::$app->params['key']['privateKey'],
		];
		$key = new Rsa($config);
		$accessToken = self::getToken();
		$data = [
			'appId' => Yii::$app->params['appId'],
			'accessToken' => $accessToken,
			'data' => $key->encrypt($data),
		];
		$res = self::httpClient($api,$data,'post');
		$res['data'] = $key->decrypt($res['data']);

		return $res;
	}

	/**
	 * @name 生成excel
	 * @author caolei
	 * @time 2017年10月18日10:01:24
	 * $titles = array('key1'=>'title1','key2'=>'title2');
     * $detail = array(array('key1'=>'value1','key2'=>'value2'),array('key1'=>'value11','key2'=>'value22'));
     * array_unshift($detail, $titles); *
	 * @var string
	 */
	public static function makeExcel($filename = 'demo', $datas = [])
	{
		require '../yiiframework/commands/PHPExcel.php';

		$objPHPExcel = new \PHPExcel();
		$num = 1;
		foreach ($datas as $l => $d) {
		    $keys = array_keys($datas[0]);
		    $key = 1089;  //大写字母对应ASCII码值
		    foreach ($keys as $k) {
		        $objPHPExcel->setActiveSheetIndex(0)->setCellValue(chr($key).$num, $d[$k]);
		        $key++;
		    }
		    $num++;
		}
		$objPHPExcel->getActiveSheet()->setTitle('Sheet1');
		header('Content-Type: application/vnd.ms-excel');//告诉浏览器将要输出excel03文件
		header('Content-Disposition: attachment;filename="'.$filename.'"');
		header('Cache-Control: max-age=0');
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output');
	}

	/*
	 * @name 生成随机字符串
	 * @2017年9月26日17:26:03
	 * @author yongkang
	 * @param $length 长度
	 * @return string
	 */
	public static function generate_password( $length = 8 ) {
		// 密码字符集，可任意添加你需要的字符
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$password = '';
		for ( $i = 0; $i < $length; $i++ )
		{
			$password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
		}

		return $password;
	}

	/**
	 * @name 生成压缩包
	 * @2017年9月26日17:26:03
	 * @author yongkang
	 * @param $cdroot string 目标地址
	 * @param $fileUrl string 文件地址
	 * @param $password string 加密内容
	 * @return string
	 */
	Public static function generate_zip($cdroot,$fileUrl,$password)
	{

	}

	/**
	 * @name 通过拼接文件地址,来返回文件全路径
	 * @remark 通过拼接文件地址,来返回文件全路径
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return string
	 */
	public static function joinFileUrl($filename)
	{
		$commonModel = new CommonModel();
		return $commonModel->getFullUrl($filename);
	}

	/**
	 * @name 删除设备的指令
	 * @author caolei
	 * @time 2017年10月30日17:23:29
	 * @param $key string 操作设备的指令
	 * @param $id  int 设备id
	 * @return [type] [description]
	 */
	public static function delMachineOrder($id, $key)
	{
		$instruct = [
			'machineId' => $id,
			'key' => $key,
		];
		return CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandDeleteByMachineId'], $instruct);
	}

	/**
	 * @name 根据渠道id查询子渠道信息
	 * @param  string  $id    [渠道id]
	 * @param  integer $level [要查询的级别]
	 * @param  string  $field [查询的字段]
	 * @param  integer $tag   [默认即可]
	 * @return [array]
	 */
	public static function childChannelByChannelId($id= '', $level = 2, $field='id,name,short_name', $tag = 0)
	{
		$res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelChildChannelByChannelId'], ['channelId' => $id, 'level' => $level, 'field' => $field]);
		if($tag){
			foreach ($res['data'] as $key => &$value) {
				$value['label'] = $value['name'];
			}
			$this->success($res['data'], 'success');
		}else{
			return $res['data'];
		}
	}

	/**
	 * @name 获取所有的子渠道
	 * @param int $level 渠道级别
	 * @param int $showNum 展示的数量
	 * @param int $page 页码
	 * @author caolei
	 * @time 2017年12月27日
	 * @return [type] [description]
	 */
	public static function getAllInfoByLevel($level, $showNum = 20, $page = 1)
	{
		return $res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelListByChannelLevel'], ['level' => $level, 'showNum' => $showNum, 'page' => $page]);
	}

	/**
	 * @name 根据渠道LEVEL获取渠道列表总数
	 * @param  [int] $level [渠道级别]
	 * @author caolei
	 * @time 2018年1月3日
	 * @return array
	 */
	public static function getCountByLevel($level)
	{
		return $res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelCountByChannelLevel'], ['level' => $level]);
	}

	/**
	 * @name 根据渠道查询渠道信息
	 * @return [type] [description]
	 */
	public static function channelInfoByChannelId($id, $field = 'id, name, parent_id')
	{
		return $res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelInfoByChannelId'], ['channelId' => $id, 'field' => $field]);
	}

	/**
	 * @name 根据渠道id获取设备列表
	 * @param int $channelId 渠道
	 * @param int $typeId 设备类型
	 * @param int $showNum 展示数量
	 * @param int $page 页码
	 * @author caolei
	 * @time 2018年1月4日
	 * @return array
	 */
	public static function getMachineListByChannelId($channelId, $typeId, $showNum = 50, $page = 1, $field = 'id,serial_no,mac_address')
	{
		return $res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['arrayDataByChannelId'], ['channelId' => $channelId, 'showNum' => $showNum, 'page' => $page, 'typeId' => $typeId, 'field' => $field, 'isWithout' => 1]);
	}

	/**
	 * @name 根据渠道id,查询所有的设备列表
	 * @param int $totalCount 列表总数
	 * @param int $channelId 渠道id
	 * @param string $typeId 设备类型
	 * @param string $field 需要获取的字段
	 * @author caolei
	 * @time 2018年1月4日
	 * @return [type] [description]
	 */
	public static function getAllMachineListByChannelId($totalCount, $channelId, $typeId = '', $field = 'id,serial_no,mac_address')
	{
		$times = ceil($totalCount / 50);
		$allList = [];
		for ($i = 1; $i <= $times; $i++) {
            $tmp = CommonService::getMachineListByChannelId($channelId, $typeId, 50, $i, $field)['data'];
            if ($tmp) {
                $allList = array_merge($allList,  $tmp);
            }
		}
		return $allList;
	}

	/**
	 * @name 根据渠道id获取设备总数
	 * @param int $channelId
	 * @param int $typeId
	 * @return [array] [设备的总数]
	 */
	public static function getMachineCountByChannelId($channelId, $typeId = '')
	{
		return $count = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineCountByChannelId'], ['channelId' => $channelId, 'typeId' => $typeId]);
	}

	/**
	 * @name 根据渠道id，查询父级渠道信息
	 * @param  [int] $channelId [渠道id]
	 * @return [type]            [description]
	 */
	public static function getParentChannelByChannelId($channelId)
	{
		return CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelParentChannelListByChannelId'], ['channelId' => $channelId]);
	}

	/**
	 * @name 创建心跳指令从新下载二维码
	 * @param [int] $machineId [设备id]
	 * @return
	 */
	public static function terminalGetErCodeMachineOrder($machineId)
	{
		$instruct = [
			'machineId' => $machineId,
			'key' => 'Er_Download_Conf',
			'value' => 'hhhh',
			'expired' => 900,
		];
		$arr = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiCommandCreateByManchineId'], $instruct);
		return $arr;
	}

	public static function getMachineMachineTypeList($value='')
	{
		return $count = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineMachineTypeList'], ['type' => 1]);
	}

	/**
	 * @name 终端根据渠道id，创建下载二维码命令
	 * @param [int] $channelId [渠道id]
	 * @author caolei
	 * @time 2018年3月1日
	 * @return
	 */
	public static function terminalGetErCodeMachineOrderByChannel($channelId)
	{
		$totalCount = self::getMachineCountByChannelId($channelId, '2,3,4,5')['data']['totalCount'];
		$totalMachine = self::getAllMachineListByChannelId($totalCount, $channelId, '2,3,4,5');
		foreach ($totalMachine as $key => $value) {
			self::terminalGetErCodeMachineOrder($value['id']);
		}
	}

	/**
	 * @name 新版本的获取图片全路径
	 * @time 2017年9月28日14:47:36
	 * @author caolei
	 * @param $url string  objectKey地址
	 * @return string
	 */
	public function getFullUrl($url)
	{
	    if ($fullUrl = Yii::$app->redis->get('fullUrl')) {
	        return $fullUrl . $url;
	    } else {
	        $config = [
	            'publicKey' => Yii::$app->params['key']['publicKey'],
	            'privateKey' => Yii::$app->params['key']['privateKey'],
	        ];
	        $key = new Rsa($config);
	        $data = [
	            'objectKey' => $url,
	            'bucketName' => 'datu-ad',
	            'expire' => -1,
	        ];
	        $url_encrypted = $key->encrypt($data);
	        $url_data = [
	            'appId' => Yii::$app->params['appId'],
	            'accessToken' => $this->getToken(),
	            'data' => $url_encrypted,
	        ];
	        $url_api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileGetFileUrl'];
	        $url_res = $this->HttpClient($url_api, $url_data, 'post');
	        if (0 === $url_res['code']) {
	            $fullUrl = $key->decrypt($url_res['data']);
	            //将域名截取并存入redis
	            $strlenth = strpos($fullUrl, 'mos/api/');
	            $domainUrl = substr($fullUrl, 0, $strlenth);
	            Yii::$app->redis->set('fullUrl', $domainUrl);
	            Yii::$app->redis->expire('fullUrl', 30);
	            return $fullUrl;
	        } else {
	            return $url_res['msg'];
	        }
	    }
	}

	/**
	 * @name 获取LEVEL的所有渠道
	 * @param [int] $level 渠道等级 1，省份2，城市，3，渠道商，4，网点，5，点位
	 * @return [type] [description]
	 */
	public static function getAllChannelList($level)
	{
		$levelCount = self::getCountByLevel($level);
		$times = ceil($levelCount['data']/20);
		$channelList = [];
		for ($i=1; $i <= $times; $i++) {
			$channelList = array_merge($channelList, self::getAllInfoByLevel($level, 20, $i)['data']);
		}
		return $channelList;
	}


	/**
	 * @name 根据渠道获取所有机器
	 * @param  [int] $channel [渠道信息]
	 * @return
	 */
	public static function getAllMachine($channel)
	{
		$totalCount = self::getMachineCountByChannelId($channel)['data']['totalCount'];
		return 	$data = self::getAllMachineListByChannelId($totalCount, $channel, '', 'id,mac_address,channel_id,type_id');
	}

	/**
	 * @name 递归根据渠道ID获取子渠道
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public static function recursionChannelId($id, $level=1)
	{
		$result = json_decode(self::childChannelByChannelIdNew($id,$level),1);

		if(!empty($result)){
			foreach($result as $key=>$value){
				$result[$key]['level'] = $level;
				$result[$key]['child'] =self::recursionChannelId($value['id'],$level+1);
				if(empty($result[$key]['child'])){
				    unset($result[$key]['child']);
				}
			}
		}
		return $result;
	}

	/**
	 * @name 根据渠道ID获取子渠道
	 * @param $tag int 1表示输出网页的信息，0表示只输出信息
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public static function childChannelByChannelIdNew($id= '', $level = 2, $field='id,name,short_name', $tag = 0)
	{
		$res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelChildChannelByChannelId'], ['channelId' => $id, 'level' => $level, 'field' => $field, 'isWithout' => 1]);
		return json_encode($res['data'], JSON_UNESCAPED_UNICODE);
	}

}