<?php
namespace app\service;

use Yii;

/**
 * @name CURL
 * Class CurlService
 * @package app\service
 */
class CurlService extends CommonService
{
	/**
	 * @name 根据渠道id获取渠道设备信息
	 * @param $channelId
	 * @return array
	 * @author yongkang
	 * @time 2017年10月11日11:19:10
	 */
	public static function getTerminalMachineListByTerminalId($channelId)
	{
		$url = Yii::$app->params['apiBaseList']['arrayDataByChannelId'];
		$data = ['typeId'=>'', 'page'=>'', 'channelId'=>$channelId, 'showNum'=>100, 'field'=>''];
		return CommonService::httpShenYao($url,$data)['data'];
	}

	/**
	 * @name 获取设备类型接口
	 * @author yongkang
	 * @time 2017年10月10日08:45:32
	 * @method get
	 * return json
	 */
	public static function getTerminalTypeList()
	{
		$url = Yii::$app->params['apiBaseList']['apiMachineMachineTypeList'];
		return CommonService::httpShenYao($url,['type' => 1])['data'];
	}

	/**
	 * @name 根据设备编号获取设备信息
	 * @param $channelId
	 * @return array
	 * @author yongkang
	 * @time 2017年10月11日11:19:10
	 */
	public static function getTerminalMachineListByTerminalSeriaNo($serialNo)
	{
		$url = Yii::$app->params['apiBaseList']['apiMachineMachineInfoBySerialNo'];
		$data = ['serialNo'=>$serialNo, 'field'=>''];
		return CommonService::httpShenYao($url,$data)['data'];
	}


	/**
	 * @name 根据设备id获取设备信息
	 * @param $machineId
	 * @return array
	 * @author yongkang
	 * @time 2017年11月03日17:20:42
	 */

	public static function getTerminalMachineInfoByMachineId($machineId)
	{
		$url = Yii::$app->params['apiBaseList']['apiMachineInfoByMachineId'];
		$data = ['machineId'=>$machineId, 'field'=> 'type_id,mac_address,serial_no,channel_id'];
		return CommonService::httpShenYao($url, $data)['data'];
	}

	/**
	 * @name 根据渠道查询渠道信息
	 * @return [type] [description]
	 */
	public static function channelInfoByChannelId($id, $field = 'id, name, parent_id')
	{
		return $res = CommonService::httpShenyao(Yii::$app->params['apiBaseList']['apiChannelInfoByChannelId'], ['channelId' => $id, 'field' => $field]);
	}

	/**
	 * @name 根据mac地址查询查询设备信息
	 * @param  [string] $macAddress [mac地址]
	 * @return [arr]             [设备信息]
	 */
	public static function getMachineInfoByMacAddres($macAddress)
	{
		//如果redis有值，直接取redis中的值
		if ($machineInfo = Yii::$app->redis->hget('machineInfoByMacAddress', $macAddress)) {
			$data['code'] = 0;
			$data['msg'] = 'success';
			$data['data'] = json_decode($machineInfo, true);
			return $data;
		} else {
			//redis没有值，查询并存入
			$res = CommonService::httpShenYao(Yii::$app->params['apiBaseList']['apiMachineMacAddress'], ['macAddress'=>$macAddress,'field'=>'type_id,mac_address,id']);
			if ($res['code'] == 0) {
				//Yii::$app->redis->hset('machineInfoByMacAddress', $macAddress, json_encode($res));
			}
			return $res;
		}
	}
}