<?php

namespace app\logic;

use Yii;
use app\models\DefaultWechat;
use app\models\TempSet;
use yii\db\Query;
use app\models\NewConference;

class WechatLogic
{

	/**
	 * @name 获取微信公众号链接
	 * @param  [int] $id [数据库id]
	 * @return [string]     [微信公众号链接]
	 */
	public static function getDefaultWechat($id)
	{
		$model = new DefaultWechat();
		$wechatUrl = Yii::$app->redis->get('defaultWechat');
		if ($wechatUrl) {
			return $wechatUrl;
		} else {
			$wechatObj = $model->get($id);
			Yii::$app->redis->set('defaultWechat', $wechatObj->wechat_url);
			return $wechatObj->wechat_url;
		}
	}

	/**
	 * @name 通过openid获得分数
	 * @param  [array] $access_token
	 * @param  [array] $ad_id 广告id
	 * @return [type]          [description]
	 */
	public static function getScoreByAccessToken($access_token, $ad_id)
	{
		return ( new Query() ) -> select( 'e.`score`, u.`nick_name`, u.`head_img`, u.`id`, u.`access_token`, a.`name`' )-> from( 'exchange_code e' )
					                    // ->leftjoin('user_oath o', 'o.`user_id` = e.`user_id`')
					                    ->leftjoin('user u', 'u.`id` = e.`user_id`')
					                    ->leftjoin('ad a', 'a.id = e.ad_id')
				                        -> where( [ 'u.`access_token`' => $access_token ] )//->createCommand()->getRawSql();
				                        ->andWhere(['e.`ad_id`' => $ad_id])
				                        // -> one();
				                        ->createCommand(\Yii::$app->db_media)
				                        ->queryAll();
	}

	/**
	 * @name 根据access_token获取所有用户的信息
	 * @param  string $access_token
	 * @return [type]               [description]
	 */
	public static function getUserInfoByAccessToken($access_token)
	{
		$res = ( new Query() ) -> select('u.`id`, u.`nick_name`, u.`head_img`, u.`access_token`')-> from( 'user u' )
				                        -> where( [ 'u.`access_token`' => $access_token ] )//->createCommand()->getRawSql();
				                        // -> one();
				                        ->createCommand(\Yii::$app->db_media)
				                        ->queryAll();
		foreach ($res as $key => &$value) {
			$value['score'] = 0;
		}
		return $res;
	}

	/**
	 * @name 数组中的相同字段，指定字段相加
	 * @param  array $array 原数组
	 * @param  array $array 相同的字段
	 * @param  array $array 要相加的字段
	 * @return array
	 */
	public static function columnAdd($array, $sameKey, $addKey)
	{
		$item = [];
		foreach ($array as $key => $value) {
			if(!isset($item[$value[$sameKey]])){
				$item[$value[$sameKey]] = $value;
				if (isset($value['name']))
					$item[$value[$sameKey]]['game'][$value['name']] = $value['score'];
			} else{
				// $item[$value[$sameKey]] = $value;
				$item[$value[$sameKey]][$addKey] += $value[$addKey];
				if (isset($value['name']))
					$item[$value[$sameKey]]['game'][$value['name']] = $value['score'];
			}
		}
		return $item;
	}

	/**
	 * @name 数组增加键值
	 * @return [type] [description]
	 */
	public static function keyInsert(&$mData, $sData)
	{
		foreach ($mData as $key => &$value) {
			if (isset($sData[$value['access_token']]['team'])) {
				$value['team'] = $sData[$value['access_token']]['team'];
			}
		}
	}

	/**
	 * @name 二维数组根据指定键进行排序
	 * @param  [array] &$data [要排序的数组]
	 * @param  [string] $key  要排序的键
	 * @return
	 */
	public static function multiSort(&$data, $key)
	{
		foreach ($data as $key => $row) {
		    $volume[$key]  = $row['score'];
		}
		array_multisort($volume, SORT_DESC, $data);
	}

	/**
	 * @name 根据key的值进行分组
	 * @param  [array] $data [数据]
	 * @param  [string] $key 要分组的key
	 * @return [array]       [处理后的数据]
	 */
	public static function groupByKey($data, $key)
	{
		$item = [];
		foreach ($data as $value) {
			if (empty($value['access_token'])) {
				continue;
			}
			$item[$value[$key]][] = $value;
		}
		return $item;
	}

	/**
	 * @name 战队排行
	 * @param [array] $data 根据access_token查询的所有分数
	 * @return
	 */
	public static function teamRanking($data, $res)
	{
		//将查询的数据增加一个team  key
		WechatLogic::keyInsert($data, $res);
		//将team相同的score相加
		$personInfo = WechatLogic::columnAdd($data, 'team', 'score');
		//根据score进行排序
		WechatLogic::multiSort($personInfo, 'score');
		$i = 1;
		foreach ($personInfo as $key => &$value) {
			$value['team_ranking'] = $i;
			$i++;
		}
		return array_column($personInfo, null, 'team');
	}

	/**
	 * @name 处理没有数据的用户
	 * @return
	 */
	public static function disposeEmpty($access_token)
	{
		$team = NewConference::findOne(['access_token' => $access_token])->team;
		return ["score" => "-", "game" => "-", "person_ranking" => "-", "team" =>$team, "team_score" => "-", "team_rangking" => "-"];
	}

	/**
	 * @name 查找广告id
	 * @return
	 */
	public static function findAdId()
	{
		if ($ad_id = Yii::$app->redis->get('temp_set')) {
		} else {
			$ad_id = TempSet::findOne(1)->ad_id;
			Yii::$app->redis->set('temp_set', $ad_id);
			Yii::$app->redis->expire('temp_set', 60);
		}
		return $ad_id = explode(',', $ad_id);
	}

}