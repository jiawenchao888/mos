<?php

namespace app\logic;

use Yii;
use app\service\OrderService;
use yii\db\Query;
use app\models\ResourceConfig;
use app\models\Resource;
use app\models\Terminal;
use app\models\Plan;
use yii\data\Pagination;

class ResourceLogic
{

	/**
	 * @name 根据素材id查询机器id
	 * @param  [int] $resId [素材id]
	 * @author caolei
	 * @time 2018年3月20日
	 * @return array 设备id
	 */
	public static function getMachineIdByResId($resId)
	{
		$secondConnection = \Yii::$app->db2;
		// $plan_id = Yii::$app->request->post('id', '');
		$planInfo = ( new Query() ) -> select( 'p.`plan_id`,
					p.`material_id`,
					m.`machine_id`' )
		                            -> from( 'plan p' )
		                            -> leftJoin( 'plan_machine m' , "p.`plan_id` = m.`plan_id`" )
		                            -> where( [ 'p.`material_id`' => $resId ] )//->createCommand()->getRawSql();
		                            -> andWhere(['m.`is_shelves`' => 1])
		                            // -> one();
		                            ->createCommand($secondConnection)
		                            ->queryAll();
		if ($planInfo) {
			return array_column($planInfo, 'machine_id');
		} else {
			return [];
		}
	}

	/**
	 * @name 根据投放计划id查询机器id
	 * @param [int] $planId 投放计划id
	 * @return
	 */
	public static function getMachineIdByPlanId($planId)
	{
		$secondConnection = \Yii::$app->db2;
		// $plan_id = Yii::$app->request->post('id', '');
		$planMachineInfo = ( new Query() ) -> select( 'p.`plan_id`,
					p.`machine_id`' )
		                            -> from( 'plan_machine p' )
		                            -> where( [ 'p.`plan_id`' => $planId ] )//->createCommand()->getRawSql();
		                            // -> one();
		                            ->createCommand($secondConnection)
		                            ->queryAll();
		if ($planMachineInfo) {
			return array_column($planMachineInfo, 'machine_id');
		} else {
			return [];
		}
	}

	/**
	 * @name 增加同步状态
	 * @param [array] $planInfo 投放计划
	 * @param [array] $syncPlanList 同步的投放计划
	 */
	public static function addSyncStatus(&$planInfo, $syncPlanList)
	{
		foreach ($planInfo as $key => &$value) {
			if (in_array($value['plan_id'], $syncPlanList)) {
				$value['plan_status'] = 0;
			} else {
				$value['plan_status'] = 1;
			}
		}

	}

	/**
	 * @name 获取投放计划列表
	 * @param  [obj] $planObj          [投放计划模型对象]
	 * @param  [int] $machineId        [机器id]
	 * @param  [obj] $pager            [分页对象]
	 * @param  [obj] $secondConnection [数据库连接对象]
	 * @return array
	 */
	public static function getPlanList($planObj, $machineId, $page, $secondConnection)
	{
		$planInfo = $planObj->offset($page->offset)->limit($page->limit)->createCommand($secondConnection)->queryAll();
		$resId = array_filter(array_column($planInfo, 'material_id'));
		$resData = self::getResListByResId($resId, $machineId);
		self::disposeResAndPlan($resData, $planInfo);
		return $planInfo;
	}

	/**
	 * @name 拼接投放计划与素材字段
	 * @param  [array] $resData [素材]
	 * @param  [array] &$plan   [投放计划]
	 * @return
	 */
	public static function disposeResAndPlan($resData, &$plan)
	{
		$resId = array_column($resData, 'res_id');
		$res = array_reduce($resData, create_function('$res, $item', '$res[$item["res_id"]] = $item["status"]; return $res;'));
		foreach ($plan as $key => &$value) {
			if(in_array($value['material_id'], $resId)) {
				$value['status'] = $res[$value['material_id']];
			} else {
				$value['status'] = 5;
			}
		}
	}

	/**
	 * @name 根据素材id查询素材
	 * @param  array $resId 素材id
	 * @param  int $machineId 设备id
	 * @return [array]
	 */
	public static function getResListByResId($resId, $machineId)
	{
		return Terminal::find()->select(['status', 'res_id'])->where(['res_id' => $resId, 'type' => 1, 'equ_number' => $machineId])->asArray()->all();
	}

	/**
	 * @name 根据设备id,连表查询素材和终端缓存素材
	 * @param  [array or int] $machineId [机器id]
	 * @return obj
	 */
	public static function getTerminalResByMachineId($machineId)
	{
		return ( new Query() ) -> select( 'm.`id`,
			m.`resource_name`,
			m.`type`,
			m.`icon_url`,
			m.`content`,
			t.`created_time`,
			t.`updated_time`,
			t.`status`' )
                        -> from( 'mos_resource m' )
                        -> leftJoin( 'mos_terminal t' , "t.`res_id` = m.`id`" )
                        -> where( ['t.type' => 1, 't.equ_number' => $machineId ] );//->createCommand()->getRawSql();
	}

	/**
	 * @name 处理素材video_time为空字段
	 * @param  [array] &$res [素材资源]
	 * @return
	 */
	public static function disposeRes(&$res)
	{
		foreach ($res as $key => &$value) {
			if (empty(json_decode($value['content'], true)['video_time'])) {
				$value['video_time'] = '';
				unset($value['content']);
			} else {
				$value['video_time'] = json_decode($value['content'], true)['video_time'];
				unset($value['content']);
			}
		}
	}

	/**
	 * @name 终端重置素材配置
	 * @param [int] $resId [素材id]
	 * @author caolei
	 * @time 2018年3月20日
	 * @return json 方圆返回的状态
	 */
	public static function resetTerminalResConf($resId)
	{
		$machineIdArr = self::getMachineIdByResId($resId);
		if (empty($machineIdArr)) {
			return ['code' => 1, 'msg' => "素材{$resId}没有投放机器"];
		}
		//删除reids,清空数据库中的配置
		Yii::$app->redis->del('resourceConf', 'id_' . $resId);
		ResourceConfig::edit($resId, '');
		self::editReleaseTime($resId);
		return OrderService::resetResConf($machineIdArr, $resId);
	}

	/**
	 * @name 投放立即发布
	 * @param [int] $planId 投放计划id
	 * @author caolei
	 * @time 2018年3月21日
	 * @return
	 */
	public static function planReset($planId)
	{
		$machineIdArr = self::getMachineIdByPlanId($planId);
		if (empty($machineIdArr)) {
			return ['code' => 1, 'msg' => '没有相关联的机器'];
		}
		$plan = Plan::findOne($planId);
		$plan->release_time = time();
		if ($plan->save()) {
			return OrderService::syncPlan($machineIdArr, $planId);
		}
	}

	/**
	 * @name 重下素材
	 * @param  int $machineId [机器id]
	 * @param  int $resId   [素材id]
	 * @author caolei
	 * @time 2018年3月21日
	 * @return
	 */
	public static function resourceResetDownload($machineId, $resId)
	{
		$machineIdArr = (array) $machineId;
		return OrderService::resetResConf($machineIdArr, $resId);
	}

	/**
	 * @name 编辑发布时间
	 * @param [int] $resId [素材id]
	 * @author caolei
	 * @time 2018年3月20日
	 * @return [type] [description]
	 */
	public static function editReleaseTime($resId)
	{
		if ($model = Resource::findOne($resId)) {
			$model->release_time = time();
			$model->save();
		} else {
			return ;
		}
	}
}