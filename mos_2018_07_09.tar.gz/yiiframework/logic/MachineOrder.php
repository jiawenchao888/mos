<?php

namespace app\logic;

use Yii;
use app\service\CommonService;
use app\service\OrderService;
use app\models\Terminal;

class MachineOrder
{
	/**
	 * @name 终端重置二维码
	 * @param  [int] $id [网点id]
	 * @author caolei
	 * @time 2018年3月19日
	 * @return
	 */
	public static function resetTerminalErCode($id)
	{
		$total = CommonService::getMachineCountByChannelId($id);
		if (1 === $total['code']) {
			return '方圆接口有误';
		}
		$res = CommonService::getAllMachineListByChannelId($total['data']['totalCount'], $id);
		if (1 === $total['code']) {
			return '方圆接口有误';
		}
		$resArray = array_column($res, 'id');
		OrderService::createHeartBatchDownloadWechatErCode($resArray);
	}

	/**
	 * @name 根据mac地址删除指令
	 * @param  [string] $macAddress [mac地址]
	 * @param  [string] $key        [指令]
	 * @author caolei
	 * @time 2018年3月19日
	 * @return
	 */
	public static function deleteOrderByMacAddress($macAddress, $key)
	{
		if ($machineId = Yii::$app->redis->hget('machineIdByMacAddress', $macAddress)) {
			return CommonService::delMachineOrder($machineId, $key);
		}
		$equ_info = Terminal::getMachineInfoByMac($macAddress);
		$machineId = $equ_info['id'];
		Yii::$app->redis->hset('machineIdByMacAddress', $macAddress, $equ_info['id']);
		CommonService::delMachineOrder($machineId, $key);
	}

}