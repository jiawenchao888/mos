<?php

namespace app\logic;

use Yii;
use app\service\OrderService;
use yii\db\Query;
use app\models\ResourceConfig;
use app\models\Resource;
use app\models\Terminal;
use app\models\PlanMachine;
use app\models\Plan;
use yii\data\Pagination;

class TerminalLogic
{

	/**
	 * 新增机器投放计划
	 * @param [array] $planId      [投放计划]
	 * @param [int] $machineId   [机器id]
	 * @param [array] $machineInfo [机器详情]
	 * @author caolei
	 * @return array
	 */
	public static function addPlanMachine($planId, $machineId, $machineInfo, $channel)
	{
		//查询所有的未过期的machinePlan表中的投放计划
		$planMachine = PlanMachine::getPlanListByDateMachinId($machineId);
		if (empty($planMachine)) {
			$planMachineId = [];
		} else {
			$planMachineId = array_column($planMachine, 'plan_id');
		}
		//将planId 取差集
		$diffId = array_diff($planId, $planMachineId);
		$diffPlan = Plan::getPlanList($diffId, $channel);
		// var_dump($diffPlan);die;
		//将diffId百分比和planMachineId百分比相加
		$planMachineTotalPercent = array_sum(array_column($planMachine, 'percent'));
		$planTotalRatio = array_sum(array_column($diffPlan, 'ratio'));
		if (($planMachineTotalPercent + $planTotalRatio) > 100) {
			$data['code'] = 1;
		} else {
			//将差集入库
			foreach ($diffPlan as $key => $value) {
				//如果数据不存在进行添加操作
				if (empty(PlanMachine::findOne(['plan_id' => $value['plan_id'], 'machine_id' => $machineId]))) {
						$machineDate[] = [
							'plan_id'        => $value['plan_id'] ,
							'machine_type'   => $machineInfo['typeId'],
							'machine_id'     => $machineId,
							'material_id'    => $value[ 'material_id' ] ,
							'select_area_id' => $value['area_id'] ,
							'is_trigger'     => $value[ 'is_trigger' ] ,
							'percent'        => $value['ratio'] ,
							'start_time'     => $value['start_time'] ,
							'end_time'       => $value['end_time'] ,
							'is_shelves'	 => 1,
						];
				}
			}
			if (!empty($machineDate)) {
				PlanMachine::batchInsert([], $machineDate);
			}
			$data['code'] = 0;
		}
		return $data;
	}
}
