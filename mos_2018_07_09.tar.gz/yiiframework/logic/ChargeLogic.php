<?php

namespace app\logic;

use Yii;
// use app\models\Terminal;
use app\models\NetpointWechat;
use app\service\CommonService;
use app\controllers\CommonController;

class ChargeLogic
{


	/**
	 * @name 根据redis获取mac网点id
	 * @param  [type] $macAddress [description]
	 * @return [type]             [description]
	 */
	public static function redisGetPointIdByMac($macAddress)
	{
		$machineInfo = Yii::$app->redis->hget('machineInfoByMacAddress', $macAddress);
		$tmp = [];
		$machineInfo = json_decode($machineInfo, true);
		if ($machineInfo) {
			foreach ($machineInfo['channels'] as $key => $value) {
				if ($value['level'] == 4) {
					$tmp['machine_id'] = $machineInfo['id'];
					$tmp['netpoint_id'] = $value['id'];
					return $tmp;
				}
			}
		} else {
			return 0;
		}
	}


	/**
	 * @name 终端获取二维码
	 * @param  [type] $mac  [description]
	 * @param  [type] $port [description]
	 * @return [type]       [description]
	 */
	public static function terminalGetChargeCodeEr($macAddress, $port)
	{
		$netPointId = self::pointIdByMac($macAddress);
		if ($netPointId === 0) {
			return 0;
		}
		$data = [
			'mac' => $macAddress,
			'port' => $port,
		];
		$model = new NetpointWechat();
		if ($url = $model->getUrlByNetPointId($netPointId['netpoint_id'])) {
			// MachineOrder::deleteOrderByMacAddress($macAddress, Yii::$app->params['machineOrder']['downloadWechatErCode']);
			return json_encode(CommonController::HttpClient($url, $data, 'get'));
		} else {
			// $url = Yii::$app->params['weChat']['makeErCode'];
			$url = WechatLogic::getDefaultWechat(1);
			return json_encode(CommonController::HttpClient($url, $data, 'get'));
		}
	}

	/**
	 * redis 获取单个二维码
	 * @param  [type] $macAddress [description]
	 * @param  [type] $port       [description]
	 * @return [type]             [description]
	 */
	public static function redisSingleGetChargeCodeEr($macAddress, $port)
	{
		$redis = Yii::$app->redis;
		if($url = $redis->hget('machineErCode', $macAddress . "_" . $port)){
			return json_encode(['code' => 0, "data" => [$port => $url]]);
		} else {
			return 0;
		}
	}

	/**
	 * redis 获取mac全部二维码
	 * @param  [type] $macAddress [description]
	 * @return [type]             [description]
	 */
	public static function redisBatchChargeCodeEr($macAddress)
	{
		$redis = Yii::$app->redis;
		$tmp[] = 'machineErCode';
		for ($i=1; $i <= 8; $i++) {
			$tmp[] = $macAddress . "_" . $i;
		}
		$data = $redis->executeCommand('HMGET', $tmp);
		if (in_array('', $data)) {
			return 0;
		} else {
			$j = 1;
            foreach ($data as $key => $value) {
                    $er_data[$j] = $value;
                    ++$j;
            }
            return json_encode(['code' => 0, "data" => $er_data]);
		}
	}

	/**
	 * @name 根据mac获取网点
	 * @param  [type] $macAddress [description]
	 * @return [type]             [description]
	 */
	public static function pointIdByMac($macAddress)
	{
		//通过redis查询
		if ($data = ChargeLogic::redisGetPointIdByMac($macAddress)) {
			return $data;
		}
		//如果redis中没有查询到，在走方圆
		$machineInfoApi = Yii::$app->params['apiBaseList']['apiMachineMacAddress'];
		$machineInfoData = [
			"macAddress" => $macAddress,
			"field" => 'channel_id,id',
		];
		$machineInfo = CommonService::httpShenYao($machineInfoApi, $machineInfoData);
		$tmp = [];
		if ($machineInfo['code'] === 0) {
			foreach ($machineInfo['data']['channels'] as $key => $value) {
				if ($value['level'] == 4) {
					$tmp['machine_id'] = $machineInfo['data']['id'];
					$tmp['netpoint_id'] = $value['id'];
					return $tmp;
				}
			}
		} else {
			return 0;
		}
	}

	/**
	 * 定时任务获取macAddres的二维码
	 * @return [type] [description]
	 */
	public static function actionCotErCode()
	{
		set_time_limit(0);
		$redis = Yii::$app->redis;
		$macAddress = $redis->hkeys('machineInfoByMacAddress');
		foreach ($macAddress as $key => $value) {
			for ($i=1; $i <= 8 ; $i++) {
				$data = ChargeLogic::terminalGetChargeCodeEr($value, $i);
				$redis->hset('machineErCode', $value . "_" . $i, json_decode($data, true)['data'][$i]);
			}
		}
	}

}