<?php

namespace app\logic;

use Yii;
use app\models\Jackpot;
use app\models\Award;
use app\models\Terminal;
use app\models\AwardTicket;
use app\service\RedirectService;
use app\service\CurlService;
use app\commands\Rsa;

class JackpotLogic
{

	/**
	 * @name 获取奖池配置
	 * @return [data]
	 */
	public static function getResConJackPot($id)
	{
		$jackpot = new Jackpot;
		$award = new Award;
		$jackpot_data = $jackpot->listt($id);
		$jackpot_data = array_column((array)$jackpot_data, NULL, 'id');
		$data = [];
		// var_dump($jackpot_data);die;
		foreach ($jackpot_data as $j_key => $j_value) {
			$temp_value = json_decode($j_value['award_list'], true);
			$jack_value = array_column($temp_value, null, 'id');
			// var_dump($jack_value);die;
			$jackpot_key = array_keys($jack_value);
			$award_data = $award->listt($jackpot_key);
			foreach ($jackpot_key as $key => $value) {
				if ($value == 0) {
					continue;
				}
				$award_data[$key]['probability'] = $jack_value[$value]['probability'];
				$data['id'] = $j_value['id'];
				$data['awards'][] = $award_data[$key];
				$data['url'] = $_SERVER['HTTP_HOST'];
			}
			$data1[] = $data;
		}
		return $data1;
	}

	/**
	 * @name 获取领奖二维码
	 * @param $post 表单提交的数据
	 * @return
	 */
	public static function getPrizeErCode($post)
	{
		var_dump($post);die;
		if (0 === $post['awardId']) {
			return '';
		}
		$machineId = CurlService::getMachineInfoByMacAddres($post['mac'])['data']['id'];
		$data = [
			'macid' => $machineId, // 设备id
			'aid' => $post['awardId'], //奖品id
			'planid' => $post['plan_id'], //投放计划id
			'time' => time() //时间
		];
		// 生成 公众号 二维码
		$qrCode = RedirectService::getWxQrCode($data);
		return $qrCode;
	}

	/**
	 * @name 生成领奖唯一码存入缓存
	 * @return int
	 */
	public static function uniqueCodePrize()
	{
		$uniqueCode = time() . rand(1,99999);
		$model = new AwardTicket;
		$model->add(['unique_code' => $uniqueCode]);
		return $uniqueCode;
	}

}
