<?php
return [
	 'class' => 'yii\redis\Connection',
	 'hostname' => '106.75.90.149',
	 'password' => 'datu@com',
	 'port' => 6379,
	 'database' => 3,
];