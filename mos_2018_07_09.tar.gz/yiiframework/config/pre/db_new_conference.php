<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=106.75.17.97;dbname=media',
    'username' => 'shop',
    'password' => 'datushao',
    'charset' => 'utf8',
    // 'tablePrefix' => 'mos_',
];
