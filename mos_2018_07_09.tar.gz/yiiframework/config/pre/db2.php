<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=10.19.91.114;port=3306;dbname=advertisement',
    'username' => 'root',
    'password' => 'MySQL123Pwd',
    'charset' => 'utf8',
];