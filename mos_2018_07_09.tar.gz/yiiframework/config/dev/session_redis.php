<?php
return [
	 'hostname' => '192.168.100.37',
	 //'password' => 'datu@com',
	 'port' => 6379,
	 'database' => 4,

];