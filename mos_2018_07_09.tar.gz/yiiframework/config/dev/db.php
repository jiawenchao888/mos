<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=192.168.100.37;dbname=mos_exhibition',
    'username' => 'mos',
    'password' => 'iqWytMMlD1mIbwpC',
    'charset' => 'utf8',
    'tablePrefix' => 'mos_',
];
