<?php
$params = require_once  __DIR__ . '/' . YII_ENV . '/params.php';

$globalParams = [
    // 本项目针对设备的AES密钥信息
    'aesForDevice' => [
        'cipherKey' => '1234567890123456',
    ],
    // 终端设备指令
    'machineOrder' =>[
        //下载微信二维码
    	'downloadWechatErCode' => 'Wechat_Er_Code_Download_Conf',
        //下载素材
        'downloadResConf' => 'Res_Download_Conf',
    ],
    'newApiList' => [
    	// 根据设备ID批量创建指令
    	'batchCreateByMachineIds' => '/v3/command/batch-create-by-machine-ids',
    ],
];

return array_merge($globalParams, $params);
