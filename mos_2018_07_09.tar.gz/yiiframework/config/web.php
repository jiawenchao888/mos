<?php

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'language'   => 'zh-CN' ,
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'ad98ec420b5eeb211f4f65f643fd8451',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.exmail.qq.com',  //每种邮箱的host配置不一样
                'username' => 'datu-notice@datuhongan.com',
                'password' => 'Dtha123',
                'port' => '465',
                'encryption' => 'SSL',
            ],
            'messageConfig'=>[
                'charset'=>'UTF-8',
                'from'=>['datu-notice@datuhongan.com'=>'admin']
            ],
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        // 'session' => [
        //       'class' => 'yii\redis\Session',
        //       'redis' => require(__DIR__ ."/". YII_ENV . '/session_redis.php'),
        // ],
        'redis' => require(__DIR__ ."/". YII_ENV . '/redis.php'),
        'db' => require(__DIR__ ."/". YII_ENV . '/db.php'),
        'db2' => require(__DIR__ ."/". YII_ENV . '/db2.php'),
        'db_media' => require(__DIR__ ."/". YII_ENV . '/db_new_conference.php'),
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
	        'enableStrictParsing' => false,
	        'suffix'          => '',
            'rules' => [
                '<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
                '<controller:\w+>/<action:\w+>.html'=>'<controller>/<action>',
            ],
        ],
    ],
    'modules' => [
        'v2' => [
            'class' => 'app\modules\v2\Module',
        ],
    ],
    'params' => require(__DIR__ .'/params.php'),
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];
}

return $config;
