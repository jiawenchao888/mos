<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=10.19.58.198;dbname=advertisement',
    'username' => 'datu',
    'password' => 'KsAcNxV8zQmntX4S',
    'charset' => 'utf8',
];
