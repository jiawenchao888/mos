<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=10.19.58.198;port=3306;dbname=datu_mosexhibition',
    'username' => 'datu',
    'password' => 'KsAcNxV8zQmntX4S',
    'charset' => 'utf8',
    'tablePrefix' => 'mos_'
];
