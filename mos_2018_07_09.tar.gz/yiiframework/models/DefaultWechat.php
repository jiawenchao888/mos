<?php
namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class DefaultWechat extends ActiveRecord
{

	public static function tableName()
	{
		return "{{%default_wechat}}";
	}

	public function rules()
	{
		return [
			[['name', 'wechat_url'], 'safe'],
			[['name', 'wechat_url', 'id'], 'required',],
			[['updated_time'], 'default', 'value' => time() ],
		];
	}

	public function attributeLabels() {
		return [
			'name' => '微信公众号',
			'wechat_url' => '微信公众号链接',
		];
	}

	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			Yii::$app->redis->del('defaultWechat');
			return true;
		} else {
			return false;
		}
	}

	public function get($id)
	{
		return $res = self::findOne($id);
	}

	/**
	 * @name 获取默认的微信二维码
	 * @return [type]     [description]
	 */
	public static function getWechatUrl()
	{
		// var_dump(self::findOne(2)->toArray());die;
		if ($model = self::findOne(1)) {
			return $model->toArray();
		} else {
			return ['name' => '', 'wechat_url' => ''];
		}
	}

}