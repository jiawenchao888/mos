<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class TempSet extends CommonModel
{

	public static function tableName()
	{
		return "{{%temp_set}}";
	}

	public function rules()
	{
		return [
			[['switch', 'ad_id'], 'trim'],
			// [['wechat_name', 'access_token', 'head_url'], 'required'],
			[['switch', 'ad_id'], 'unique'],
			[['created_time'], 'default', 'value' => time()],
		];
	}

	public function attributeLabels()
	{
		return [
			"switch" => '临时开关',
			"ad_id" => '广告id',
		];
	}

	/**
	 * 添加
	 * @param [array] $data [表单提交的数据]
	 * return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 编辑
	 * @param  [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function edit($data)
	{
		$this->updated_time = time();
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

}