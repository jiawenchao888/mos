<?php
namespace app\models;

use Yii;
use yii\db\Query;

class PlanMachine extends CommonModel
{

	public static function tableName()
	{
		return "{{%plan_machine}}";
	}

	public static function getDb()
	{
		return Yii::$app->get('db2');
	}

	/**
	 * @name 根据机器id查询投放计划
	 * @param  [int] $machineId [机器id]
	 * @author caolei
	 * @time 2018年3月23日
	 * @return obj
	 */
	public static function getPlanByMachineId($machineId)
	{
		return ( new Query() ) -> select( 'm.`plan_id`' )
                            -> from( 'plan_machine m' )
                            -> where( [ 'm.`machine_id`' => $machineId] )
                            -> andWhere( ['>', 'm.`end_time`', time()] );//->createCommand()->getRawSql();
	}

	/**
	 * @name 根据机器查询投放计划，并排除$planId的投放计划
	 * @param  [type] $planId    [description]
	 * @param  [type] $machineId [description]
	 * @return [type]            [description]
	 */
	public static function getPlanPercentByMachineId($planId, $machineId)
	{
		PlanMachine::find()->select(['percent', 'plan_id'])
							->where(['not in', 'plan_id', $planId])
							->andWhere( ['>', 'end_time', time()] )
							->andWhere(['machine_id' => $machineId])
							->asArray()->all();
	}

	/**
	 * 根据日期查询设备id投放计划
	 * @return [type] [description]
	 */
	public static function getPlanListByDateMachinId($machineId)
	{
		return PlanMachine::find() ->andWhere( ['>', 'end_time', time()] )
							->andWhere(['machine_id' => $machineId, 'is_shelves' => 1])
							->asArray()->all();
	}

	/**
	 * 批量入库
	 * @param  array  $field [要添加字段]
	 * @param  array  $data  [要入库的数据]
	 * @return
	 */
	public static function batchInsert ( $field = [] , $data = [] )
		{
			if ( $field == [] ) {
				$field = [
					'plan_id' ,//投放计划id
	//				'province_id' ,//省id
	//				'city_id' ,//城市id
	//				'channel_id' ,//渠道id
	//				'site_id',//网点id
	//				'position_id',//点位id
					'machine_type',//机器类型
					'machine_id',//机器id
					'material_id',//素材id
					'select_area_id',//选择投放的区域id
					'is_trigger',//是否触发
					'percent',//此计划(机器)上投放占的百分比
					'start_time',//投放计划开始时间
					'end_time',//投放计划结束时间
					'is_shelves',//投放计划是否上架
				];
			}
			
			$res=yii ::$app -> db2 -> createCommand ()
			                      -> batchInsert ( self ::tableName () , $field , $data )
			                      -> execute ();
			if($res){
				return true;
			}else{
				throw new \ErrorException('批量写入失败');
			}
		}

}