<?php
namespace app\models;

use Yii;

class UploadFile extends CommonModel
{

	public static function tableName()
	{
		return "{{%upload_file}}";
	}

	public function rules()
	{
		return [
			[['updated_time'], 'default', 'value' => 0],
			['name', 'string', 'length'=>[1,32], 'message'=>'长度超标'],
			[['name', 'url', 'type', 'created_time', 'updated_time'], 'required', 'message' => '字段不能为空'],
		];
	}

	/**
	 * @name 新增，编辑模型
	 * @author caolei
	 * @time 2017年11月21日14:02:29
	 * @param [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

}