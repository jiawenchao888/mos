<?php
namespace app\models;

use yii\db\Query;
use Yii;

class Plan extends CommonModel
{

	public static function tableName()
	{
		return "{{%plan}}";
	}

	public static function getDb()
	{
		return Yii::$app->get('db2');
	}

	/**
	 * 根据渠道查询投放计划，上架的，未过期的，等级大于5的
	 * @param  [type] $channel [description]
	 * @return [type]          [description]
	 */
	public static function planListByArea($channel)
	{
		return  ( new Query() ) -> select( 'a.`plan_id`,
							a.`area_id`,
							p.`plan_name`,
							p.`category_id`,
							p.`material_id`,
							p.`material_name`,
							c.`category_name`,
							p.`start_time`,
							p.`end_time`,
							p.`is_shelves`,
							p.`plan_total_hours`' )
                           		-> from( 'plan_area a' )
                           		-> leftJoin( 'plan p' , "p.`plan_id` = a.`plan_id`" )
                           		-> leftJoin( 'category c' , "p.`category_id`=c.`category_id`" )
                           		-> andWhere( [ 'in', 'a.`area_id`', $channel] )
                            	-> andWhere( [ 'p.`is_shelves`' => 1 ] )
                            	-> andWhere(['<>', 'a.`level`', 5])
                            	-> andWhere(['>', 'p.`end_time`', time()])
                            	-> orderBy('start_time');//->createCommand()->getRawSql();
	}

	/**
	 * 连表查询投放计划，和投放区域
	 * @param  [array] $planId [投放计划]
	 * @param  [array] $channel 渠道
	 * @return
	 */
	public static function getPlanList($planId, $channel)
	{
		return  ( new Query() ) -> select( 'a.`plan_id`,
									p.`material_id`,
									a.`area_id`,
									p.`start_time`,
									p.`end_time`,
									p.`is_trigger`,
									p.`ratio`' )
		                           		-> from( 'plan_area a' )
		                           		-> leftJoin( 'plan p' , "p.`plan_id` = a.`plan_id`" )
		                            	-> where( ['in', 'p.plan_id', $planId] )
		                            	-> andWhere( [ 'in', 'a.`area_id`', $channel] )
		                            	// -> orderBy('start_time');//->createCommand()->getRawSql();
		                            	->createCommand(\Yii::$app->db2)->queryAll();
	}

}