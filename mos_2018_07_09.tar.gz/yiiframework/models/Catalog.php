<?php
namespace app\models;

class Catalog extends CommonModel
{
    public static function tableName()
    {
	    return '{{%catalog}}';
    }

    public function rules()
    {
	    return [];
    }

	/**
	 * @name U盘刊例添加
	 * @remark U盘刊例添加
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * @param $data array 数据
	 * return
	 */
    public function addCatalog($data){
		$this->name = $data['name'];
		$this->list = $data['list'];
		$this->created_time = time();
		$this->is_finished = 0;
		$this->password = parent::generate_password(6);

		$filename = date('YmdHis').parent::generate_password(10);
		$this->zipname = $filename;

		$this->save();
	    return true;
    }

	/**
	 * @name U盘刊例编辑
	 * @remark U盘刊例编辑
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return bool
	 */
    public function editCatalog($data){
    	$model = self::findOne($data['id']);
		$model->name = $data['name'];
		$model->list = $data['list'];
		$model->created_time = time();
		$model->is_finished = 0;
		$model->password = parent::generate_password(6);

		$filename = date('YmdHis').parent::generate_password(10);
		$model->zipname = $filename;

		$model->save();
	    return true;
    }

    /**
     * @name U盘刊例删除
     * @remark U盘刊例编辑
     * @author yongkang
     * @time 2017年9月29日17:21:19
     * @return bool
     */
    public function delCatalog($id)
    {
    	$model = self::findOne($id);
    	$model->is_deleted = 1;
    	if ($model->save()) {
    		return true;
    	} else {
    		return false;
    	}
    }

}