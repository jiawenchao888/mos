<?php
namespace app\models;

use app\commands\Rsa;
use app\service\CommonService;
use yii\db\ActiveRecord;
use yii\httpclient\Client;
use yii\filters\VerbFilter;
use yii\filters\Cors;
use yii\helpers\Json;
use yii\helpers\ArrayHelper;

use Yii;

class CommonModel extends ActiveRecord{

	/**
	 * @name http请求
	 * @author caolei
	 * @param $api string 请求的接口
	 * @param $data array 发送的数据
	 * @param $type string 请求的类型
	 * @return bool | string
	 */
	public static function HttpClient($api,$data,$type)
	{
		$client = new Client();
		$response = $client->createRequest()
			->setMethod($type)
			->setUrl($api)
			->setData($data)
			->send();
		if ($response->isOk) {
			return $data = $response->data;
		}
		return false;
	}

	/**
	 * @name 通过拼接文件地址,来生成md5
	 * @remark 通过拼接文件地址,来生成md5
	 * @param $fileName 文件地址
	 * @param $fieldName 字段名称
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return string
	 */
	public static function makeMd5File($filename){
		// 网站根目录
		$webroot = Yii::getAlias('@webroot') . '/';
		if(file_exists($webroot . $filename)){
			return md5_file($webroot . $filename);
		}
		return '';
	}

	/**
	 * @name 公钥加密
	 * @author caolei
	 * @time 2017年9月26日17:26:57
	 * @return [type] [description]
	 */
	public static function keyEncrypt($str)
	{

		$webroot = Yii::getAlias('@webroot') . '/../';
		$public_key = file_get_contents(Yii::$app->params['key']['publicKey']);

		$pu_key = openssl_pkey_get_public($public_key);

		// 加密数据
		$encrypted = '';

		openssl_public_encrypt($str, $encrypted, $pu_key);//公钥加密

		$encrypted = base64_encode($encrypted);// base64传输

		return $encrypted;
	}

	/**
	 * @name 私钥解密
	 * @author caolei
	 * @time 2017年9月26日17:25:52
	 * @param  [type] $encrypted [description]
	 * @return [type]            [description]
	 */
	public static function keyDecrypt($encrypted)
	{
		$webroot = Yii::getAlias('@webroot') . '/../';
		$private_key = file_get_contents(Yii::$app->params['key']['privateKey']);

		$pi_key =  openssl_pkey_get_private($private_key);
		$decrypted = '';

		openssl_private_decrypt(base64_decode($encrypted), $decrypted, $pi_key);//私钥解密
		return $decrypted;
	}


	/**
	 * @name 获取应用授权码
	 * @2017年9月26日17:26:03
	 * @author caolei
	 * @return [type] [description]
	 */
	public static function getToken()
	{
		if ($accessToken = Yii::$app->redis->get('accessToken')) {
			return $accessToken;
		} else {
			// 加密数据
			$data = [
				'appSecret' => Yii::$app->params['appSecret'],
			];
			$data = json_encode($data);

			$encrypted = self::keyEncrypt($data);
			$arr = ['data' => $encrypted, 'appId' => Yii::$app->params['appId']];
			$api = Yii::$app->params['domainList']['domain'] . '/api/user/get-access-token';
			$res = self::HttpClient($api, $arr, 'post');
			$json_token = self::keyDecrypt($res['data']);
			$token = json_decode($json_token, true);
			Yii::$app->redis->set('accessToken', $token['accessToken']);
			Yii::$app->redis->expireat('accessToken', $token['expire']);
			return $accessToken = Yii::$app->redis->get('accessToken');
		}
	}

	/*
	 * @name 生成随机字符串
	 * @2017年9月26日17:26:03
	 * @author yongkang
	 * @return string
	 */
	public static function generate_password( $length = 8 ) {
		// 密码字符集，可任意添加你需要的字符
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$password = '';
		for ( $i = 0; $i < $length; $i++ )
		{
			$password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
		}

		return $password;
	}

	/**
	 * @name 获取图片全路径
	 * @time 2017年9月28日14:47:36
	 * @author caolei
	 * @param $url string  objectKey地址
	 * @return string|array
	 */
	public function getFullUrl($url)
	{
		if ($fullUrl = Yii::$app->redis->get('fullUrl')) {
            return $fullUrl . $url;
        } else {
            $config = [
                'publicKey' => Yii::$app->params['key']['publicKey'],
                'privateKey' => Yii::$app->params['key']['privateKey'],
            ];
            $key = new Rsa($config);
            $data = [
                'objectKey' => $url,
                'bucketName' => 'datu-ad',
                'expire' => -1,
            ];
            $url_encrypted = $key->encrypt($data);
            $url_data = [
                'appId' => Yii::$app->params['appId'],
                'accessToken' => $this->getToken(),
                'data' => $url_encrypted,
            ];
            $url_api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiFileGetFileUrl'];
            $url_res = $this->HttpClient($url_api, $url_data, 'post');
            if (0 === $url_res['code']) {
                $fullUrl = $key->decrypt($url_res['data']);
                //将域名截取并存入redis
                $strlenth = strpos($fullUrl, 'mos/api/');
                $domainUrl = substr($fullUrl, 0, $strlenth);
                Yii::$app->redis->set('fullUrl', $domainUrl);
                Yii::$app->redis->expire('fullUrl', 300);
                return $fullUrl;
            } else {
                return $url_res['msg'];
            }
        }
	}

	/**
	 * @name 获取操作记录
	 * @time 2017年10月10日15:49:38
	 * @param $dirty array 修改过的数据
	 * @param $clean array 原始数据
	 * @author caolei
	 * @return [type] [description]
	 */
	public function getSelfMatter($dirty, $clean)
	{
		$log = array_reduce(array_keys($dirty), function ($res, $key) use ($clean,$dirty) { return $res .= $dirty[$key] . '->' . $clean[$key] . "<br>";});
		if (empty($clean['name'])) {
			return $logs = $clean['resource_name'] . ":<br>" . $log;
		}
		return $logs = $clean['name'] . ":<br>" . $log;
	}

	/**
	 * @name 输出错误信息
	 * @time 2017年10月11日09:19:58
	 * @param int $code 错误代码
	 * @param string $msg 错误信息
	 * @param array $data 返回数据
	 * @return [type] [description]
	 */
	public function error($code = 1, $msg = 'error', $data = '')
	{

		if ( defined ( 'YII_ENV' ) && YII_ENV != 'prod' ) {
			echo json_encode([
				'code' => $code,
				'msg' => $msg,
				'data' => $data,
				], JSON_UNESCAPED_UNICODE);
			die;
		} else {
			echo json_encode([
				'code' => $code,
				'msg' => $msg,
				], JSON_UNESCAPED_UNICODE);
			die;
		}


	}

	/**
	 * @name 存储，查询操作日志
	 * @author caolei
	 * @time 2017年10月10日10:12:02
     * @param $type 为空执行存储，不为空执行查询
	 * @param $arr array 提交给接口的数据
	 * @return json or bool
	 */
	public function operateLog($arr, $type = '')
	{
	    if ($type) {
	        $api = Yii::$app->params['apiBaseList']['aipOtherLogList'];
	    } else {
	        $api = Yii::$app->params['apiBaseList']['apiOtherRecordLog'];
	    }
	    $res = CommonService::httpShenYao($api, $arr);
	    if (0 == $res['code']) {
		    return json_encode($res, JSON_UNESCAPED_UNICODE);
	    }
	    return false;
	}

		/**
	 * @name 截取前端提交的长地址
	 * @param  [string] $url [资源的url地址]
	 * @author caolei
	 * @time 2018年1月11日
	 * @return [string]      [截取过后的短地址]
	 */
	public function cutShortUrl($url)
	{
		if ($url) {
			return strstr($url, 'mos/api/');
		} else {
			return '';
		}
	}
}