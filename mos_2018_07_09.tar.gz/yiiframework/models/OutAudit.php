<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class OutAudit extends CommonModel
{

	public static function tableName()
	{
		return "{{%out_audit}}";
	}

	public function rules()
	{
		return [
			[['res_id', 'advert_id', 'auditor_id', 'res_name', 'advert_name', 'auditor_name', 'company_material', 'area', 'email_remind', 'email', 'start_time', 'end_time', 'auditor_email', 'auditor_remind'], 'trim'],
			[['res_id', 'advert_id', 'auditor_id', 'res_name', 'advert_name', 'auditor_name', 'company_material', 'area', 'email_remind', 'email', 'start_time', 'end_time', 'auditor_email', 'auditor_remind'], 'required'],
			[['created_time', 'check_time'], 'default', 'value' => time()],
		];
	}

	/**
	 * 添加
	 * @param [array] $data [表单提交的数据]
	 * return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '')) {
			$this->company_material = $this->disposeCompanyMaterial($this->company_material);
		} else {
			return false;
		}
		if ($this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @name 处理审核资质的图片路径
	 * @param  [type] $data [description]
	 * @return [type]       [description]
	 */
	public function disposeCompanyMaterial($data)
	{
		$data = json_decode($data, true);
		foreach ($data as $key => &$value) {
			$value['url'] = $this->cutShortUrl($value['url']);
		}
		return json_encode($data, JSON_UNESCAPED_UNICODE);
	}

	/**
	 * 编辑
	 * @param  [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function edit($data)
	{
		$this->updated_time = time();
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 详情
	 * @param [int] $resId 素材id
	 * @param [int] $createTime 创建时间
	 * @return [type] [description]
	 */
	public function detail($resId, $createTime)
	{
		$model = self::findOne(['res_id' => $resId, 'created_time' => $createTime]);
		if ($model) {
			$data = $model->toArray();
			$data['company_material'] = json_decode($data['company_material'], true);
			foreach ($data['company_material'] as $key => &$value) {
				$value['url'] = $this->getFullUrl($value['url']);
			}
			$data['company_material'] = json_encode($data['company_material'], JSON_UNESCAPED_UNICODE);
			return $data;
		} else {
			return false;
		}
	}

	/**
	 * @name 获取素材id的最大创建时间
	 * @param  [type] $res_id [description]
	 * @return [type]         [description]
	 */
	public static function getMaxCreateTime($res_id)
	{
		return $created_time = (new \yii\db\Query())
				    ->from('mos_out_audit')
				    ->where(['res_id' => $res_id])
				    ->max('created_time');
	}

}