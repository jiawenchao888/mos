<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class AwardTicket extends CommonModel
{

	public static function tableName()
	{
		return "{{%award_ticket}}";
	}

	public function rules()
	{
		return [
			[['unique_code'], 'required'],
		];
	}

	// public function attributeLabels()
	// {
	// 	return [
	// 		"user_name" => '用户名',
	// 		"account_number" => '账号',
	// 		"email" => '邮箱',
	// 		"email_remind" => '邮箱提醒',
	// 	];
	// }

	/**
	 * 添加
	 * @param [array] $data [表单提交的数据]
	 * return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 编辑
	 * @param  [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function edit($data)
	{
		$this->updated_time = time();
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

}