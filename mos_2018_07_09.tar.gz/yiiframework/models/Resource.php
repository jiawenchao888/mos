<?php

namespace app\models;

use app\service\ResourceService;
use app\service\ApkparserService;
use app\controllers\ApkParserController;
use Yii;
use yii\helpers\ArrayHelper;
use app\models\Jackpot;
use app\models\Award;
use app\models\ResourceConfig;
use app\logic\JackpotLogic;
use app\logic\ResourceLogic;

class Resource extends CommonModel
{
	public static function tableName()
	{
		return "{{%resource}}";
	}

	/**
	 * @return array 验证规则
	 */
	public function rules()
	{
		return [
			[['resource_name', 'type'], 'required', 'message' => '不能为空', 'on' => ['addRes']],
		];
	}

	/**
	 * @name 资源添加
	 * @remark 资源添加接口
	 * @author yongkang
	 * @param $type int 判读是否是更新/添加  1 添加 2 更新
	 * @time 2017年09月18日 09:27:15
	 * return bool | array
	 */
	public function addRes($data,$type=1)
	{
		if($type == 1){
			$this->created_time = time();   // 创建时间
		}

		$this->scenario = 'addRes';
		$this->resource_name = $data['resource_name'];  // 资源名字
		$this->icon_url = $this->cutShortUrl($data['icon_url']);        // icon地址
		$this->award_id = intval(!empty($data['award_id']) ? $data['award_id'] : 0);        // 奖池id
		$this->lay_status = 0;      // 法务审核
		$this->res_status = 0;      // 资源审核
		$this->type = intval($data['type']);    // 模板类型
		$this->adv_owner = intval($data['adv_owner']);   // 广告主
		$this->md5_file = json_encode([
			'icon_md5' => parent::makeMd5File($this->icon_url, 'icon'),
		]);

		// content 内容生成
		$arr = [];
		if (!empty($data['qa'])) {
			$arr['qa'] = $this->disposeQuestion($data['qa']);
		}

		$arr['inter_list'] = '';
		// 讲解
		if(!empty($data['interpretation'])){
			$arr['inter_list'] = $this->disposeInterpretation($data['interpretation'], $data['inter_title']);
		}

		$arr = $this->resType($data, $arr);

		$this->content = json_encode($arr);

		if($this->validate()){
			if($type == 2){
				ResourceService::delRedisResourceById($data['id']);
				$data = $this->getOperateLogData($data, '编辑素材', '素材');
				//将操作的记录保存
				$res = $this->operateLog($data);
				if(empty($res)){
					$this->error(13300,'保存操作日志失败',[]);
				}
			}
			//判断是数据是否有修改
			if($this->getDirtyAttributes()){
				$this->updated_time = time();   // 更新时间
			}
			$this->save();
			if($type == 1){
				// 添加后, 给奖池关联属性
				if(!empty($data['award_id'])){
					$jackpot = Jackpot::findOne($data['award_id']);
					$jackpot->is_relevance = 1;
					$jackpot->save();
				}

				// $insert_id = $this->id;
				$data['id'] = $this->id;
				$data = $this->getOperateLogData($data, '新增素材', '素材');
				//将操作的记录保存
				$res = $this->operateLog($data);
			}
			return true;
		} else {
			return $this->errors;
		}

	}

	/**
	 * @name 获取apk的包名
	 * @param $pathFile string apk的路径
	 * @return [type] [description]
	 */
	public function getApkPackageName($pathFile)
	{
		$model = new ApkparserService;
		$res = $model->open($pathFile);
		return $packageName = $model->getPackage();
	}

	/**
	 * @name 处理前端提交的问答字段
	 * @param array $data 用户提交的问答字段
	 * @return [type] [description]
	 */
	public function disposeQuestion($data)
	{
		$temp = [];
		// 获取问答的答案
		foreach($data as $key => $v){
			foreach($v['checkeds'] as $keys => $val){
				$temp[$key] = $v;
				if($val === true || $val == 'true'){
					$temp[$key]['checked'] = $v[$keys];
					break;
				}
			}
		}
		return $temp;
	}

	/**
	 * @name 处理前端提交的问答
	 * @param array $data 用户提交的问答字段
	 * @return
	 */
	public function disposeInterpretation($inter, $title)
	{
		return [
			0 => [
				'interpretation' => $inter,
				'inter_title' => $title
			]
		];
	}

	/**
	 * @name 处理应用
	 * @param [array] $data [提交的表单数据]
	 * @author caolei
	 * @time 2018年1月9日
	 * @return [array] [要入数据库的数据]
	 */
	public function resByType3($data)
	{
		$arr = [];
		if(!empty($data['app_platform']['Android'])){
			$data['app_platform']['Android']['apk_url'] = $this->cutShortUrl($data['app_platform']['Android']['apk_url']);
			$data['app_platform']['Android']['apk_md5'] = parent::makeMd5File($data['app_platform']['Android']['apk_url'], 'apk');
			$ApkPath = Yii::getAlias('@webroot') . '/' . $data['app_platform']['Android']['apk_url'];
			$data['app_platform']['Android']['packageName'] = $this->getApkPackageName($ApkPath);
		}
		$arr['app_platform'] = $data['app_platform'];   //应用平台
		$arr['app_desc'] = $data['app_desc'];   // 文字简介
		$arr['bg_url'] = $this->cutShortUrl($data['bg_url']);      // 终端 背景图片
		$arr['H5_bg_url'] = $this->cutShortUrl($data['H5_bg_url']);      // H5页面 背景图片
		$arr['bg_md5'] = parent::makeMd5File($arr['bg_url'], 'bg');
		$arr['H5_bg_md5'] = parent::makeMd5File($arr['H5_bg_url'], 'H5_bg'); // H5页面 背景图片md5

		$arr['tuiguang'] = $data['tuiguang'];   // 推广二维码/当 type = 3 时 为 apk 下载二维码
		$arr['video_url'] = $this->cutShortUrl($data['video_url']); // 视频
		$arr['video_md5'] = parent::makeMd5File($arr['video_url'], 'video');
		$arr['video_time'] = $data['video_time']; // 视频时长
		$arr['interactive_area'] = $data['interactive_area'];  //互动区弹窗 显示对应1 隐藏对应2

		if(empty($arr['bg_url'])){
			throw new \ErrorException('背景图片添加错误,请检查,或者重新上传');
		}

		if(empty($arr['H5_bg_url'])){
			throw new \ErrorException('H5页面背景图添加错误,请检查,或者重新上传');
		}
		return $arr;
	}

	/**
	 * @name 处理三分
	 * @param [array] $data [提交的表单数据]
	 * @author caolei
	 * @time 2018年1月9日
	 * @return [array] [要入数据库的数据]
	 */
	public function resByType2($data)
	{
		$arr = [];
		$arr['bg_url'] = $this->cutShortUrl($data['bg_url']);      // 终端 背景图片
		$arr['bg_md5'] = parent::makeMd5File($arr['bg_url'], 'bg');
		if (!empty($data['banner_url'])) {
			$arr['banner_url'] = $this->cutShortUrl($data['banner_url']);
			$arr['banner_url_md5'] = parent::makeMd5File($arr['banner_url'], 'banner');
		}
		$arr['tuiguang'] = $data['tuiguang'];   // 推广二维码/当 type = 3 时 为 apk 下载二维码
		if (!empty($data['video_url'])) {
			$arr['video_url'] = $this->cutShortUrl($data['video_url']); // 视频
			$arr['video_md5'] = parent::makeMd5File($arr['video_url'], 'video');
		}
		$arr['video_time'] = $data['video_time']; // 视频时长
		$arr['interactive_area'] = $data['interactive_area'];  //互动区弹窗 显示对应1 隐藏对应2

		if(empty($arr['bg_url'])){
			throw new \ErrorException('背景图片添加错误,请检查,或者重新上传');
		}
		return $arr;
	}

	/**
	 * @name 点互试触摸模板
	 * @param  [array] $data [提交的表单数据]
	 * @return array
	 */
	public function resByType11($data)
	{
		$arr = [];
		// $arr['banner_url'] = $this->cutShortUrl($data['banner_url']);      // 终端 背景图片
		// $arr['banner_md5'] = parent::makeMd5File($arr['banner_url']);
		$arr['video_time'] = $data['video_time']; // 视频时长
		$arr['redirect'] = $data['redirect'];
		// var_dump(empty($data['banner_url']));die;
		if (!empty($data['banner_url'])) {
			// echo 'aaa';die;
				$arr['banner_url'] = $this->cutShortUrl($data['banner_url']);      // 终端 背景图片
				$arr['banner_md5'] = parent::makeMd5File($arr['banner_url']);
		}
		$arr['game_score'] = $data['game_score'];//游戏分数线
		$arr['interactive_area'] = $data['interactive_area'];  //互动区弹窗 显示对应1 隐藏对应2
		// if(empty($arr['banner_url'])){
		// 	throw new \ErrorException('背景图片添加错误,请检查,或者重新上传');
		// }
		return $arr;
	}

	/**
	 * @name 处理商品模板
	 * @param  [array] $data [提交的表单数据]
	 * @author caolei
	 * @time 2018年2月6日
	 * @return [type]       [description]
	 */
	public function resByType10($data)
	{
		$arr = [];
		if(empty($data['bg_url'])){
			throw new \ErrorException('背景图片添加错误,请检查,或者重新上传');
		}

		if(empty($data['video_url'])){
			throw new \ErrorException('视频添加错误,请检查,或者重新上传');
		}
		$arr['bg_url'] = $this->cutShortUrl($data['bg_url']);      // 终端 背景图片
		$arr['bg_md5'] = parent::makeMd5File($arr['bg_url'], 'bg');
		// $arr['tuiguang'] = $data['tuiguang'];   // 推广二维码/当 type = 3 时 为 apk 下载二维码
		if (!empty($data['video_url'])) {
			$arr['video_url'] = $this->cutShortUrl($data['video_url']); // 视频
			$arr['video_md5'] = parent::makeMd5File($arr['video_url'], 'video');
		}
		$arr['commodity_id'] = $data['commodity_id']; // 商品id
		$arr['video_time'] = $data['video_time']; // 视频时长
		$arr['commodity_start_time'] = $data['commodity_start_time']; // 商品开始时间
		$arr['commodity_end_time'] = $data['commodity_end_time']; // 商品结束时间

		// $arr['interactive_area'] = $data['interactive_area'];  //互动区弹窗 显示对应1 隐藏对应2

		return $arr;
	}

	/**
	 * @name 处理全屏视频
	 * @param [array] $data [提交的表单数据]
	 * @author caolei
	 * @time 2018年1月9日
	 * @return [array] [要入数据库的数据]
	 */
	public function resByType1($data)
	{
		if (empty($data['bg_url']) && empty($data['video_url'])) {
			throw new \ErrorException('全屏图片/视频不能为空');
		}
		$arr = [];
		if (!empty($data['bg_url'])) {
			$arr['bg_url'] = $this->cutShortUrl($data['bg_url']); //全屏图片
			$arr['bg_md5'] = parent::makeMd5File($arr['bg_url'], 'bg');
		}

		$arr['tuiguang'] = $data['tuiguang'];   // 推广二维码/当 type = 3 时 为 apk 下载二维码
		if (!empty($data['video_url'])) {
			$arr['video_url'] = $this->cutShortUrl($data['video_url']); // 视频
			$arr['video_md5'] = parent::makeMd5File($arr['video_url'], 'video');
		}
		$arr['video_time'] = $data['video_time']; // 视频时长
		$arr['interactive_area'] = $data['interactive_area'];  //互动区弹窗 显示对应1 隐藏对应2

		return $arr;
	}

	/**
	 * @name 截取前端提交的长地址
	 * @param  [string] $url [资源的url地址]
	 * @author caolei
	 * @time 2018年1月11日
	 * @return [string]      [截取过后的短地址]
	 */
	public function cutShortUrl($url)
	{
		if ($url) {
			return strstr($url, 'mos/api/');
		} else {
			return '';
		}
	}

	/**
	 * @name 处理列表模板
	 * @param  [array] $data [提交的表单数据]
	 * @author caolei
	 * @time 2018年1月8日
	 * @return [array]       [要入数据库的数据]
	 */
	public function resByType4($data)
	{
		$arr = [];
		$arr['bg_url'] = $this->cutShortUrl($data['bg_url']);//全屏图片
		$arr['bg_md5'] = parent::makeMd5File($arr['bg_url'], 'bg');
		$arr['video_time'] = $data['video_time'];//素材时长
		$arr['contact_app'] = $this->cutShortUrl($data['contact_app']);//关联的apk
		$arr['contact_app_md5'] = parent::makeMd5File($arr['contact_app'], 'contact_app');
		$arr['set_list'] = $this->listModel4SetList($data['set_list']);
		return $arr;
	}

	/**
	 * @name resByType4中处理  $arr['set_list']字段
	 * @param [type] $data $arr['set_list'] 数组字段
	 * @author caolei
	 * @time 2018年1月8日
	 * @return array
	 */
	public function listModel4SetList($data)
	{
		foreach ($data as $key => &$value) {
			$value['cover_url'] = $this->cutShortUrl($value['cover_url']);
			$value['cover_url_md5'] = parent::makeMd5File($value['cover_url'], 'cover');
			$value['detail_url'] = $this->cutShortUrl($value['detail_url']);
			$value['detail_url_md5'] = parent::makeMd5File($value['detail_url'], 'detail');
		}
		return $data;
	}

	/**
	 * @name 获取添加日志的数据
	 * @param $data array resource中的数据
	 * @param $data1 string 操作类型
	 * @param $data2 string 资源类型
	 * @author caolei
	 * @time 2018年1月2日
	 * @return
	 */
	public function getOperateLogData($data, $data1, $data2)
	{
		return [
			'projectName' => 'mos',
			'controllerName' => 'Resource',
			'actionName' => 'addRes',
			'type' => 'insert', //新增=insert、更新=update、删除=delete
			'userId' => $data['user_id'],
			'data1' => $data1, //操作类型
			'data2' => $data2, //资源类型
			'data3' => $data['id'], //资源类型对应的id
			'time' => time(),
		];
	}

	/**
	 * @name 获取配置文件接口
	 * @remark 获取配置文件接口
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return bool | array
	 */
	public function getResConf($id='')
	{
		if(empty($id)){
			return false;
		}
		$id = explode(',', $id);
		$data = [];
		foreach ($id as $key => $value) {
			if ($result = Yii::$app->redis->hget('resourceConf','id_'.$value)) {
				$resource = json_decode($result, true);
				$data[$resource['type']][] = $resource;
			} elseif($result = ResourceConfig::getConfig($value)) {
				$resource = json_decode($result, true);
				$data[$resource['type']][] = $resource;
				Yii::$app->redis->hset('resourceConf','id_'.$value, $result);
			} else {
				if ($result = self::find()->where(['id' => $value])->asArray()->all()) {
					$resource = json_encode($this->formatRes($result[0]));
					//配置如数据库
					ResourceConfig::add($value, $resource);
					Yii::$app->redis->hset('resourceConf','id_'.$value, $resource);
					$data[$result[0]['type']][] = json_decode($resource, true);
				}
			}
		}
		return $data;
	}

	/**
	 * @name 格式化资源文件
	 * @remark 格式化资源文件
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return array
	 */
	public function formatRes($data = [])
	{
		$content = json_decode($data['content'], true);
		$arr = [];
		//1、全屏视频  2、三分视频   3、应用配置  4、列表   10、商品  11、触摸模板
		$fnName = "formatResByType" . $data['type'];
		$arr = $this->$fnName($data, $content);
		return $arr;
	}

	/**
	 * @name 格式化资源文件通过type1
	 * @remark 格式化资源文件通过type1
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return array
	 */
	public function formatResByType1($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr = [
			'id' => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
			],
			'award_id'=>$data['award_id'],
			'tuiguang'=>$content['tuiguang'],
			'interactive_area' => $content['interactive_area'],
		];

		if (!empty($content['video_url'])) {
			$arr['filelist']['video_url'] = ['url'=>$this->joinFileUrl($content['video_url']), 'md5'=>$content['video_md5']];
		} else if (!empty($content['bg_url'])) {
			$arr['filelist']['bg_url'] = ['url'=>$this->joinFileUrl($content['bg_url']), 'md5'=>$content['bg_md5']];
		}

		if(!empty($content['video_time'])){
			$arr['video_time'] = $content['video_time'];
		}

		if(!empty($content['qa'])&&!empty($content['qa'][0]['question'])){
			$arr['qa'] = $content['qa'];
			//处理问答给终端，多选2017年12月19日09:24:00
			// $arr['qa'] = $this->actionQuestionDispose($content['qa']);
		}
		if(!empty($content['inter_list'])){
			$arr['inter_list'] = $content['inter_list'];
		}


		return $arr;
	}

	/**
	 * @name 处理问题答案，展示给终端,用在formatResByType中
	 * @param  [arr] $data [素材添加的问题]
	 * @author caolei
	 * @time 2017年12月19日09:25:18
	 * @return [type]       [description]
	 */
	public function actionQuestionDispose($data)
	{
		foreach ($data as &$value) {
			foreach ($value as $key => &$val) {
				if (false !== strpos($key, 'value')) {
					$temp['optionContent'] = $val;
					$temp['isRight'] = $value['checkeds'][$key];
					$value['list'][] = $temp;
					unset($value[$key]);
				}
			}
			unset($value['checkeds']);
			unset($value['checked']);
		}
		return $data;
	}

	/**
	 * [formatResByType11 description]
	 * @author caolei
	 * @time 2018年2月7日
	 * @return [type]          [description]
	 */
	public function formatResByType11($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr = [
			'id'    => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'redirect' => $content['redirect'],
			'video_time' => $content['video_time'],// 视频时长
			'game_score' => $content['game_score'],//游戏分数线
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
				// 'banner_url'    => ['url'=>$this->joinFileUrl($content['banner_url']), 'md5'=>$content['banner_md5']],
			],
		];
		if (!empty($content['banner_url'])) {
			$arr['filelist']['banner_url'] = ['url'=>$this->joinFileUrl($content['banner_url']), 'md5'=>$content['banner_md5']];
		}
		if(!empty($content['qa'])&&!empty($content['qa'][0]['question'])){
			$arr['qa'] = $content['qa'];
		}
		if(!empty($content['inter_list'])){
			$arr['inter_list'] = $content['inter_list'];
		}
		return $arr;
	}

	/**
	 * [formatResByType10 description]
	 * @author caolei
	 * @time 2018年2月7日
	 * @return [type]          [description]
	 */
	public function formatResByType10($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr = [
			'id'    => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
				'bg_url'    => ['url'=>$this->joinFileUrl($content['bg_url']), 'md5'=>$content['bg_md5']],
				'video_url' => ['url'=>$this->joinFileUrl($content['video_url']), 'md5'=>$content['video_md5']],
			],
			'award_id'=>$data['award_id'],
			'video_time' => $content['video_time'],
			'commodity_start_time' => $content['commodity_start_time'],
			'commodity_end_time' => $content['commodity_end_time'],
		];
		return $arr;
	}

	/**
	 * @name 格式化资源文件通过type2
	 * @remark 格式化资源文件通过type2
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return array
	 */
	public function formatResByType2($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr = [
			'id'    => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
				'bg_url'    => ['url'=>$this->joinFileUrl($content['bg_url']), 'md5'=>$content['bg_md5']]
			],
			'award_id'=>$data['award_id'],
			'tuiguang'=>$content['tuiguang'],
			'interactive_area' => $content['interactive_area'],
		];

		if (!empty($content['video_url'])) {
			$arr['filelist']['video_url'] = ['url'=>$this->joinFileUrl($content['video_url']), 'md5'=>$content['video_md5']];
		} else if (!empty($content['bg_url'])) {
			$arr['filelist']['banner_url'] = ['url'=>$this->joinFileUrl($content['banner_url']), 'md5'=>$content['banner_url_md5']];
		}

//		$arr['qa'] ='';
		if(!empty($content['video_time'])){
			$arr['video_time'] = $content['video_time'];
		}
		if(!empty($content['qa'])&&!empty($content['qa'][0]['question'])){
			$arr['qa'] = $content['qa'];
			//处理问答给终端，多选2017年12月19日09:24:00
			// $arr['qa'] = $this->actionQuestionDispose($content['qa']);
		}
		if(!empty($content['inter_list'])){
			$arr['inter_list'] = $content['inter_list'];
		}

		return $arr;
	}

	/**
	 * @name 格式化资源文件通过type3
	 * @remark 格式化资源文件通过type3
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return array
	 */
	public function formatResByType3($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr= [
			'id' => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
				'video_url' => ['url'=>$this->joinFileUrl($content['video_url']), 'md5'=>$content['video_md5']],
				'bg_url'    => ['url'=>$this->joinFileUrl($content['bg_url']),'md5'=>$content['bg_md5']],
				'H5_bg_url' => ['url'=>$this->joinFileUrl($content['H5_bg_url']),'md5'=>$content['H5_bg_md5']],
			],
			'interactive_area' => $content['interactive_area'],
			'app_name' => $data['resource_name'],
			'app_desc' => $content['app_desc'],
			'tuiguang' => $this->joinFileUrl($content['tuiguang']),
			'app_store' => ''
		];
//		$arr['qa'] ='';
		if(!empty($content['video_time'])){
			$arr['video_time'] = $content['video_time'];
		}
		if(!empty($content['qa'])&&!empty($content['qa']['question'])){
			$arr['qa'] = $content['qa'];
		}
//		$arr['inter_list'] ='';
		if(!empty($content['inter_list'])){
			$arr['inter_list'] = $content['inter_list'];
		}


		//拼接平台
//		$apk = '';
		if(array_key_exists('iOS', $content['app_platform'])&&array_key_exists('Android', $content['app_platform'])){
			$app['plateform'] = 'ios&android';
			$app['ios_size'] = $content['app_platform']['iOS']['size'];
			$app['android_size'] = $content['app_platform']['Android']['size'];
			$arr['app_store'] = $content['app_platform']['iOS']['apk_url'];
			$apk = ['url'=>$this->joinFileUrl($content['app_platform']['Android']['apk_url']), 'md5'=>$content['app_platform']['Android']['apk_md5']];

		}elseif(array_key_exists('iOS', $content['app_platform'])&&!array_key_exists('Android', $content['app_platform'])){
			$app['plateform'] = 'ios';
			$app['ios_size'] = $content['app_platform']['iOS']['size'];
			$arr['app_store'] = $content['app_platform']['iOS']['apk_url'];

//			$app['app_url'] = $content['app_platform']['ios']['apk_url'];

		}elseif(array_key_exists('Android', $content['app_platform'])&&!array_key_exists('iOS', $content['app_platform'])){
			$app['plateform'] = 'android';
			$app['android_size'] = $content['app_platform']['Android']['size'];
			$apk= ['url'=>$this->joinFileUrl($content['app_platform']['Android']['apk_url']), 'md5'=>$content['app_platform']['Android']['apk_md5']];
		}
		else{
			$app['plateform'] = 'null';
		}

		$arr += $app;
		if(!empty($apk)){
			$arr['filelist']['apk']=$apk;
		}

		return $arr;
	}

	/**
	 * @name 格式化资源文件通过type4
	 * @author caolei
	 * @time 2018年1月7日
	 * @return [array]
	 */
	public function formatResByType4($data, $content)
	{
		$file = json_decode($data['md5_file'],1);
		$arr = [
			'id' => $data['id'],
			'resource_name' => $data['resource_name'],
			'type' => $data['type'],
			'filelist' => [
				'icon' => ['url'=>$this->joinFileUrl($data['icon_url']), 'md5'=>$file['icon_md5']],
				'bg_url' => ['url'=>$this->joinFileUrl($content['bg_url']), 'md5'=>$content['bg_md5']],
			],
			'award_id'=>$data['award_id'],
			'set_list' => $this->formatResByType4SetList($content['set_list'], $data),
			'video_time' => $content['video_time'],
		];
		if ($content['contact_app']) {
			$arr['filelist']['apk'] = ['url'=>$this->joinFileUrl($content['contact_app']), 'md5'=>$content['contact_app_md5']];
		}
		return $arr;
	}

	/**
	 * @name 格式化处理set_list资源
	 * @param set_list 数据
	 * @author caolei
	 * @time 2018年1月8日
	 * @return array
	 */
	public function formatResByType4SetList($content, $data)
	{
		$arr = [];
		foreach ($content as $key => $value) {
			// $arr[$key]['id'] = $value['id'];
			$arr[$key]['resource_name'] = $value['name'];
			$arr[$key]['relative_id'] = $data['id'];
			$arr[$key]['filelist'] = [
				'icon' => ['url' => $this->joinFileUrl($value['cover_url']), 'md5' => $value['cover_url_md5']],     //终端机icon图
				'bg_url' => ['url' => $this->joinFileUrl($value['detail_url']), 'md5' => $value['detail_url_md5']], //终端机背景图
			];
		}
		return $arr;
	}

	/**
	 * @name 通过拼接文件地址,来返回文件全路径
	 * @remark 通过拼接文件地址,来返回文件全路径
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return string
	 */
	public function joinFileUrl($filename){

		if(empty($filename)){
		    return '';
		}else {
			return $this->getFullUrl($filename);
		}
//		return self::$_fileUrl . $filename;
	}

	/**
	 * @name 获取素材，全部或者多个
	 * @author caolei
	 * @time 2017年9月15日13:51:58
	 * @param  string $id [description]
	 * @return [array]     [单个或多个素材]
	 */
	public function getData($id)
	{
		//如果为数组表示查询多个或者单个素材
		$id = explode(',', $id);
		$resource = self::findAll($id);
		$data['list'] = \yii\helpers\ArrayHelper::toArray($resource);
		return $data;
	}


	/**
	 * @name 获取素材文件列表,包括奖池
	 * @author yongkang
	 * @time 2017年09月27日19:11:15
	 * @param  array $id [description]
	 * @return [array] 多个素材
	 */
	public function getFilelistByResId($id)
	{
		$allResource = Resource::find()
			->where(['id' => $id])
			->asArray()
			->all();

		$filelist = [];

		foreach($allResource as $key=>$data){

			//获取奖池列表
			if($data['award_id']!=0){
				$filelist = array_merge($filelist,$this->getFileAwardlist($data['award_id']));
			}
			$content = json_decode($data['content'],1);
			if(!empty($data['icon_url'])){
				$filelist[] = $data['icon_url'];
			}

			if (!empty($content['banner_url'])) {
				$filelist[] = $content['banner_url'];
			}

			if (!empty($content['contact_app'])) {
				$filelist[] = $content['contact_app'];
			}

			if (!empty($content['set_list'])) {
				foreach ($content['set_list'] as $key => $value) {
					array_push($filelist, $value['cover_url']);
					array_push($filelist, $value['detail_url']);
				}
			}

			if(!empty($content['video_url'])){
				$filelist[] = $content['video_url'];
			}

			if(!empty($content['bg_url'])){
				$filelist[] = $content['bg_url'];
			}

			if(!empty($content['H5_bg_url'])){
				$filelist[] = $content['H5_bg_url'];
			}

			if(!empty($content['app_platform']) && array_key_exists('Android', $content['app_platform'])){
				$filelist[] = $content['app_platform']['Android']['apk_url'];
			}
		}
		return $filelist;
	}


	/**
	 * @name 获取奖池文件
	 * @author yongkang
	 * @time 2017年09月27日19:11:15
	 * @param int $id [description]
	 * @return [array] 多个素材
	 */
	public function getFileAwardlist($id)
	{
		$award_list = Jackpot::findOne($id)->award_list;
		$award_list = array_column(json_decode($award_list,1),'id');
		$award_list = array_diff($award_list,['0']); //获取所有奖池的奖品id
		$award_list = Award::find()->where(['id'=>$award_list])->select(['id','img_url'])->asArray()->all();
		$award_list = array_column($award_list,'img_url');
		return $award_list;
	}


	/**
	 * @name 给素材压缩包生成的Conf
	 * @author yongkang
	 * @time 2017年09月27日19:11:15
	 * @param array $id id
	 * @param string $fileroot 文件生成路径
	 * @return [array] 多个素材
	 */

	public function getConfigByResIdForZip($id, $fileroot){
		$allResource = Resource::find()
			->where(['id' => $id])
			->asArray()
			->all();

		foreach($allResource as $key=>$value1){
			//获取奖池列表
			if($value1['award_id']!=0){
				$id = $value1['award_id'];
				$data = JackpotLogic::getResConJackPot($id);
				if($data) {
					//生成配置文件
					//type_id    type 1 = 全屏  2 = 三分 3 = 应用 4 = 奖池 5 = mos 6 列表 10 商品
					file_put_contents($fileroot . '/4_' . $value1['award_id'].'.txt',json_encode($data));
				}
			}

			$result = $this->formatRes($value1);

			//type_id    type 1 = 全屏  2 = 三分 3 = 应用 4 = 奖池 5 = mos 6列表 10商品
			file_put_contents($fileroot . '/' . $this->disposeType($value1['type']) . '_' . $value1['id'].'.txt',json_encode($result));

		}
	}

	/**
	 * @name 处理压缩包的类型
	 * @param $type int 类型 4应该转化为6列表
	 * @return [type] [description]
	 */
	public function disposeType($type)
	{
		if ($type == 4) {
			return 6;
		} else {
			return $type;
		}
	}

	/**
	 * @name 素材删除
	 * @author caolei
	 * @time 2017年9月30日10:33:52
	 * @return [type]     [description]
	 */
	public function delRes($id, $value=1)
	{
		$model = self::findOne($id);
		$model->is_deleted = $value;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @name 素材恢复
	 * @author caolei
	 * @time 2017年12月13日15:32:49
	 * @return [type] [description]
	 */
	public function restore($id)
	{
		$model = self::findOne($id);
		$model->is_deleted = 0;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @name 查询单个素材详情
	 * @author caolei
	 * @time 2017年10月19日09:51:00
	 * @return array
	 */
	public function details($id)
	{
		$model = self::findOne($id);
		$model = ArrayHelper::toArray($model);
		if ($model) {
			return $model;
		} else {
			return false;
		}
	}

	/**
	 * @name 素材类型
	 * @param  [array] $data [表单提交的数据]
	 * @param  [array] $arr  [入库数据]
	 * @return
	 */
	public function resType(&$data, &$arr)
	{
		$fnName = "resByType" . $data['type'];
		return $arr = array_merge($arr, $this->$fnName($data));
	}

}