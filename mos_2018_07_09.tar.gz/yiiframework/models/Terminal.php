<?php
namespace app\models;

use app\commands\Rsa;
use app\service\TerminalService;
use app\service\CurlService;
use yii;

class Terminal extends CommonModel
{

	public static function tableName()
	{
		return "{{%terminal}}";
	}

	public function rules()
	{
		return [
			['res_id', 'required', 'message'=>'不能为空','on'=>['add']],
		];
	}

	/**
	 * @name 终端素材添加接口 - 单条
	 * @remark 终端素材添加接口 - 单条
	 * @author yongkang
	 * @time 2017年9月20日11:41:27
	 * @return bool
	 */
	public static function addTerminalsingle($data)
	{
			//设备id
			if(empty($data['equ_number'])){
				// $equinfo = self::getMachineInfoByMac($data['mac']);
				$equinfo = CurlService::getMachineInfoByMacAddres($data['mac'])['data'];
				$data['equ_number'] = $equinfo['id'];
				$data['equ_typeid'] = $equinfo['typeId'];
			}

			if(empty($data['updated_time'])){
				$data['updated_time'] = $data['time'];
			}

			$res = self::find()
				->where(['res_id' => $data['res_id'], 'equ_number'=>$data['equ_number'],'type' => $data['type']])
				->one();

			if(empty($res)){
				$res = new Terminal();
				$res->created_time = time();
				$res->updated_time = time();
				$res->res_id = $data['res_id'];    //素材id
				$res->equ_number = $data['equ_number']; //设备id
				$res->equ_typeid = $data['equ_typeid']; //设备类型id
				$res->type = $data['type'];    //类型
			}else{
				// 设定更新时间
				$res->updated_time = $data['updated_time'];
			}

			$res->status = $data['status'];//状态
			$result = $res->save();
			return $result;
	}

	/**
	 * @name 终端素材添加通过过去素材列表添加
	 * @remark 终端素材添加通过过去素材列表添加
	 * @author yongkang
	 * @time 2017年9月20日11:41:27
	 * @param $id array|string id
	 * @param $mac string mac address
	 * @param $type int type
	 * @return bool
	 */
	public static function addTerminalbyresconf($id, $mac, $type = 1)
	{
		try {
			$equ_info = self::getMachineInfoByMac($mac);
			$equ_number = $equ_info['id'];
			$equ_typeid = $equ_info['typeId'];
			//生成对应的数组
			$id = explode(',', $id);
			//兼容老版本过滤负数
			$id = array_filter(array_map(function($n) { if($n > 0) return $n; }, $id));
			foreach($id as $v){
				$data = [
					'res_id' => $v,
					'equ_number'   => $equ_number,
					'equ_typeid'   => $equ_typeid,
					'type' => $type,
					// 'status' => $status,
					'updated_time' => time()
				];
				self::addTerminalsingle($data);
			}
			return true;
		} catch (\Exception $e) {
			return false;
		}
	}


	/**
	 * **
	 * @name 终端素材添加接口 - 多条
	 * @remark 终端素材添加接口 - 多条
	 * @author yongkang
	 * @time 2017年9月20日11:41:27
	 * @return bool
	 */
	public function addTerminalarray($data)
	{
		try {
			$data['data'] = json_decode($data['data'],1);

			$equ_info = self::getMachineInfoByMac($data['mac']);
			$equ_number = $equ_info['id'];
			$equ_typeid = $equ_info['typeId'];


			// 设备id 对应的所有素材状态改为5
			$sql = Yii::$app->db->createCommand()->update('mos_terminal', ['status'=>5],'equ_number='.$equ_number.' and type=1')->getRawSql();

			foreach($data['data'] as $val){
				$temp = [
					'res_id' => $val['id'],
					'type' => $data['type'],
					'status' => $val['status'],
					'equ_number'=> $equ_number,
					'equ_typeid' => $equ_typeid,
					'updated_time' => $val['time']
				];
				self::addTerminalsingle($temp);
			}

			return true;
		} catch (\ErrorException $exception) {
			$this->error(11000, $exception->getMessage());
		}

	}


	/*
	 * 根据mac地址 获取设备的设备号等等
	 * @author yongkang
	 * @param  string $ac 需要的mac 地址
	 * @return 返回设备的设备编号,若返回false,则说明该mac无设备信息
	 */
	public static function getMachineInfoByMac($mac = ''){

		$config = [
			'publicKey' => Yii::$app->params['key']['publicKey'],
			'privateKey' =>Yii::$app->params['key']['privateKey']
		];

		$rsa = new Rsa($config);
		$api = Yii::$app->params['domainList']['domain'] . Yii::$app->params['apiBaseList']['apiMachineMacAddress'];

		$mac_data = [
			'appId' =>  Yii::$app->params['appId'],
			'accessToken'=> self::getToken(),
			'data' => $rsa->encrypt(['macAddress'=>$mac,'field'=>'type_id,mac_address,id'])
		];

		$rsaResult = parent::HttpClient($api,$mac_data,'post');

		if($rsaResult['code'] == 0){
			$result = $rsa->decrypt($rsaResult['data']);
			return $result;
		}
		return false;
	}


	/*
	 * http-client 给陈建的素材创建通知接口 - 单条
	 * @author yongkang
	 * @param  string $ac 需要的mac 地址
	 * @time 2017年09月25日11:52:25
	 * @return 返回设备的设备编号,若返回false,则说明该mac无设备信息
	 */
	public static function curlToCjTermainalListSingle($machine, $material, $time){
		$url = 'http://advertisement.datudev.net/machine-material/down';
		$url .= '?machine_id='.$machine.'&material_id='.$material.'&download_time='.$time;

		try{
			parent::HttpClient($url,'','get');
			return true;
		}
		catch(\Exception $exception){
			return 'cj接口单条状态添加报错啦,内容为'.$exception;
		}
	}

	/**
	 * @name 关联资源表
	 * @author caolei
	 * @time 2017年9月28日09:52:38
	 * @return [type] [description]
	 */
	public function getResource()
	{
	    return $this->hasMany(Resource::className(), ['id' => 'res_id']);
	}

	/**
	 * @name 关联奖池表
	 * @author caolei
	 * @time 2017年9月28日09:51:28
	 * @return
	 */
	public function getJackpot()
	{
		return $this->hasMany(Jackpot::className(), ['id' => 'res_id']);
	}

	/**
	 * @name 增加重置次数
	 * @author caolei
	 * @time 2017年10月17日10:20:02
	 * @param [type] $id [description]
	 */
	public function addTimes($m_id, $v_id, $type = 3)
	{
		try {
			if ($model = Terminal::findOne(['equ_number' => $m_id, 'res_id' => $v_id, 'type' => $type])) {
				$model->times += 1;
				$model->save();
				return true;
			} else {
				return false;
			}
		} catch (\Exception $e) {
			$this->error(15000, '内部错误', $e->getMessage());
		}
	}

}