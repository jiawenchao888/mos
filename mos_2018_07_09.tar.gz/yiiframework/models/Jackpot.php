<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class Jackpot extends CommonModel
{

	public static function tableName()
	{
		return "{{%jackpot}}";
	}

	public function rules()
	{
		return [
			[['is_enable', 'name', 'award_list'], 'trim'],
			['name', 'string', 'length'=>[1,32], 'message'=>'长度超标'],
			[['is_enable', 'is_deleted'], 'integer', 'message'=>'必须为整型'],
			[['is_enable'], 'default', 'value' => 0],
			[['is_enable', 'name', 'award_list'], 'required', 'message' => '不能为空'],
		];
	}


	/**
	 * @name 奖池添加修改
	 * @author caolei
	 * @time 2017年9月18日16:54:43
	 * @return bool
	 */
	public function add($data)
	{
		//奖品不能重复
		$this->load($data);
		$awardList = json_decode($this->award_list, true);
		$awardList = array_column($awardList, 'id');
		if (count($awardList) != count(array_unique($awardList))) {
		    $this->error(14000, '奖池不能添加重复的奖品');
		}
		$model = new Award();
		if (empty($data['Jackpot']['id'])) {
			//新增奖品直接添加关联
			$model->setIsRelevance($awardList);
		} else {
			//编辑奖品，判断是否编辑award_list,然后删除之前关联的，在添加新的关联
			if (!empty($dirty['award_list'])) {
				//更新关联奖池之前删除之前关联过的奖池
				$dirty = $this->getDirtyAttributes();
				$old = $this->getOldAttribute('award_list');
				$oldAwadList = json_decode($this->getOldAttribute('award_list'), true);
				$oldAwadList = array_column($oldAwadList, 'id');
				$model->delIsRelevance($oldAwadList);
				//更新新的关联奖池
				$model->setIsRelevance($awardList);
			}
		}
		if ($this->save()) {
			return true;
		}
		return false;
	}

	/**
	 * @name 奖池单个详情
	 * @author caolei
	 * @time 2017年9月29日20:44:42
	 * @return [type] [description]
	 */
	public function details($id)
	{
		$model = self::findOne($id);
		$model = ArrayHelper::toArray($model);
		if ($model) {
			return $model;
		} else {
			return false;
		}
	}

	/**
	 * @name 根据id值获取奖池信息
	 * @author caolei
	 * @param  单个id 1  多个id 1,2,3
	 * @return array
	 */
	public function listt($id = '')
	{
		if(empty($id)){
			return false;
		}
		$id = explode(',', $id);
		$resource = self::findAll($id);
		$data = ArrayHelper::toArray($resource);
		return $data;
	}

	/**
	 * @name 奖池删除
	 * @author caolei
	 * @time 2017年9月29日20:32:47
	 * @return bool
	 */
	public function delJackpot($id)
	{
		$model = self::findOne($id);
		$model->is_deleted = 1;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

}