<?php
namespace app\models;

use Yii;

class NetpointWechat extends CommonModel
{
	public static function tableName()
	{
		return "{{%netpoint_wechat}}";
	}

	public function rules()
	{
		return [
			[['netpoint_id', 'name', 'url_wechat'], 'safe'],
		];
	}

	/**
	 * @name 批量添加
	 * @author caolei
	 * @param $data 入库的数据
	 * @time 2017年12月6日10:17:06
	 * @return [int] [操作的数据条数]
	 */
	public static function batchInsert($data)
	{
		try {
			return Yii::$app->db->createCommand()->batchInsert(self::tableName(), ['netpoint_id', 'name', 'url_wechat'], $data)->execute();
		} catch (\Exception $e) {
			$this->error(13000, '数据库内部错误');
		}
	}

	/**
	 * @name 无验证修改
	 * @author caolei
	 * @param  [array] $data [修改的数据]
	 * @time 2017年12月6日14:42:03
	 * @return [int]   [操作数据影响条数]
	 */
	public static function singleUpdate($data)
	{
		try {
			return Yii::$app->db->createCommand()->update(self::tableName(), ['name' => $data['name'], 'url_wechat' => $data['url_wechat']], ['netpoint_id' => $data['netpoint_id']])->execute();
		} catch (\Exception $e) {
			$this->error(13000, '数据库内部错误');
		}
	}

	/**
	 * @name 根据网点id查询，对应的二维码链接
	 * @param  [int] $netpointId [网点id]
	 * @return [type]     [description]
	 */
	public function getUrlByNetPointId($netpointId)
	{
		if ($model = NetpointWechat::findOne(['netpoint_id' => $netpointId])) {
			return $model->url_wechat;
		} else {
			return false;
		}

	}

	/**
	 * @name 编辑，添加
	 * @param  [array] $data [表单提交的数据]
	 * @return [type]       [description]
	 */
	public function edit($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

}