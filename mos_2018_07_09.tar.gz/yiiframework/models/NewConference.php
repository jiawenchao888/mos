<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class NewConference extends CommonModel
{

	public static function tableName()
	{
		return "{{%new_conference}}";
	}

	public function rules()
	{
		return [
			[['wechat_name', 'access_token', 'head_url'], 'trim'],
			// [['wechat_name', 'access_token', 'head_url'], 'required'],
			[['access_token'], 'unique'],
		];
	}

	public function attributeLabels()
	{
		return [
			"wechat_name" => '微信名称',
			"access_token" => 'access_token',
			"head_url" => '头像地址',
		];
	}

	/**
	 * 添加
	 * @param [array] $data [表单提交的数据]
	 * return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 编辑
	 * @param  [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function edit($data)
	{
		$this->updated_time = time();
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	public function team($id)
	{
		$model = self::findOne($id);
		$model->team = $model->id%10;
		if ($model->save()) {
			return [
				'team' => $model->team,
				'id' => $model->id,
			];
			// return $model->team;
		} else {
			return false;
		}
	}

}