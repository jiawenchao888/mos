<?php
namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class UploadForm extends Model
{
	/**
	 * 文件上传属性
	 * @var [type]
	 */
	public $file;

	/**
	 * 验证规则
	 * @return [type] [description]
	 */
	public function rules()
	{
		return [
			[['file'], 'file', 'extensions' => 'png,jpg,apk,txt','checkExtensionByMimeType' => false],
		];
	}

}