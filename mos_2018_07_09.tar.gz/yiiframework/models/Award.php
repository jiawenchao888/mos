<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class Award extends CommonModel
{

	public static function tableName()
	{
		return "{{%award}}";
	}

	public function rules()
	{
		return [
			[['img_url', 'name', 'type', 'url', 'end_time', 'start_time', 'effective_times', 'qrcode_time', 'md5', 'times', 'is_enable', 'business_type'], 'trim'],
			[['img_url', 'name', 'type', 'url', 'end_time', 'start_time'], 'required', 'message' => '不能有空数据'],
			[['effective_times', 'qrcode_time', 'times', 'is_enable', 'business_type', 'times', 'is_enable', 'business_type'], 'default', 'value' => 0],
			[['end_time', 'start_time', 'effective_times', 'qrcode_time'], 'integer', 'message'=>'必须为整型'],
			[['md5'], 'default', 'value' => ''],
		];
	}

	/**
	 * @name 奖品添加修改
	 * @author caolei
	 * @time 2017年9月15日16:47:44
	 * @return bool
	 */
	public function add($data)
	{
		if ($this->load($data)) {
			//id为空表示新增,记录新增的操作
			if (empty($data['Award']['id'])) {
				$this->md5 = $this->makeMd5File($this->img_url);
			} else {
				$dirty = $this->getDirtyAttributes();
				if (!empty($dirty['img_url'])) {
					$this->md5 = $this->makeMd5File($this->img_url);
				}
			}
		} else {
			$this->error(13200, '数据加载出错', []);
		}
		if ($this->save()) {
			return true;
		}
		return false;
	}

	/**
	 * @name 查询单个奖品详情
	 * @author caolei
	 * @time 2017年9月15日16:49:15
	 * @return array
	 */
	public function details($id)
	{
		$model = self::findOne($id);
		$model = ArrayHelper::toArray($model);
		if ($model) {
			return $model;
		} else {
			return false;
		}
	}

	/**
	 * @name jackpot 控制器 Getresconjack 下的查询奖品方法
	 * @author caolei
	 * @param $id array 要查询的id
	 * @time 2017年9月22日16:45:07
	 * @return [type] [description]
	 */
	public function listt($id)
	{
		if(empty($id)){
			return false;
		}
		$model = self::find();
		$resource = $model->select('id,md5,img_url,name,url')->where(['id'=>$id])->all();
		$data = yii\helpers\ArrayHelper::toArray($resource);
		foreach ($data as $key => &$value) {
			$value['img_url'] = $this->getFullUrl($value['img_url']);
		}
		return $data;
	}


	/**
	 * @name 删除奖品关联字段
	 * @param  string $arr array 需要删除的关联字段
	 * @author caolei
	 * @time 2017年10月23日19:19:27
	 * @return [type]        [description]
	 */
	public function delIsRelevance($arr)
	{
		$arrModel = self::findAll($arr);
		foreach ($arrModel as $key => $model) {
			$model->is_relevance = 0;
			if (!$model->save()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @name 设置奖品关联字段
	 * @param $arr array 需要设置值的关联字段
	 * @author caolei
	 * @time 2017年9月29日19:35:17
	 * @return bool
	 */
	public function setIsRelevance($arr)
	{
		$arrModel = self::findAll($arr);
		foreach ($arrModel as $key => $model) {
			$model->is_relevance = 1;
			if (!$model->save()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @name 奖品删除
	 * @author caolei
	 * @time 2017年10月11日17:24:53
	 * @return bool
	 */
	public function delAward($id)
	{
		$model = self::findOne($id);
		$model->is_deleted = 1;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

}