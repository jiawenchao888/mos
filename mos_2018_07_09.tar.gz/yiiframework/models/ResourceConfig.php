<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class ResourceConfig extends CommonModel
{

	public static function tableName()
	{
		return "{{%resource_config}}";
	}

	/**
	 * @name 获取素材配置
	 * @param  [int] $resId [素材id]
	 * @return
	 */
	public static function getConfig($resId)
	{
		if ($res = self::findOne(['res_id' => $resId, 'is_deleted' => 0])) {
			return $res->config;
		} else {
			return false;
		}
	}

	/**
	 * @name 添加
	 * @param [int] $resId  [素材id]
	 * @param [string] $config [素材配置]
	 */
	public static function add($resId, $config)
	{
		$model = new self();
		$model->res_id = $resId;
		$model->config = $config;
		return $model->save();
	}

	/**
	 * @name 编辑配置文件
	 * @param [int] $resId [素材id]
	 * @return
	 */
	public static function edit($resId, $config)
	{
		if ($model = self::findOne(['res_id' => $resId])) {
			$model->config = $config;
			return $model->save();
		} else {
			return ;
		}
	}

	public static function del($resId)
	{
		return self::updateAll(['is_deleted' => 1], "res_id = {$resId}");
	}

}