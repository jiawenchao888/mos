<?php
namespace app\models;

use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;
use yii;

class AuditOperator extends CommonModel
{

	public static function tableName()
	{
		return "{{%audit_operator}}";
	}

	public function rules()
	{
		return [
			[['user_name', 'account_number', 'email', 'email_remind', 'password'], 'trim'],
			['email', 'email'],
			[['user_name', 'account_number', 'email', 'email_remind', 'password'], 'required'],
			[['user_name'], 'unique'],
			[['created_time'], 'default', 'value' => time()],
		];
	}

	public function attributeLabels()
	{
		return [
			"user_name" => '用户名',
			"account_number" => '账号',
			"email" => '邮箱',
			"email_remind" => '邮箱提醒',
		];
	}

	/**
	 * 添加
	 * @param [array] $data [表单提交的数据]
	 * return bool
	 */
	public function add($data)
	{
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 编辑
	 * @param  [array] $data [表单提交的数据]
	 * @return bool
	 */
	public function edit($data)
	{
		$this->updated_time = time();
		if ($this->load($data, '') && $this->save()) {
			return true;
		} else {
			return false;
		}
	}

}