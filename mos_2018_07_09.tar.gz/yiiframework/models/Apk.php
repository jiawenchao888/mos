<?php
namespace app\models;
use Yii;

class Apk extends CommonModel
{

	public static function tableName()
	{
		return "{{%apk}}";
	}

	public function rules()
	{
		return [
			[['type', 'version', 'upload_time', 'upload_url', 'version_explain'], 'trim'],
			[['type', 'version', 'upload_time', 'upload_url', 'version_explain'], 'required', 'message' => '不能为空'],
		];
	}


	/**
	 * @name mos安装包添加
	 * @remark mos安装包添加
	 * @author yongkang
	 * @time 2017年09月18日 09:27:15
	 * return bool | array
	 */
	public function add($data)
	{
		if($this->load($data) && $this->save()){
			return true;
		}
		return false;
	}

	/**
	 * @name 查询单个mos包详情
	 * @author caolei
	 * @time 2017年10月12日11:07:48
	 * @return array
	 */
	public function details($id)
	{
		$model = self::findOne($id);
		$model = ArrayHelper::toArray($model);
		if ($model) {
			return $model;
		} else {
			return false;
		}
	}

	/**
	 * @name mos删除
	 * @author caolei
	 * @time 2017年10月12日14:47:58
	 * @return bool
	 */
	public function delApk($id)
	{
		$model = self::findOne($id);
		$model->is_deleted = 1;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @name mos还原
	 * @param  int or arr $id
	 * @time 2018年3月23日
	 * @author caolei
	 * @return bool
	 */
	public function restore($id)
	{
		$model = self::findOne($id);
		$model->is_deleted = 0;
		if ($model->save()) {
			return true;
		} else {
			return false;
		}
	}

}