<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;

class TerminalLog extends ActiveRecord
{
	public static function tableName()
	{
		return "{{%terminal_log}}";
	}

	public function rules()
	{
		return [
			[['res_id', 'equ_number', 'type', 'status', 'time', 'msg'], 'required', 'message'=>'不能为空', 'on'=>['add']],
		];
	}

	/**
	 * @name 终端素材返回状态添加
	 * @author caolei
	 * @time 2017年9月20日13:36:42
	 */
	public function add($data)
	{
		$this->scenario = 'add';
		if ($this->load($data) && $this->save()) {
			return true;
		}
		return false;
	}


}