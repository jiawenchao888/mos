<?php

namespace app\common;

use Yii;

class Common
{

    /**
     * @name 发送邮件
     * @maile string 发送的邮件地址
     * @subject string 邮件标题
     * @auditBody string 邮件内容
     * @param string $scenario 发送场景
     * @author caolei
     * @time 2018年3月14日
     * @return [type] [description]
     */
    public static function sendMail($email, $subject, $auditBody = '')
    {
    	$redis = Yii::$app->redis;
        $mail= Yii::$app->mailer->compose();
        $mail->setTo($email);
        $mail->setSubject($subject);
        $mail->setTextBody($auditBody);   //发布纯文字文本
        // $mail->setHtmlBody($auditBody);    //发布可以带html标签的文本
        if($mail->send()){
        	return true;
        }else{
            return false;
        }
    }


    /**
     * @name 处理model的报错信息
     * @param $data array model的错误信息
     * @author caolei
     * @time 2018年5月2日
     * @return string
     */
    public static function disposeModelError($data)
    {
        $msg = '';
        foreach ($data as $key => $value) {
            $msg .= $value[0];
        }
        return $msg;
    }

}